import { i as identity, a as is_function, w as writable, S as SvelteComponentDev, b as init, s as safe_not_equal, d as dispatch_dev, c as create_slot, v as validate_slots, e as element, f as claim_element, g as children, h as detach_dev, j as attr_dev, k as add_location, l as insert_hydration_dev, u as update_slot_base, m as get_all_dirty_from_scope, n as get_slot_changes, t as transition_in, o as add_render_callback, p as create_bidirectional_transition, q as transition_out, r as space, x as claim_space, y as append_hydration_dev, z as noop, A as globals, B as createEventDispatcher, C as create_component, D as claim_component, E as mount_component, F as destroy_component, G as text, H as claim_text, I as src_url_equal, J as set_data_dev, K as group_outros, L as check_outros, M as toggle_class, N as listen_dev, O as run_all, P as bubble, Q as prop_dev, R as set_input_value, T as binding_callbacks, U as bind, V as prevent_default, W as add_flush_callback, X as onMount, Y as onDestroy, Z as empty, _ as query_selector_all, $ as validate_each_argument, a0 as validate_each_keys, a1 as fix_position, a2 as add_transform, a3 as create_animation, a4 as update_keyed_each, a5 as fix_and_outro_and_destroy_block } from './client.ac2f7d6b.js';
import { B as Button } from './Button.621849db.js';

function cubicOut(t) {
    const f = t - 1.0;
    return f * f * f + 1.0;
}

function fade(node, { delay = 0, duration = 400, easing = identity } = {}) {
    const o = +getComputedStyle(node).opacity;
    return {
        delay,
        duration,
        easing,
        css: t => `opacity: ${t * o}`
    };
}
function fly(node, { delay = 0, duration = 400, easing = cubicOut, x = 0, y = 0, opacity = 0 } = {}) {
    const style = getComputedStyle(node);
    const target_opacity = +style.opacity;
    const transform = style.transform === 'none' ? '' : style.transform;
    const od = target_opacity * (1 - opacity);
    return {
        delay,
        duration,
        easing,
        css: (t, u) => `
			transform: ${transform} translate(${(1 - t) * x}px, ${(1 - t) * y}px);
			opacity: ${target_opacity - (od * u)}`
    };
}
function slide(node, { delay = 0, duration = 400, easing = cubicOut } = {}) {
    const style = getComputedStyle(node);
    const opacity = +style.opacity;
    const height = parseFloat(style.height);
    const padding_top = parseFloat(style.paddingTop);
    const padding_bottom = parseFloat(style.paddingBottom);
    const margin_top = parseFloat(style.marginTop);
    const margin_bottom = parseFloat(style.marginBottom);
    const border_top_width = parseFloat(style.borderTopWidth);
    const border_bottom_width = parseFloat(style.borderBottomWidth);
    return {
        delay,
        duration,
        easing,
        css: t => 'overflow: hidden;' +
            `opacity: ${Math.min(t * 20, 1) * opacity};` +
            `height: ${t * height}px;` +
            `padding-top: ${t * padding_top}px;` +
            `padding-bottom: ${t * padding_bottom}px;` +
            `margin-top: ${t * margin_top}px;` +
            `margin-bottom: ${t * margin_bottom}px;` +
            `border-top-width: ${t * border_top_width}px;` +
            `border-bottom-width: ${t * border_bottom_width}px;`
    };
}
function scale(node, { delay = 0, duration = 400, easing = cubicOut, start = 0, opacity = 0 } = {}) {
    const style = getComputedStyle(node);
    const target_opacity = +style.opacity;
    const transform = style.transform === 'none' ? '' : style.transform;
    const sd = 1 - start;
    const od = target_opacity * (1 - opacity);
    return {
        delay,
        duration,
        easing,
        css: (_t, u) => `
			transform: ${transform} scale(${1 - (sd * u)});
			opacity: ${target_opacity - (od * u)}
		`
    };
}

function flip(node, { from, to }, params = {}) {
    const style = getComputedStyle(node);
    const transform = style.transform === 'none' ? '' : style.transform;
    const [ox, oy] = style.transformOrigin.split(' ').map(parseFloat);
    const dx = (from.left + from.width * ox / to.width) - (to.left + ox);
    const dy = (from.top + from.height * oy / to.height) - (to.top + oy);
    const { delay = 0, duration = (d) => Math.sqrt(d) * 120, easing = cubicOut } = params;
    return {
        delay,
        duration: is_function(duration) ? duration(Math.sqrt(dx * dx + dy * dy)) : duration,
        easing,
        css: (t, u) => {
            const x = u * dx;
            const y = u * dy;
            const sx = t + u * from.width / to.width;
            const sy = t + u * from.height / to.height;
            return `transform: ${transform} translate(${x}px, ${y}px) scale(${sx}, ${sy});`;
        }
    };
}

const meetups = writable([]);

const customMeetupsStore = {
  subscribe: meetups.subscribe,
  setMeetups: (items) => {
    meetups.set(items);
  },
  addMeetup: (meetupData) => {
    const newMeetup = {
      ...meetupData,
    };
    meetups.update((items) => [newMeetup, ...items]);
  },
  updateMeetup: (id, meetupData) => {
    meetups.update((items) => {
      const meetupIndex = items.findIndex((i) => i.id === id);
      const updatedMeetup = { ...items[meetupIndex], ...meetupData };
      const updatedMeetups = [...items];
      updatedMeetups[meetupIndex] = updatedMeetup;
      return updatedMeetups;
    });
  },
  removeMeetup: (id) => {
    meetups.update((items) => {
      return items.filter((i) => i.id !== id);
    });
  },
  toggleFavorite: (id) => {
    meetups.update((items) => {
      const updatedMeetup = { ...items.find((m) => m.id === id) };
      updatedMeetup.isFavorite = !updatedMeetup.isFavorite;
      const meetupIndex = items.findIndex((m) => m.id === id);
      const updatedMeetups = [...items];
      updatedMeetups[meetupIndex] = updatedMeetup;
      return updatedMeetups;
    });
  },
};

/* src\components\UI\Badge.svelte generated by Svelte v3.45.0 */
const file = "src\\components\\UI\\Badge.svelte";

function create_fragment(ctx) {
	let span;
	let span_transition;
	let current;
	const default_slot_template = /*#slots*/ ctx[1].default;
	const default_slot = create_slot(default_slot_template, ctx, /*$$scope*/ ctx[0], null);

	const block = {
		c: function create() {
			span = element("span");
			if (default_slot) default_slot.c();
			this.h();
		},
		l: function claim(nodes) {
			span = claim_element(nodes, "SPAN", { class: true });
			var span_nodes = children(span);
			if (default_slot) default_slot.l(span_nodes);
			span_nodes.forEach(detach_dev);
			this.h();
		},
		h: function hydrate() {
			attr_dev(span, "class", "svelte-vxg6x8");
			add_location(span, file, 4, 0, 69);
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, span, anchor);

			if (default_slot) {
				default_slot.m(span, null);
			}

			current = true;
		},
		p: function update(ctx, [dirty]) {
			if (default_slot) {
				if (default_slot.p && (!current || dirty & /*$$scope*/ 1)) {
					update_slot_base(
						default_slot,
						default_slot_template,
						ctx,
						/*$$scope*/ ctx[0],
						!current
						? get_all_dirty_from_scope(/*$$scope*/ ctx[0])
						: get_slot_changes(default_slot_template, /*$$scope*/ ctx[0], dirty, null),
						null
					);
				}
			}
		},
		i: function intro(local) {
			if (current) return;
			transition_in(default_slot, local);

			add_render_callback(() => {
				if (!span_transition) span_transition = create_bidirectional_transition(span, slide, {}, true);
				span_transition.run(1);
			});

			current = true;
		},
		o: function outro(local) {
			transition_out(default_slot, local);
			if (!span_transition) span_transition = create_bidirectional_transition(span, slide, {}, false);
			span_transition.run(0);
			current = false;
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(span);
			if (default_slot) default_slot.d(detaching);
			if (detaching && span_transition) span_transition.end();
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_fragment.name,
		type: "component",
		source: "",
		ctx
	});

	return block;
}

function instance($$self, $$props, $$invalidate) {
	let { $$slots: slots = {}, $$scope } = $$props;
	validate_slots('Badge', slots, ['default']);
	const writable_props = [];

	Object.keys($$props).forEach(key => {
		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== '$$' && key !== 'slot') console.warn(`<Badge> was created with unknown prop '${key}'`);
	});

	$$self.$$set = $$props => {
		if ('$$scope' in $$props) $$invalidate(0, $$scope = $$props.$$scope);
	};

	$$self.$capture_state = () => ({ slide });
	return [$$scope, slots];
}

class Badge extends SvelteComponentDev {
	constructor(options) {
		super(options);
		init(this, options, instance, create_fragment, safe_not_equal, {});

		dispatch_dev("SvelteRegisterComponent", {
			component: this,
			tagName: "Badge",
			options,
			id: create_fragment.name
		});
	}
}

/* src\components\UI\Spinner.svelte generated by Svelte v3.45.0 */

const file$1 = "src\\components\\UI\\Spinner.svelte";

function create_fragment$1(ctx) {
	let div5;
	let div4;
	let div0;
	let t0;
	let div1;
	let t1;
	let div2;
	let t2;
	let div3;

	const block = {
		c: function create() {
			div5 = element("div");
			div4 = element("div");
			div0 = element("div");
			t0 = space();
			div1 = element("div");
			t1 = space();
			div2 = element("div");
			t2 = space();
			div3 = element("div");
			this.h();
		},
		l: function claim(nodes) {
			div5 = claim_element(nodes, "DIV", { class: true });
			var div5_nodes = children(div5);
			div4 = claim_element(div5_nodes, "DIV", { class: true });
			var div4_nodes = children(div4);
			div0 = claim_element(div4_nodes, "DIV", { class: true });
			children(div0).forEach(detach_dev);
			t0 = claim_space(div4_nodes);
			div1 = claim_element(div4_nodes, "DIV", { class: true });
			children(div1).forEach(detach_dev);
			t1 = claim_space(div4_nodes);
			div2 = claim_element(div4_nodes, "DIV", { class: true });
			children(div2).forEach(detach_dev);
			t2 = claim_space(div4_nodes);
			div3 = claim_element(div4_nodes, "DIV", { class: true });
			children(div3).forEach(detach_dev);
			div4_nodes.forEach(detach_dev);
			div5_nodes.forEach(detach_dev);
			this.h();
		},
		h: function hydrate() {
			attr_dev(div0, "class", "svelte-rs856v");
			add_location(div0, file$1, 2, 4, 53);
			attr_dev(div1, "class", "svelte-rs856v");
			add_location(div1, file$1, 3, 4, 66);
			attr_dev(div2, "class", "svelte-rs856v");
			add_location(div2, file$1, 4, 4, 79);
			attr_dev(div3, "class", "svelte-rs856v");
			add_location(div3, file$1, 5, 4, 92);
			attr_dev(div4, "class", "lds-ring svelte-rs856v");
			add_location(div4, file$1, 1, 2, 25);
			attr_dev(div5, "class", "loading svelte-rs856v");
			add_location(div5, file$1, 0, 0, 0);
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, div5, anchor);
			append_hydration_dev(div5, div4);
			append_hydration_dev(div4, div0);
			append_hydration_dev(div4, t0);
			append_hydration_dev(div4, div1);
			append_hydration_dev(div4, t1);
			append_hydration_dev(div4, div2);
			append_hydration_dev(div4, t2);
			append_hydration_dev(div4, div3);
		},
		p: noop,
		i: noop,
		o: noop,
		d: function destroy(detaching) {
			if (detaching) detach_dev(div5);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_fragment$1.name,
		type: "component",
		source: "",
		ctx
	});

	return block;
}

function instance$1($$self, $$props) {
	let { $$slots: slots = {}, $$scope } = $$props;
	validate_slots('Spinner', slots, []);
	const writable_props = [];

	Object.keys($$props).forEach(key => {
		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== '$$' && key !== 'slot') console.warn(`<Spinner> was created with unknown prop '${key}'`);
	});

	return [];
}

class Spinner extends SvelteComponentDev {
	constructor(options) {
		super(options);
		init(this, options, instance$1, create_fragment$1, safe_not_equal, {});

		dispatch_dev("SvelteRegisterComponent", {
			component: this,
			tagName: "Spinner",
			options,
			id: create_fragment$1.name
		});
	}
}

/* src\components\Meetups\MeetupItem.svelte generated by Svelte v3.45.0 */

const { Error: Error_1, console: console_1 } = globals;
const file$2 = "src\\components\\Meetups\\MeetupItem.svelte";

// (48:6) {#if isFav}
function create_if_block_1(ctx) {
	let badge;
	let current;

	badge = new Badge({
			props: {
				$$slots: { default: [create_default_slot_3] },
				$$scope: { ctx }
			},
			$$inline: true
		});

	const block = {
		c: function create() {
			create_component(badge.$$.fragment);
		},
		l: function claim(nodes) {
			claim_component(badge.$$.fragment, nodes);
		},
		m: function mount(target, anchor) {
			mount_component(badge, target, anchor);
			current = true;
		},
		i: function intro(local) {
			if (current) return;
			transition_in(badge.$$.fragment, local);
			current = true;
		},
		o: function outro(local) {
			transition_out(badge.$$.fragment, local);
			current = false;
		},
		d: function destroy(detaching) {
			destroy_component(badge, detaching);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_if_block_1.name,
		type: "if",
		source: "(48:6) {#if isFav}",
		ctx
	});

	return block;
}

// (49:8) <Badge>
function create_default_slot_3(ctx) {
	let t;

	const block = {
		c: function create() {
			t = text("FAVORITE");
		},
		l: function claim(nodes) {
			t = claim_text(nodes, "FAVORITE");
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, t, anchor);
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(t);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_default_slot_3.name,
		type: "slot",
		source: "(49:8) <Badge>",
		ctx
	});

	return block;
}

// (62:4) <Button type="button" mode="outline" on:click={() => dispatch('edit', id)}       >
function create_default_slot_2(ctx) {
	let t;

	const block = {
		c: function create() {
			t = text("Edit");
		},
		l: function claim(nodes) {
			t = claim_text(nodes, "Edit");
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, t, anchor);
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(t);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_default_slot_2.name,
		type: "slot",
		source: "(62:4) <Button type=\\\"button\\\" mode=\\\"outline\\\" on:click={() => dispatch('edit', id)}       >",
		ctx
	});

	return block;
}

// (68:4) {:else}
function create_else_block(ctx) {
	let button;
	let current;

	button = new Button({
			props: {
				type: "button",
				mode: "outline",
				color: /*isFav*/ ctx[6] ? null : 'success',
				$$slots: { default: [create_default_slot_1] },
				$$scope: { ctx }
			},
			$$inline: true
		});

	button.$on("click", /*toggleFavorite*/ ctx[9]);

	const block = {
		c: function create() {
			create_component(button.$$.fragment);
		},
		l: function claim(nodes) {
			claim_component(button.$$.fragment, nodes);
		},
		m: function mount(target, anchor) {
			mount_component(button, target, anchor);
			current = true;
		},
		p: function update(ctx, dirty) {
			const button_changes = {};
			if (dirty & /*isFav*/ 64) button_changes.color = /*isFav*/ ctx[6] ? null : 'success';

			if (dirty & /*$$scope, isFav*/ 4160) {
				button_changes.$$scope = { dirty, ctx };
			}

			button.$set(button_changes);
		},
		i: function intro(local) {
			if (current) return;
			transition_in(button.$$.fragment, local);
			current = true;
		},
		o: function outro(local) {
			transition_out(button.$$.fragment, local);
			current = false;
		},
		d: function destroy(detaching) {
			destroy_component(button, detaching);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_else_block.name,
		type: "else",
		source: "(68:4) {:else}",
		ctx
	});

	return block;
}

// (65:4) {#if isLoading}
function create_if_block(ctx) {
	let span;
	let t;

	const block = {
		c: function create() {
			span = element("span");
			t = text("Changing...");
			this.h();
		},
		l: function claim(nodes) {
			span = claim_element(nodes, "SPAN", {});
			var span_nodes = children(span);
			t = claim_text(span_nodes, "Changing...");
			span_nodes.forEach(detach_dev);
			this.h();
		},
		h: function hydrate() {
			add_location(span, file$2, 66, 6, 1516);
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, span, anchor);
			append_hydration_dev(span, t);
		},
		p: noop,
		i: noop,
		o: noop,
		d: function destroy(detaching) {
			if (detaching) detach_dev(span);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_if_block.name,
		type: "if",
		source: "(65:4) {#if isLoading}",
		ctx
	});

	return block;
}

// (69:6) <Button         type="button"         mode="outline"         color={isFav ? null : 'success'}         on:click={toggleFavorite}>
function create_default_slot_1(ctx) {
	let t_value = (/*isFav*/ ctx[6] ? 'Unfavorite' : 'Favorite') + "";
	let t;

	const block = {
		c: function create() {
			t = text(t_value);
		},
		l: function claim(nodes) {
			t = claim_text(nodes, t_value);
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, t, anchor);
		},
		p: function update(ctx, dirty) {
			if (dirty & /*isFav*/ 64 && t_value !== (t_value = (/*isFav*/ ctx[6] ? 'Unfavorite' : 'Favorite') + "")) set_data_dev(t, t_value);
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(t);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_default_slot_1.name,
		type: "slot",
		source: "(69:6) <Button         type=\\\"button\\\"         mode=\\\"outline\\\"         color={isFav ? null : 'success'}         on:click={toggleFavorite}>",
		ctx
	});

	return block;
}

// (76:4) <Button type="button" caption="Show Details" href="/{id}"       >
function create_default_slot(ctx) {
	let t;

	const block = {
		c: function create() {
			t = text("Show Details");
		},
		l: function claim(nodes) {
			t = claim_text(nodes, "Show Details");
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, t, anchor);
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(t);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_default_slot.name,
		type: "slot",
		source: "(76:4) <Button type=\\\"button\\\" caption=\\\"Show Details\\\" href=\\\"/{id}\\\"       >",
		ctx
	});

	return block;
}

function create_fragment$2(ctx) {
	let article;
	let header;
	let h1;
	let t0;
	let t1;
	let t2;
	let h2;
	let t3;
	let t4;
	let p0;
	let t5;
	let t6;
	let div0;
	let img;
	let img_src_value;
	let t7;
	let div1;
	let p1;
	let t8;
	let t9;
	let footer;
	let button0;
	let t10;
	let current_block_type_index;
	let if_block1;
	let t11;
	let button1;
	let current;
	let if_block0 = /*isFav*/ ctx[6] && create_if_block_1(ctx);

	button0 = new Button({
			props: {
				type: "button",
				mode: "outline",
				$$slots: { default: [create_default_slot_2] },
				$$scope: { ctx }
			},
			$$inline: true
		});

	button0.$on("click", /*click_handler*/ ctx[11]);
	const if_block_creators = [create_if_block, create_else_block];
	const if_blocks = [];

	function select_block_type(ctx, dirty) {
		if (/*isLoading*/ ctx[7]) return 0;
		return 1;
	}

	current_block_type_index = select_block_type(ctx);
	if_block1 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);

	button1 = new Button({
			props: {
				type: "button",
				caption: "Show Details",
				href: "/" + /*id*/ ctx[0],
				$$slots: { default: [create_default_slot] },
				$$scope: { ctx }
			},
			$$inline: true
		});

	const block = {
		c: function create() {
			article = element("article");
			header = element("header");
			h1 = element("h1");
			t0 = text(/*title*/ ctx[1]);
			t1 = space();
			if (if_block0) if_block0.c();
			t2 = space();
			h2 = element("h2");
			t3 = text(/*subtitle*/ ctx[2]);
			t4 = space();
			p0 = element("p");
			t5 = text(/*address*/ ctx[5]);
			t6 = space();
			div0 = element("div");
			img = element("img");
			t7 = space();
			div1 = element("div");
			p1 = element("p");
			t8 = text(/*description*/ ctx[4]);
			t9 = space();
			footer = element("footer");
			create_component(button0.$$.fragment);
			t10 = space();
			if_block1.c();
			t11 = space();
			create_component(button1.$$.fragment);
			this.h();
		},
		l: function claim(nodes) {
			article = claim_element(nodes, "ARTICLE", { class: true });
			var article_nodes = children(article);
			header = claim_element(article_nodes, "HEADER", { class: true });
			var header_nodes = children(header);
			h1 = claim_element(header_nodes, "H1", { class: true });
			var h1_nodes = children(h1);
			t0 = claim_text(h1_nodes, /*title*/ ctx[1]);
			t1 = claim_space(h1_nodes);
			if (if_block0) if_block0.l(h1_nodes);
			h1_nodes.forEach(detach_dev);
			t2 = claim_space(header_nodes);
			h2 = claim_element(header_nodes, "H2", { class: true });
			var h2_nodes = children(h2);
			t3 = claim_text(h2_nodes, /*subtitle*/ ctx[2]);
			h2_nodes.forEach(detach_dev);
			t4 = claim_space(header_nodes);
			p0 = claim_element(header_nodes, "P", { class: true });
			var p0_nodes = children(p0);
			t5 = claim_text(p0_nodes, /*address*/ ctx[5]);
			p0_nodes.forEach(detach_dev);
			header_nodes.forEach(detach_dev);
			t6 = claim_space(article_nodes);
			div0 = claim_element(article_nodes, "DIV", { class: true });
			var div0_nodes = children(div0);
			img = claim_element(div0_nodes, "IMG", { src: true, alt: true, class: true });
			div0_nodes.forEach(detach_dev);
			t7 = claim_space(article_nodes);
			div1 = claim_element(article_nodes, "DIV", { class: true });
			var div1_nodes = children(div1);
			p1 = claim_element(div1_nodes, "P", { class: true });
			var p1_nodes = children(p1);
			t8 = claim_text(p1_nodes, /*description*/ ctx[4]);
			p1_nodes.forEach(detach_dev);
			div1_nodes.forEach(detach_dev);
			t9 = claim_space(article_nodes);
			footer = claim_element(article_nodes, "FOOTER", { class: true });
			var footer_nodes = children(footer);
			claim_component(button0.$$.fragment, footer_nodes);
			t10 = claim_space(footer_nodes);
			if_block1.l(footer_nodes);
			t11 = claim_space(footer_nodes);
			claim_component(button1.$$.fragment, footer_nodes);
			footer_nodes.forEach(detach_dev);
			article_nodes.forEach(detach_dev);
			this.h();
		},
		h: function hydrate() {
			attr_dev(h1, "class", "svelte-lym3nh");
			add_location(h1, file$2, 45, 4, 1071);
			attr_dev(h2, "class", "svelte-lym3nh");
			add_location(h2, file$2, 51, 4, 1166);
			attr_dev(p0, "class", "svelte-lym3nh");
			add_location(p0, file$2, 52, 4, 1190);
			attr_dev(header, "class", "svelte-lym3nh");
			add_location(header, file$2, 44, 2, 1058);
			if (!src_url_equal(img.src, img_src_value = /*imageUrl*/ ctx[3])) attr_dev(img, "src", img_src_value);
			attr_dev(img, "alt", /*title*/ ctx[1]);
			attr_dev(img, "class", "svelte-lym3nh");
			add_location(img, file$2, 55, 4, 1245);
			attr_dev(div0, "class", "image svelte-lym3nh");
			add_location(div0, file$2, 54, 2, 1221);
			attr_dev(p1, "class", "svelte-lym3nh");
			add_location(p1, file$2, 58, 4, 1317);
			attr_dev(div1, "class", "content svelte-lym3nh");
			add_location(div1, file$2, 57, 2, 1291);
			attr_dev(footer, "class", "svelte-lym3nh");
			add_location(footer, file$2, 60, 2, 1349);
			attr_dev(article, "class", "svelte-lym3nh");
			add_location(article, file$2, 43, 0, 1046);
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, article, anchor);
			append_hydration_dev(article, header);
			append_hydration_dev(header, h1);
			append_hydration_dev(h1, t0);
			append_hydration_dev(h1, t1);
			if (if_block0) if_block0.m(h1, null);
			append_hydration_dev(header, t2);
			append_hydration_dev(header, h2);
			append_hydration_dev(h2, t3);
			append_hydration_dev(header, t4);
			append_hydration_dev(header, p0);
			append_hydration_dev(p0, t5);
			append_hydration_dev(article, t6);
			append_hydration_dev(article, div0);
			append_hydration_dev(div0, img);
			append_hydration_dev(article, t7);
			append_hydration_dev(article, div1);
			append_hydration_dev(div1, p1);
			append_hydration_dev(p1, t8);
			append_hydration_dev(article, t9);
			append_hydration_dev(article, footer);
			mount_component(button0, footer, null);
			append_hydration_dev(footer, t10);
			if_blocks[current_block_type_index].m(footer, null);
			append_hydration_dev(footer, t11);
			mount_component(button1, footer, null);
			current = true;
		},
		p: function update(ctx, [dirty]) {
			if (!current || dirty & /*title*/ 2) set_data_dev(t0, /*title*/ ctx[1]);

			if (/*isFav*/ ctx[6]) {
				if (if_block0) {
					if (dirty & /*isFav*/ 64) {
						transition_in(if_block0, 1);
					}
				} else {
					if_block0 = create_if_block_1(ctx);
					if_block0.c();
					transition_in(if_block0, 1);
					if_block0.m(h1, null);
				}
			} else if (if_block0) {
				group_outros();

				transition_out(if_block0, 1, 1, () => {
					if_block0 = null;
				});

				check_outros();
			}

			if (!current || dirty & /*subtitle*/ 4) set_data_dev(t3, /*subtitle*/ ctx[2]);
			if (!current || dirty & /*address*/ 32) set_data_dev(t5, /*address*/ ctx[5]);

			if (!current || dirty & /*imageUrl*/ 8 && !src_url_equal(img.src, img_src_value = /*imageUrl*/ ctx[3])) {
				attr_dev(img, "src", img_src_value);
			}

			if (!current || dirty & /*title*/ 2) {
				attr_dev(img, "alt", /*title*/ ctx[1]);
			}

			if (!current || dirty & /*description*/ 16) set_data_dev(t8, /*description*/ ctx[4]);
			const button0_changes = {};

			if (dirty & /*$$scope*/ 4096) {
				button0_changes.$$scope = { dirty, ctx };
			}

			button0.$set(button0_changes);
			let previous_block_index = current_block_type_index;
			current_block_type_index = select_block_type(ctx);

			if (current_block_type_index === previous_block_index) {
				if_blocks[current_block_type_index].p(ctx, dirty);
			} else {
				group_outros();

				transition_out(if_blocks[previous_block_index], 1, 1, () => {
					if_blocks[previous_block_index] = null;
				});

				check_outros();
				if_block1 = if_blocks[current_block_type_index];

				if (!if_block1) {
					if_block1 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
					if_block1.c();
				} else {
					if_block1.p(ctx, dirty);
				}

				transition_in(if_block1, 1);
				if_block1.m(footer, t11);
			}

			const button1_changes = {};
			if (dirty & /*id*/ 1) button1_changes.href = "/" + /*id*/ ctx[0];

			if (dirty & /*$$scope*/ 4096) {
				button1_changes.$$scope = { dirty, ctx };
			}

			button1.$set(button1_changes);
		},
		i: function intro(local) {
			if (current) return;
			transition_in(if_block0);
			transition_in(button0.$$.fragment, local);
			transition_in(if_block1);
			transition_in(button1.$$.fragment, local);
			current = true;
		},
		o: function outro(local) {
			transition_out(if_block0);
			transition_out(button0.$$.fragment, local);
			transition_out(if_block1);
			transition_out(button1.$$.fragment, local);
			current = false;
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(article);
			if (if_block0) if_block0.d();
			destroy_component(button0);
			if_blocks[current_block_type_index].d();
			destroy_component(button1);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_fragment$2.name,
		type: "component",
		source: "",
		ctx
	});

	return block;
}

function instance$2($$self, $$props, $$invalidate) {
	let { $$slots: slots = {}, $$scope } = $$props;
	validate_slots('MeetupItem', slots, []);
	let { id } = $$props;
	let { title } = $$props;
	let { subtitle } = $$props;
	let { imageUrl } = $$props;
	let { description } = $$props;
	let { address } = $$props;
	let { email } = $$props;
	let { isFav } = $$props;
	let isLoading = false;
	const dispatch = createEventDispatcher();

	function toggleFavorite(event) {
		$$invalidate(7, isLoading = true);

		fetch(`https://svelte-course-doles-default-rtdb.firebaseio.com/meetups/${id}.json`, {
			method: 'PATCH',
			body: JSON.stringify({ isFavorite: !isFav }),
			headers: { 'Content-Type': 'application/json' }
		}).then(res => {
			if (!res.ok) {
				throw new Error('Failed!');
			}

			customMeetupsStore.toggleFavorite(id);
		}).catch(err => {
			console.log(err);
		}).finally(() => $$invalidate(7, isLoading = false));
	}

	const writable_props = [
		'id',
		'title',
		'subtitle',
		'imageUrl',
		'description',
		'address',
		'email',
		'isFav'
	];

	Object.keys($$props).forEach(key => {
		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== '$$' && key !== 'slot') console_1.warn(`<MeetupItem> was created with unknown prop '${key}'`);
	});

	const click_handler = () => dispatch('edit', id);

	$$self.$$set = $$props => {
		if ('id' in $$props) $$invalidate(0, id = $$props.id);
		if ('title' in $$props) $$invalidate(1, title = $$props.title);
		if ('subtitle' in $$props) $$invalidate(2, subtitle = $$props.subtitle);
		if ('imageUrl' in $$props) $$invalidate(3, imageUrl = $$props.imageUrl);
		if ('description' in $$props) $$invalidate(4, description = $$props.description);
		if ('address' in $$props) $$invalidate(5, address = $$props.address);
		if ('email' in $$props) $$invalidate(10, email = $$props.email);
		if ('isFav' in $$props) $$invalidate(6, isFav = $$props.isFav);
	};

	$$self.$capture_state = () => ({
		createEventDispatcher,
		meetups: customMeetupsStore,
		Button,
		Badge,
		Spinner,
		id,
		title,
		subtitle,
		imageUrl,
		description,
		address,
		email,
		isFav,
		isLoading,
		dispatch,
		toggleFavorite
	});

	$$self.$inject_state = $$props => {
		if ('id' in $$props) $$invalidate(0, id = $$props.id);
		if ('title' in $$props) $$invalidate(1, title = $$props.title);
		if ('subtitle' in $$props) $$invalidate(2, subtitle = $$props.subtitle);
		if ('imageUrl' in $$props) $$invalidate(3, imageUrl = $$props.imageUrl);
		if ('description' in $$props) $$invalidate(4, description = $$props.description);
		if ('address' in $$props) $$invalidate(5, address = $$props.address);
		if ('email' in $$props) $$invalidate(10, email = $$props.email);
		if ('isFav' in $$props) $$invalidate(6, isFav = $$props.isFav);
		if ('isLoading' in $$props) $$invalidate(7, isLoading = $$props.isLoading);
	};

	if ($$props && "$$inject" in $$props) {
		$$self.$inject_state($$props.$$inject);
	}

	return [
		id,
		title,
		subtitle,
		imageUrl,
		description,
		address,
		isFav,
		isLoading,
		dispatch,
		toggleFavorite,
		email,
		click_handler
	];
}

class MeetupItem extends SvelteComponentDev {
	constructor(options) {
		super(options);

		init(this, options, instance$2, create_fragment$2, safe_not_equal, {
			id: 0,
			title: 1,
			subtitle: 2,
			imageUrl: 3,
			description: 4,
			address: 5,
			email: 10,
			isFav: 6
		});

		dispatch_dev("SvelteRegisterComponent", {
			component: this,
			tagName: "MeetupItem",
			options,
			id: create_fragment$2.name
		});

		const { ctx } = this.$$;
		const props = options.props || {};

		if (/*id*/ ctx[0] === undefined && !('id' in props)) {
			console_1.warn("<MeetupItem> was created without expected prop 'id'");
		}

		if (/*title*/ ctx[1] === undefined && !('title' in props)) {
			console_1.warn("<MeetupItem> was created without expected prop 'title'");
		}

		if (/*subtitle*/ ctx[2] === undefined && !('subtitle' in props)) {
			console_1.warn("<MeetupItem> was created without expected prop 'subtitle'");
		}

		if (/*imageUrl*/ ctx[3] === undefined && !('imageUrl' in props)) {
			console_1.warn("<MeetupItem> was created without expected prop 'imageUrl'");
		}

		if (/*description*/ ctx[4] === undefined && !('description' in props)) {
			console_1.warn("<MeetupItem> was created without expected prop 'description'");
		}

		if (/*address*/ ctx[5] === undefined && !('address' in props)) {
			console_1.warn("<MeetupItem> was created without expected prop 'address'");
		}

		if (/*email*/ ctx[10] === undefined && !('email' in props)) {
			console_1.warn("<MeetupItem> was created without expected prop 'email'");
		}

		if (/*isFav*/ ctx[6] === undefined && !('isFav' in props)) {
			console_1.warn("<MeetupItem> was created without expected prop 'isFav'");
		}
	}

	get id() {
		throw new Error_1("<MeetupItem>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	set id(value) {
		throw new Error_1("<MeetupItem>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	get title() {
		throw new Error_1("<MeetupItem>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	set title(value) {
		throw new Error_1("<MeetupItem>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	get subtitle() {
		throw new Error_1("<MeetupItem>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	set subtitle(value) {
		throw new Error_1("<MeetupItem>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	get imageUrl() {
		throw new Error_1("<MeetupItem>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	set imageUrl(value) {
		throw new Error_1("<MeetupItem>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	get description() {
		throw new Error_1("<MeetupItem>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	set description(value) {
		throw new Error_1("<MeetupItem>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	get address() {
		throw new Error_1("<MeetupItem>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	set address(value) {
		throw new Error_1("<MeetupItem>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	get email() {
		throw new Error_1("<MeetupItem>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	set email(value) {
		throw new Error_1("<MeetupItem>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	get isFav() {
		throw new Error_1("<MeetupItem>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	set isFav(value) {
		throw new Error_1("<MeetupItem>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}
}

/* src\components\Meetups\MeetupFilter.svelte generated by Svelte v3.45.0 */
const file$3 = "src\\components\\Meetups\\MeetupFilter.svelte";

function create_fragment$3(ctx) {
	let div;
	let button0;
	let t0;
	let t1;
	let button1;
	let t2;
	let mounted;
	let dispose;

	const block = {
		c: function create() {
			div = element("div");
			button0 = element("button");
			t0 = text("All");
			t1 = space();
			button1 = element("button");
			t2 = text("Favorites");
			this.h();
		},
		l: function claim(nodes) {
			div = claim_element(nodes, "DIV", { class: true });
			var div_nodes = children(div);
			button0 = claim_element(div_nodes, "BUTTON", { type: true, class: true });
			var button0_nodes = children(button0);
			t0 = claim_text(button0_nodes, "All");
			button0_nodes.forEach(detach_dev);
			t1 = claim_space(div_nodes);
			button1 = claim_element(div_nodes, "BUTTON", { type: true, class: true });
			var button1_nodes = children(button1);
			t2 = claim_text(button1_nodes, "Favorites");
			button1_nodes.forEach(detach_dev);
			div_nodes.forEach(detach_dev);
			this.h();
		},
		h: function hydrate() {
			attr_dev(button0, "type", "button");
			attr_dev(button0, "class", "svelte-wewm0q");
			toggle_class(button0, "active", /*selectedButton*/ ctx[0] === 0);
			add_location(button0, file$3, 9, 2, 159);
			attr_dev(button1, "type", "button");
			attr_dev(button1, "class", "svelte-wewm0q");
			toggle_class(button1, "active", /*selectedButton*/ ctx[0] === 1);
			add_location(button1, file$3, 17, 2, 335);
			attr_dev(div, "class", "svelte-wewm0q");
			add_location(div, file$3, 8, 0, 150);
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, div, anchor);
			append_hydration_dev(div, button0);
			append_hydration_dev(button0, t0);
			append_hydration_dev(div, t1);
			append_hydration_dev(div, button1);
			append_hydration_dev(button1, t2);

			if (!mounted) {
				dispose = [
					listen_dev(button0, "click", /*click_handler*/ ctx[2], false, false, false),
					listen_dev(button1, "click", /*click_handler_1*/ ctx[3], false, false, false)
				];

				mounted = true;
			}
		},
		p: function update(ctx, [dirty]) {
			if (dirty & /*selectedButton*/ 1) {
				toggle_class(button0, "active", /*selectedButton*/ ctx[0] === 0);
			}

			if (dirty & /*selectedButton*/ 1) {
				toggle_class(button1, "active", /*selectedButton*/ ctx[0] === 1);
			}
		},
		i: noop,
		o: noop,
		d: function destroy(detaching) {
			if (detaching) detach_dev(div);
			mounted = false;
			run_all(dispose);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_fragment$3.name,
		type: "component",
		source: "",
		ctx
	});

	return block;
}

function instance$3($$self, $$props, $$invalidate) {
	let { $$slots: slots = {}, $$scope } = $$props;
	validate_slots('MeetupFilter', slots, []);
	const dispatch = createEventDispatcher();
	let selectedButton = 0;
	const writable_props = [];

	Object.keys($$props).forEach(key => {
		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== '$$' && key !== 'slot') console.warn(`<MeetupFilter> was created with unknown prop '${key}'`);
	});

	const click_handler = () => {
		$$invalidate(0, selectedButton = 0);
		dispatch('select', 0);
	};

	const click_handler_1 = () => {
		$$invalidate(0, selectedButton = 1);
		dispatch('select', 1);
	};

	$$self.$capture_state = () => ({
		createEventDispatcher,
		dispatch,
		selectedButton
	});

	$$self.$inject_state = $$props => {
		if ('selectedButton' in $$props) $$invalidate(0, selectedButton = $$props.selectedButton);
	};

	if ($$props && "$$inject" in $$props) {
		$$self.$inject_state($$props.$$inject);
	}

	return [selectedButton, dispatch, click_handler, click_handler_1];
}

class MeetupFilter extends SvelteComponentDev {
	constructor(options) {
		super(options);
		init(this, options, instance$3, create_fragment$3, safe_not_equal, {});

		dispatch_dev("SvelteRegisterComponent", {
			component: this,
			tagName: "MeetupFilter",
			options,
			id: create_fragment$3.name
		});
	}
}

/* src\components\UI\TextInput.svelte generated by Svelte v3.45.0 */

const file$4 = "src\\components\\UI\\TextInput.svelte";

// (24:2) {:else}
function create_else_block$1(ctx) {
	let input;
	let mounted;
	let dispose;

	const block = {
		c: function create() {
			input = element("input");
			this.h();
		},
		l: function claim(nodes) {
			input = claim_element(nodes, "INPUT", { type: true, id: true, class: true });
			this.h();
		},
		h: function hydrate() {
			attr_dev(input, "type", /*type*/ ctx[5]);
			attr_dev(input, "id", /*id*/ ctx[2]);
			input.value = /*value*/ ctx[0];
			attr_dev(input, "class", "svelte-1mrfx4j");
			toggle_class(input, "invalid", !/*valid*/ ctx[6] && /*touched*/ ctx[8]);
			add_location(input, file$4, 24, 4, 525);
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, input, anchor);

			if (!mounted) {
				dispose = [
					listen_dev(input, "input", /*input_handler*/ ctx[9], false, false, false),
					listen_dev(input, "blur", /*blur_handler_1*/ ctx[12], false, false, false)
				];

				mounted = true;
			}
		},
		p: function update(ctx, dirty) {
			if (dirty & /*type*/ 32) {
				attr_dev(input, "type", /*type*/ ctx[5]);
			}

			if (dirty & /*id*/ 4) {
				attr_dev(input, "id", /*id*/ ctx[2]);
			}

			if (dirty & /*value*/ 1 && input.value !== /*value*/ ctx[0]) {
				prop_dev(input, "value", /*value*/ ctx[0]);
			}

			if (dirty & /*valid, touched*/ 320) {
				toggle_class(input, "invalid", !/*valid*/ ctx[6] && /*touched*/ ctx[8]);
			}
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(input);
			mounted = false;
			run_all(dispose);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_else_block$1.name,
		type: "else",
		source: "(24:2) {:else}",
		ctx
	});

	return block;
}

// (16:2) {#if controlType === 'textarea'}
function create_if_block_1$1(ctx) {
	let textarea;
	let mounted;
	let dispose;

	const block = {
		c: function create() {
			textarea = element("textarea");
			this.h();
		},
		l: function claim(nodes) {
			textarea = claim_element(nodes, "TEXTAREA", { rows: true, id: true, class: true });
			children(textarea).forEach(detach_dev);
			this.h();
		},
		h: function hydrate() {
			attr_dev(textarea, "rows", /*rows*/ ctx[4]);
			attr_dev(textarea, "id", /*id*/ ctx[2]);
			attr_dev(textarea, "class", "svelte-1mrfx4j");
			toggle_class(textarea, "invalid", !/*valid*/ ctx[6] && /*touched*/ ctx[8]);
			add_location(textarea, file$4, 16, 4, 366);
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, textarea, anchor);
			set_input_value(textarea, /*value*/ ctx[0]);

			if (!mounted) {
				dispose = [
					listen_dev(textarea, "input", /*textarea_input_handler*/ ctx[10]),
					listen_dev(textarea, "blur", /*blur_handler*/ ctx[11], false, false, false)
				];

				mounted = true;
			}
		},
		p: function update(ctx, dirty) {
			if (dirty & /*rows*/ 16) {
				attr_dev(textarea, "rows", /*rows*/ ctx[4]);
			}

			if (dirty & /*id*/ 4) {
				attr_dev(textarea, "id", /*id*/ ctx[2]);
			}

			if (dirty & /*value*/ 1) {
				set_input_value(textarea, /*value*/ ctx[0]);
			}

			if (dirty & /*valid, touched*/ 320) {
				toggle_class(textarea, "invalid", !/*valid*/ ctx[6] && /*touched*/ ctx[8]);
			}
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(textarea);
			mounted = false;
			run_all(dispose);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_if_block_1$1.name,
		type: "if",
		source: "(16:2) {#if controlType === 'textarea'}",
		ctx
	});

	return block;
}

// (34:2) {#if validityMessage && !valid && touched}
function create_if_block$1(ctx) {
	let p;
	let t;

	const block = {
		c: function create() {
			p = element("p");
			t = text(/*validityMessage*/ ctx[7]);
			this.h();
		},
		l: function claim(nodes) {
			p = claim_element(nodes, "P", { class: true });
			var p_nodes = children(p);
			t = claim_text(p_nodes, /*validityMessage*/ ctx[7]);
			p_nodes.forEach(detach_dev);
			this.h();
		},
		h: function hydrate() {
			attr_dev(p, "class", "error-message svelte-1mrfx4j");
			add_location(p, file$4, 34, 4, 738);
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, p, anchor);
			append_hydration_dev(p, t);
		},
		p: function update(ctx, dirty) {
			if (dirty & /*validityMessage*/ 128) set_data_dev(t, /*validityMessage*/ ctx[7]);
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(p);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_if_block$1.name,
		type: "if",
		source: "(34:2) {#if validityMessage && !valid && touched}",
		ctx
	});

	return block;
}

function create_fragment$4(ctx) {
	let div;
	let label_1;
	let t0;
	let t1;
	let t2;

	function select_block_type(ctx, dirty) {
		if (/*controlType*/ ctx[1] === 'textarea') return create_if_block_1$1;
		return create_else_block$1;
	}

	let current_block_type = select_block_type(ctx);
	let if_block0 = current_block_type(ctx);
	let if_block1 = /*validityMessage*/ ctx[7] && !/*valid*/ ctx[6] && /*touched*/ ctx[8] && create_if_block$1(ctx);

	const block = {
		c: function create() {
			div = element("div");
			label_1 = element("label");
			t0 = text(/*label*/ ctx[3]);
			t1 = space();
			if_block0.c();
			t2 = space();
			if (if_block1) if_block1.c();
			this.h();
		},
		l: function claim(nodes) {
			div = claim_element(nodes, "DIV", { class: true });
			var div_nodes = children(div);
			label_1 = claim_element(div_nodes, "LABEL", { for: true, class: true });
			var label_1_nodes = children(label_1);
			t0 = claim_text(label_1_nodes, /*label*/ ctx[3]);
			label_1_nodes.forEach(detach_dev);
			t1 = claim_space(div_nodes);
			if_block0.l(div_nodes);
			t2 = claim_space(div_nodes);
			if (if_block1) if_block1.l(div_nodes);
			div_nodes.forEach(detach_dev);
			this.h();
		},
		h: function hydrate() {
			attr_dev(label_1, "for", /*id*/ ctx[2]);
			attr_dev(label_1, "class", "svelte-1mrfx4j");
			add_location(label_1, file$4, 14, 2, 293);
			attr_dev(div, "class", "form-control svelte-1mrfx4j");
			add_location(div, file$4, 13, 0, 263);
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, div, anchor);
			append_hydration_dev(div, label_1);
			append_hydration_dev(label_1, t0);
			append_hydration_dev(div, t1);
			if_block0.m(div, null);
			append_hydration_dev(div, t2);
			if (if_block1) if_block1.m(div, null);
		},
		p: function update(ctx, [dirty]) {
			if (dirty & /*label*/ 8) set_data_dev(t0, /*label*/ ctx[3]);

			if (dirty & /*id*/ 4) {
				attr_dev(label_1, "for", /*id*/ ctx[2]);
			}

			if (current_block_type === (current_block_type = select_block_type(ctx)) && if_block0) {
				if_block0.p(ctx, dirty);
			} else {
				if_block0.d(1);
				if_block0 = current_block_type(ctx);

				if (if_block0) {
					if_block0.c();
					if_block0.m(div, t2);
				}
			}

			if (/*validityMessage*/ ctx[7] && !/*valid*/ ctx[6] && /*touched*/ ctx[8]) {
				if (if_block1) {
					if_block1.p(ctx, dirty);
				} else {
					if_block1 = create_if_block$1(ctx);
					if_block1.c();
					if_block1.m(div, null);
				}
			} else if (if_block1) {
				if_block1.d(1);
				if_block1 = null;
			}
		},
		i: noop,
		o: noop,
		d: function destroy(detaching) {
			if (detaching) detach_dev(div);
			if_block0.d();
			if (if_block1) if_block1.d();
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_fragment$4.name,
		type: "component",
		source: "",
		ctx
	});

	return block;
}

function instance$4($$self, $$props, $$invalidate) {
	let { $$slots: slots = {}, $$scope } = $$props;
	validate_slots('TextInput', slots, []);
	let { controlType = null } = $$props;
	let { id } = $$props;
	let { label } = $$props;
	let { rows = null } = $$props;
	let { value } = $$props;
	let { type = 'text' } = $$props;
	let { valid = true } = $$props;
	let { validityMessage = '' } = $$props;
	let touched = false;

	const writable_props = [
		'controlType',
		'id',
		'label',
		'rows',
		'value',
		'type',
		'valid',
		'validityMessage'
	];

	Object.keys($$props).forEach(key => {
		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== '$$' && key !== 'slot') console.warn(`<TextInput> was created with unknown prop '${key}'`);
	});

	function input_handler(event) {
		bubble.call(this, $$self, event);
	}

	function textarea_input_handler() {
		value = this.value;
		$$invalidate(0, value);
	}

	const blur_handler = () => $$invalidate(8, touched = true);
	const blur_handler_1 = () => $$invalidate(8, touched = true);

	$$self.$$set = $$props => {
		if ('controlType' in $$props) $$invalidate(1, controlType = $$props.controlType);
		if ('id' in $$props) $$invalidate(2, id = $$props.id);
		if ('label' in $$props) $$invalidate(3, label = $$props.label);
		if ('rows' in $$props) $$invalidate(4, rows = $$props.rows);
		if ('value' in $$props) $$invalidate(0, value = $$props.value);
		if ('type' in $$props) $$invalidate(5, type = $$props.type);
		if ('valid' in $$props) $$invalidate(6, valid = $$props.valid);
		if ('validityMessage' in $$props) $$invalidate(7, validityMessage = $$props.validityMessage);
	};

	$$self.$capture_state = () => ({
		controlType,
		id,
		label,
		rows,
		value,
		type,
		valid,
		validityMessage,
		touched
	});

	$$self.$inject_state = $$props => {
		if ('controlType' in $$props) $$invalidate(1, controlType = $$props.controlType);
		if ('id' in $$props) $$invalidate(2, id = $$props.id);
		if ('label' in $$props) $$invalidate(3, label = $$props.label);
		if ('rows' in $$props) $$invalidate(4, rows = $$props.rows);
		if ('value' in $$props) $$invalidate(0, value = $$props.value);
		if ('type' in $$props) $$invalidate(5, type = $$props.type);
		if ('valid' in $$props) $$invalidate(6, valid = $$props.valid);
		if ('validityMessage' in $$props) $$invalidate(7, validityMessage = $$props.validityMessage);
		if ('touched' in $$props) $$invalidate(8, touched = $$props.touched);
	};

	if ($$props && "$$inject" in $$props) {
		$$self.$inject_state($$props.$$inject);
	}

	return [
		value,
		controlType,
		id,
		label,
		rows,
		type,
		valid,
		validityMessage,
		touched,
		input_handler,
		textarea_input_handler,
		blur_handler,
		blur_handler_1
	];
}

class TextInput extends SvelteComponentDev {
	constructor(options) {
		super(options);

		init(this, options, instance$4, create_fragment$4, safe_not_equal, {
			controlType: 1,
			id: 2,
			label: 3,
			rows: 4,
			value: 0,
			type: 5,
			valid: 6,
			validityMessage: 7
		});

		dispatch_dev("SvelteRegisterComponent", {
			component: this,
			tagName: "TextInput",
			options,
			id: create_fragment$4.name
		});

		const { ctx } = this.$$;
		const props = options.props || {};

		if (/*id*/ ctx[2] === undefined && !('id' in props)) {
			console.warn("<TextInput> was created without expected prop 'id'");
		}

		if (/*label*/ ctx[3] === undefined && !('label' in props)) {
			console.warn("<TextInput> was created without expected prop 'label'");
		}

		if (/*value*/ ctx[0] === undefined && !('value' in props)) {
			console.warn("<TextInput> was created without expected prop 'value'");
		}
	}

	get controlType() {
		throw new Error("<TextInput>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	set controlType(value) {
		throw new Error("<TextInput>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	get id() {
		throw new Error("<TextInput>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	set id(value) {
		throw new Error("<TextInput>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	get label() {
		throw new Error("<TextInput>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	set label(value) {
		throw new Error("<TextInput>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	get rows() {
		throw new Error("<TextInput>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	set rows(value) {
		throw new Error("<TextInput>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	get value() {
		throw new Error("<TextInput>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	set value(value) {
		throw new Error("<TextInput>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	get type() {
		throw new Error("<TextInput>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	set type(value) {
		throw new Error("<TextInput>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	get valid() {
		throw new Error("<TextInput>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	set valid(value) {
		throw new Error("<TextInput>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	get validityMessage() {
		throw new Error("<TextInput>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	set validityMessage(value) {
		throw new Error("<TextInput>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}
}

/* src\components\UI\Modal.svelte generated by Svelte v3.45.0 */
const file$5 = "src\\components\\UI\\Modal.svelte";
const get_footer_slot_changes = dirty => ({});
const get_footer_slot_context = ctx => ({});

// (19:6) <Button on:click={closeModal}>
function create_default_slot$1(ctx) {
	let t;

	const block = {
		c: function create() {
			t = text("Close");
		},
		l: function claim(nodes) {
			t = claim_text(nodes, "Close");
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, t, anchor);
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(t);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_default_slot$1.name,
		type: "slot",
		source: "(19:6) <Button on:click={closeModal}>",
		ctx
	});

	return block;
}

// (18:24)         
function fallback_block(ctx) {
	let button;
	let current;

	button = new Button({
			props: {
				$$slots: { default: [create_default_slot$1] },
				$$scope: { ctx }
			},
			$$inline: true
		});

	button.$on("click", /*closeModal*/ ctx[1]);

	const block = {
		c: function create() {
			create_component(button.$$.fragment);
		},
		l: function claim(nodes) {
			claim_component(button.$$.fragment, nodes);
		},
		m: function mount(target, anchor) {
			mount_component(button, target, anchor);
			current = true;
		},
		p: function update(ctx, dirty) {
			const button_changes = {};

			if (dirty & /*$$scope*/ 8) {
				button_changes.$$scope = { dirty, ctx };
			}

			button.$set(button_changes);
		},
		i: function intro(local) {
			if (current) return;
			transition_in(button.$$.fragment, local);
			current = true;
		},
		o: function outro(local) {
			transition_out(button.$$.fragment, local);
			current = false;
		},
		d: function destroy(detaching) {
			destroy_component(button, detaching);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: fallback_block.name,
		type: "fallback",
		source: "(18:24)         ",
		ctx
	});

	return block;
}

function create_fragment$5(ctx) {
	let div0;
	let div0_transition;
	let t0;
	let div2;
	let h1;
	let t1;
	let t2;
	let div1;
	let t3;
	let footer;
	let div2_transition;
	let current;
	let mounted;
	let dispose;
	const default_slot_template = /*#slots*/ ctx[2].default;
	const default_slot = create_slot(default_slot_template, ctx, /*$$scope*/ ctx[3], null);
	const footer_slot_template = /*#slots*/ ctx[2].footer;
	const footer_slot = create_slot(footer_slot_template, ctx, /*$$scope*/ ctx[3], get_footer_slot_context);
	const footer_slot_or_fallback = footer_slot || fallback_block(ctx);

	const block = {
		c: function create() {
			div0 = element("div");
			t0 = space();
			div2 = element("div");
			h1 = element("h1");
			t1 = text(/*title*/ ctx[0]);
			t2 = space();
			div1 = element("div");
			if (default_slot) default_slot.c();
			t3 = space();
			footer = element("footer");
			if (footer_slot_or_fallback) footer_slot_or_fallback.c();
			this.h();
		},
		l: function claim(nodes) {
			div0 = claim_element(nodes, "DIV", { class: true });
			children(div0).forEach(detach_dev);
			t0 = claim_space(nodes);
			div2 = claim_element(nodes, "DIV", { class: true });
			var div2_nodes = children(div2);
			h1 = claim_element(div2_nodes, "H1", { class: true });
			var h1_nodes = children(h1);
			t1 = claim_text(h1_nodes, /*title*/ ctx[0]);
			h1_nodes.forEach(detach_dev);
			t2 = claim_space(div2_nodes);
			div1 = claim_element(div2_nodes, "DIV", { class: true });
			var div1_nodes = children(div1);
			if (default_slot) default_slot.l(div1_nodes);
			div1_nodes.forEach(detach_dev);
			t3 = claim_space(div2_nodes);
			footer = claim_element(div2_nodes, "FOOTER", { class: true });
			var footer_nodes = children(footer);
			if (footer_slot_or_fallback) footer_slot_or_fallback.l(footer_nodes);
			footer_nodes.forEach(detach_dev);
			div2_nodes.forEach(detach_dev);
			this.h();
		},
		h: function hydrate() {
			attr_dev(div0, "class", "modal-backdrop svelte-rj5ywu");
			add_location(div0, file$5, 12, 0, 290);
			attr_dev(h1, "class", "svelte-rj5ywu");
			add_location(h1, file$5, 14, 2, 411);
			attr_dev(div1, "class", "content svelte-rj5ywu");
			add_location(div1, file$5, 15, 2, 431);
			attr_dev(footer, "class", "svelte-rj5ywu");
			add_location(footer, file$5, 16, 2, 470);
			attr_dev(div2, "class", "modal svelte-rj5ywu");
			add_location(div2, file$5, 13, 0, 360);
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, div0, anchor);
			insert_hydration_dev(target, t0, anchor);
			insert_hydration_dev(target, div2, anchor);
			append_hydration_dev(div2, h1);
			append_hydration_dev(h1, t1);
			append_hydration_dev(div2, t2);
			append_hydration_dev(div2, div1);

			if (default_slot) {
				default_slot.m(div1, null);
			}

			append_hydration_dev(div2, t3);
			append_hydration_dev(div2, footer);

			if (footer_slot_or_fallback) {
				footer_slot_or_fallback.m(footer, null);
			}

			current = true;

			if (!mounted) {
				dispose = listen_dev(div0, "click", /*closeModal*/ ctx[1], false, false, false);
				mounted = true;
			}
		},
		p: function update(ctx, [dirty]) {
			if (!current || dirty & /*title*/ 1) set_data_dev(t1, /*title*/ ctx[0]);

			if (default_slot) {
				if (default_slot.p && (!current || dirty & /*$$scope*/ 8)) {
					update_slot_base(
						default_slot,
						default_slot_template,
						ctx,
						/*$$scope*/ ctx[3],
						!current
						? get_all_dirty_from_scope(/*$$scope*/ ctx[3])
						: get_slot_changes(default_slot_template, /*$$scope*/ ctx[3], dirty, null),
						null
					);
				}
			}

			if (footer_slot) {
				if (footer_slot.p && (!current || dirty & /*$$scope*/ 8)) {
					update_slot_base(
						footer_slot,
						footer_slot_template,
						ctx,
						/*$$scope*/ ctx[3],
						!current
						? get_all_dirty_from_scope(/*$$scope*/ ctx[3])
						: get_slot_changes(footer_slot_template, /*$$scope*/ ctx[3], dirty, get_footer_slot_changes),
						get_footer_slot_context
					);
				}
			}
		},
		i: function intro(local) {
			if (current) return;

			add_render_callback(() => {
				if (!div0_transition) div0_transition = create_bidirectional_transition(div0, fade, {}, true);
				div0_transition.run(1);
			});

			transition_in(default_slot, local);
			transition_in(footer_slot_or_fallback, local);

			add_render_callback(() => {
				if (!div2_transition) div2_transition = create_bidirectional_transition(div2, fly, { y: 300 }, true);
				div2_transition.run(1);
			});

			current = true;
		},
		o: function outro(local) {
			if (!div0_transition) div0_transition = create_bidirectional_transition(div0, fade, {}, false);
			div0_transition.run(0);
			transition_out(default_slot, local);
			transition_out(footer_slot_or_fallback, local);
			if (!div2_transition) div2_transition = create_bidirectional_transition(div2, fly, { y: 300 }, false);
			div2_transition.run(0);
			current = false;
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(div0);
			if (detaching && div0_transition) div0_transition.end();
			if (detaching) detach_dev(t0);
			if (detaching) detach_dev(div2);
			if (default_slot) default_slot.d(detaching);
			if (footer_slot_or_fallback) footer_slot_or_fallback.d(detaching);
			if (detaching && div2_transition) div2_transition.end();
			mounted = false;
			dispose();
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_fragment$5.name,
		type: "component",
		source: "",
		ctx
	});

	return block;
}

function instance$5($$self, $$props, $$invalidate) {
	let { $$slots: slots = {}, $$scope } = $$props;
	validate_slots('Modal', slots, ['default','footer']);
	let { title } = $$props;
	const dispatch = createEventDispatcher();

	function closeModal() {
		dispatch('cancel');
	}

	const writable_props = ['title'];

	Object.keys($$props).forEach(key => {
		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== '$$' && key !== 'slot') console.warn(`<Modal> was created with unknown prop '${key}'`);
	});

	$$self.$$set = $$props => {
		if ('title' in $$props) $$invalidate(0, title = $$props.title);
		if ('$$scope' in $$props) $$invalidate(3, $$scope = $$props.$$scope);
	};

	$$self.$capture_state = () => ({
		createEventDispatcher,
		fade,
		fly,
		Button,
		title,
		dispatch,
		closeModal
	});

	$$self.$inject_state = $$props => {
		if ('title' in $$props) $$invalidate(0, title = $$props.title);
	};

	if ($$props && "$$inject" in $$props) {
		$$self.$inject_state($$props.$$inject);
	}

	return [title, closeModal, slots, $$scope];
}

class Modal extends SvelteComponentDev {
	constructor(options) {
		super(options);
		init(this, options, instance$5, create_fragment$5, safe_not_equal, { title: 0 });

		dispatch_dev("SvelteRegisterComponent", {
			component: this,
			tagName: "Modal",
			options,
			id: create_fragment$5.name
		});

		const { ctx } = this.$$;
		const props = options.props || {};

		if (/*title*/ ctx[0] === undefined && !('title' in props)) {
			console.warn("<Modal> was created without expected prop 'title'");
		}
	}

	get title() {
		throw new Error("<Modal>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	set title(value) {
		throw new Error("<Modal>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}
}

function notEmpty(val) {
  return val.trim().length === 0;
}

function isValidEmail(val) {
  return new RegExp('/^S+@S+.S+$/').test(val);
}

/* src\components\Meetups\EditMeetup.svelte generated by Svelte v3.45.0 */

const { Error: Error_1$1, console: console_1$1 } = globals;
const file$6 = "src\\components\\Meetups\\EditMeetup.svelte";

// (123:0) <Modal title="Edit Meetup Data" on:cancel>
function create_default_slot_3$1(ctx) {
	let form;
	let textinput0;
	let t0;
	let textinput1;
	let t1;
	let textinput2;
	let t2;
	let textinput3;
	let t3;
	let textinput4;
	let t4;
	let textinput5;
	let updating_value;
	let current;
	let mounted;
	let dispose;

	textinput0 = new TextInput({
			props: {
				id: "title",
				label: "Title",
				valid: /*titleValid*/ ctx[12],
				validityMessage: "Please enter a valid title",
				value: /*title*/ ctx[1]
			},
			$$inline: true
		});

	textinput0.$on("input", /*input_handler*/ ctx[17]);

	textinput1 = new TextInput({
			props: {
				id: "subtitle",
				label: "Subtitle",
				valid: /*subtitleValid*/ ctx[11],
				validityMessage: "Please enter a valid subtitle",
				value: /*subtitle*/ ctx[2]
			},
			$$inline: true
		});

	textinput1.$on("input", /*input_handler_1*/ ctx[18]);

	textinput2 = new TextInput({
			props: {
				id: "address",
				label: "Adress",
				valid: /*addressValid*/ ctx[10],
				validityMessage: "Please enter a valid address",
				value: /*address*/ ctx[3]
			},
			$$inline: true
		});

	textinput2.$on("input", /*input_handler_2*/ ctx[19]);

	textinput3 = new TextInput({
			props: {
				id: "imageUrl",
				label: "Image URL",
				valid: /*imageUrlValid*/ ctx[7],
				validityMessage: "Please enter a valid image url",
				value: /*imageUrl*/ ctx[6]
			},
			$$inline: true
		});

	textinput3.$on("input", /*input_handler_3*/ ctx[20]);

	textinput4 = new TextInput({
			props: {
				id: "email",
				label: "Email",
				valid: /*emailValid*/ ctx[9],
				validityMessage: "Please enter a valid email address",
				type: "email",
				value: /*email*/ ctx[4]
			},
			$$inline: true
		});

	textinput4.$on("input", /*input_handler_4*/ ctx[21]);

	function textinput5_value_binding(value) {
		/*textinput5_value_binding*/ ctx[22](value);
	}

	let textinput5_props = {
		id: "description",
		label: "Description",
		valid: /*descriptionValid*/ ctx[8],
		validityMessage: "Please enter a valid description",
		controlType: "textarea",
		rows: "3"
	};

	if (/*description*/ ctx[5] !== void 0) {
		textinput5_props.value = /*description*/ ctx[5];
	}

	textinput5 = new TextInput({ props: textinput5_props, $$inline: true });
	binding_callbacks.push(() => bind(textinput5, 'value', textinput5_value_binding));

	const block = {
		c: function create() {
			form = element("form");
			create_component(textinput0.$$.fragment);
			t0 = space();
			create_component(textinput1.$$.fragment);
			t1 = space();
			create_component(textinput2.$$.fragment);
			t2 = space();
			create_component(textinput3.$$.fragment);
			t3 = space();
			create_component(textinput4.$$.fragment);
			t4 = space();
			create_component(textinput5.$$.fragment);
			this.h();
		},
		l: function claim(nodes) {
			form = claim_element(nodes, "FORM", { class: true });
			var form_nodes = children(form);
			claim_component(textinput0.$$.fragment, form_nodes);
			t0 = claim_space(form_nodes);
			claim_component(textinput1.$$.fragment, form_nodes);
			t1 = claim_space(form_nodes);
			claim_component(textinput2.$$.fragment, form_nodes);
			t2 = claim_space(form_nodes);
			claim_component(textinput3.$$.fragment, form_nodes);
			t3 = claim_space(form_nodes);
			claim_component(textinput4.$$.fragment, form_nodes);
			t4 = claim_space(form_nodes);
			claim_component(textinput5.$$.fragment, form_nodes);
			form_nodes.forEach(detach_dev);
			this.h();
		},
		h: function hydrate() {
			attr_dev(form, "class", "svelte-no1xoc");
			add_location(form, file$6, 123, 2, 3236);
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, form, anchor);
			mount_component(textinput0, form, null);
			append_hydration_dev(form, t0);
			mount_component(textinput1, form, null);
			append_hydration_dev(form, t1);
			mount_component(textinput2, form, null);
			append_hydration_dev(form, t2);
			mount_component(textinput3, form, null);
			append_hydration_dev(form, t3);
			mount_component(textinput4, form, null);
			append_hydration_dev(form, t4);
			mount_component(textinput5, form, null);
			current = true;

			if (!mounted) {
				dispose = listen_dev(form, "submit", prevent_default(/*submitForm*/ ctx[14]), false, true, false);
				mounted = true;
			}
		},
		p: function update(ctx, dirty) {
			const textinput0_changes = {};
			if (dirty & /*titleValid*/ 4096) textinput0_changes.valid = /*titleValid*/ ctx[12];
			if (dirty & /*title*/ 2) textinput0_changes.value = /*title*/ ctx[1];
			textinput0.$set(textinput0_changes);
			const textinput1_changes = {};
			if (dirty & /*subtitleValid*/ 2048) textinput1_changes.valid = /*subtitleValid*/ ctx[11];
			if (dirty & /*subtitle*/ 4) textinput1_changes.value = /*subtitle*/ ctx[2];
			textinput1.$set(textinput1_changes);
			const textinput2_changes = {};
			if (dirty & /*addressValid*/ 1024) textinput2_changes.valid = /*addressValid*/ ctx[10];
			if (dirty & /*address*/ 8) textinput2_changes.value = /*address*/ ctx[3];
			textinput2.$set(textinput2_changes);
			const textinput3_changes = {};
			if (dirty & /*imageUrlValid*/ 128) textinput3_changes.valid = /*imageUrlValid*/ ctx[7];
			if (dirty & /*imageUrl*/ 64) textinput3_changes.value = /*imageUrl*/ ctx[6];
			textinput3.$set(textinput3_changes);
			const textinput4_changes = {};
			if (dirty & /*emailValid*/ 512) textinput4_changes.valid = /*emailValid*/ ctx[9];
			if (dirty & /*email*/ 16) textinput4_changes.value = /*email*/ ctx[4];
			textinput4.$set(textinput4_changes);
			const textinput5_changes = {};
			if (dirty & /*descriptionValid*/ 256) textinput5_changes.valid = /*descriptionValid*/ ctx[8];

			if (!updating_value && dirty & /*description*/ 32) {
				updating_value = true;
				textinput5_changes.value = /*description*/ ctx[5];
				add_flush_callback(() => updating_value = false);
			}

			textinput5.$set(textinput5_changes);
		},
		i: function intro(local) {
			if (current) return;
			transition_in(textinput0.$$.fragment, local);
			transition_in(textinput1.$$.fragment, local);
			transition_in(textinput2.$$.fragment, local);
			transition_in(textinput3.$$.fragment, local);
			transition_in(textinput4.$$.fragment, local);
			transition_in(textinput5.$$.fragment, local);
			current = true;
		},
		o: function outro(local) {
			transition_out(textinput0.$$.fragment, local);
			transition_out(textinput1.$$.fragment, local);
			transition_out(textinput2.$$.fragment, local);
			transition_out(textinput3.$$.fragment, local);
			transition_out(textinput4.$$.fragment, local);
			transition_out(textinput5.$$.fragment, local);
			current = false;
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(form);
			destroy_component(textinput0);
			destroy_component(textinput1);
			destroy_component(textinput2);
			destroy_component(textinput3);
			destroy_component(textinput4);
			destroy_component(textinput5);
			mounted = false;
			dispose();
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_default_slot_3$1.name,
		type: "slot",
		source: "(123:0) <Modal title=\\\"Edit Meetup Data\\\" on:cancel>",
		ctx
	});

	return block;
}

// (177:4) <Button type="button" mode="outline" on:click={cancel}>
function create_default_slot_2$1(ctx) {
	let t;

	const block = {
		c: function create() {
			t = text("Cancel");
		},
		l: function claim(nodes) {
			t = claim_text(nodes, "Cancel");
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, t, anchor);
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(t);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_default_slot_2$1.name,
		type: "slot",
		source: "(177:4) <Button type=\\\"button\\\" mode=\\\"outline\\\" on:click={cancel}>",
		ctx
	});

	return block;
}

// (178:4) <Button type="button" on:click={submitForm} disabled={!formIsValid}        >
function create_default_slot_1$1(ctx) {
	let t;

	const block = {
		c: function create() {
			t = text("Save");
		},
		l: function claim(nodes) {
			t = claim_text(nodes, "Save");
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, t, anchor);
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(t);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_default_slot_1$1.name,
		type: "slot",
		source: "(178:4) <Button type=\\\"button\\\" on:click={submitForm} disabled={!formIsValid}        >",
		ctx
	});

	return block;
}

// (181:4) {#if id}
function create_if_block$2(ctx) {
	let button;
	let current;

	button = new Button({
			props: {
				type: "button",
				$$slots: { default: [create_default_slot$2] },
				$$scope: { ctx }
			},
			$$inline: true
		});

	button.$on("click", /*deleteMeetup*/ ctx[16]);

	const block = {
		c: function create() {
			create_component(button.$$.fragment);
		},
		l: function claim(nodes) {
			claim_component(button.$$.fragment, nodes);
		},
		m: function mount(target, anchor) {
			mount_component(button, target, anchor);
			current = true;
		},
		p: function update(ctx, dirty) {
			const button_changes = {};

			if (dirty & /*$$scope*/ 33554432) {
				button_changes.$$scope = { dirty, ctx };
			}

			button.$set(button_changes);
		},
		i: function intro(local) {
			if (current) return;
			transition_in(button.$$.fragment, local);
			current = true;
		},
		o: function outro(local) {
			transition_out(button.$$.fragment, local);
			current = false;
		},
		d: function destroy(detaching) {
			destroy_component(button, detaching);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_if_block$2.name,
		type: "if",
		source: "(181:4) {#if id}",
		ctx
	});

	return block;
}

// (182:6) <Button type="button" on:click={deleteMeetup}>
function create_default_slot$2(ctx) {
	let t;

	const block = {
		c: function create() {
			t = text("Delete");
		},
		l: function claim(nodes) {
			t = claim_text(nodes, "Delete");
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, t, anchor);
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(t);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_default_slot$2.name,
		type: "slot",
		source: "(182:6) <Button type=\\\"button\\\" on:click={deleteMeetup}>",
		ctx
	});

	return block;
}

// (176:2) 
function create_footer_slot(ctx) {
	let div;
	let button0;
	let t0;
	let button1;
	let t1;
	let current;

	button0 = new Button({
			props: {
				type: "button",
				mode: "outline",
				$$slots: { default: [create_default_slot_2$1] },
				$$scope: { ctx }
			},
			$$inline: true
		});

	button0.$on("click", /*cancel*/ ctx[15]);

	button1 = new Button({
			props: {
				type: "button",
				disabled: !/*formIsValid*/ ctx[13],
				$$slots: { default: [create_default_slot_1$1] },
				$$scope: { ctx }
			},
			$$inline: true
		});

	button1.$on("click", /*submitForm*/ ctx[14]);
	let if_block = /*id*/ ctx[0] && create_if_block$2(ctx);

	const block = {
		c: function create() {
			div = element("div");
			create_component(button0.$$.fragment);
			t0 = space();
			create_component(button1.$$.fragment);
			t1 = space();
			if (if_block) if_block.c();
			this.h();
		},
		l: function claim(nodes) {
			div = claim_element(nodes, "DIV", { slot: true });
			var div_nodes = children(div);
			claim_component(button0.$$.fragment, div_nodes);
			t0 = claim_space(div_nodes);
			claim_component(button1.$$.fragment, div_nodes);
			t1 = claim_space(div_nodes);
			if (if_block) if_block.l(div_nodes);
			div_nodes.forEach(detach_dev);
			this.h();
		},
		h: function hydrate() {
			attr_dev(div, "slot", "footer");
			add_location(div, file$6, 175, 2, 4715);
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, div, anchor);
			mount_component(button0, div, null);
			append_hydration_dev(div, t0);
			mount_component(button1, div, null);
			append_hydration_dev(div, t1);
			if (if_block) if_block.m(div, null);
			current = true;
		},
		p: function update(ctx, dirty) {
			const button0_changes = {};

			if (dirty & /*$$scope*/ 33554432) {
				button0_changes.$$scope = { dirty, ctx };
			}

			button0.$set(button0_changes);
			const button1_changes = {};
			if (dirty & /*formIsValid*/ 8192) button1_changes.disabled = !/*formIsValid*/ ctx[13];

			if (dirty & /*$$scope*/ 33554432) {
				button1_changes.$$scope = { dirty, ctx };
			}

			button1.$set(button1_changes);

			if (/*id*/ ctx[0]) {
				if (if_block) {
					if_block.p(ctx, dirty);

					if (dirty & /*id*/ 1) {
						transition_in(if_block, 1);
					}
				} else {
					if_block = create_if_block$2(ctx);
					if_block.c();
					transition_in(if_block, 1);
					if_block.m(div, null);
				}
			} else if (if_block) {
				group_outros();

				transition_out(if_block, 1, 1, () => {
					if_block = null;
				});

				check_outros();
			}
		},
		i: function intro(local) {
			if (current) return;
			transition_in(button0.$$.fragment, local);
			transition_in(button1.$$.fragment, local);
			transition_in(if_block);
			current = true;
		},
		o: function outro(local) {
			transition_out(button0.$$.fragment, local);
			transition_out(button1.$$.fragment, local);
			transition_out(if_block);
			current = false;
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(div);
			destroy_component(button0);
			destroy_component(button1);
			if (if_block) if_block.d();
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_footer_slot.name,
		type: "slot",
		source: "(176:2) ",
		ctx
	});

	return block;
}

function create_fragment$6(ctx) {
	let modal;
	let current;

	modal = new Modal({
			props: {
				title: "Edit Meetup Data",
				$$slots: {
					footer: [create_footer_slot],
					default: [create_default_slot_3$1]
				},
				$$scope: { ctx }
			},
			$$inline: true
		});

	modal.$on("cancel", /*cancel_handler*/ ctx[23]);

	const block = {
		c: function create() {
			create_component(modal.$$.fragment);
		},
		l: function claim(nodes) {
			claim_component(modal.$$.fragment, nodes);
		},
		m: function mount(target, anchor) {
			mount_component(modal, target, anchor);
			current = true;
		},
		p: function update(ctx, [dirty]) {
			const modal_changes = {};

			if (dirty & /*$$scope, id, formIsValid, descriptionValid, description, emailValid, email, imageUrlValid, imageUrl, addressValid, address, subtitleValid, subtitle, titleValid, title*/ 33570815) {
				modal_changes.$$scope = { dirty, ctx };
			}

			modal.$set(modal_changes);
		},
		i: function intro(local) {
			if (current) return;
			transition_in(modal.$$.fragment, local);
			current = true;
		},
		o: function outro(local) {
			transition_out(modal.$$.fragment, local);
			current = false;
		},
		d: function destroy(detaching) {
			destroy_component(modal, detaching);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_fragment$6.name,
		type: "component",
		source: "",
		ctx
	});

	return block;
}

function instance$6($$self, $$props, $$invalidate) {
	let titleValid;
	let subtitleValid;
	let addressValid;
	let emailValid;
	let descriptionValid;
	let imageUrlValid;
	let formIsValid;
	let { $$slots: slots = {}, $$scope } = $$props;
	validate_slots('EditMeetup', slots, []);
	let { id = null } = $$props;
	let title = '';
	let subtitle = '';
	let address = '';
	let email = '';
	let description = '';
	let imageUrl = '';

	if (id) {
		const unsubscribe = customMeetupsStore.subscribe(items => {
			const selectedMeetup = items.find(i => i.id === id);
			$$invalidate(1, title = selectedMeetup.title);
			$$invalidate(2, subtitle = selectedMeetup.subtitle);
			$$invalidate(3, address = selectedMeetup.address);
			$$invalidate(4, email = selectedMeetup.contactEmail);
			$$invalidate(5, description = selectedMeetup.description);
			$$invalidate(6, imageUrl = selectedMeetup.imageUrl);
		});

		unsubscribe();
	}

	const dispatch = createEventDispatcher();

	function submitForm() {
		const meetupData = {
			title,
			subtitle,
			address,
			email,
			description,
			imageUrl
		};

		if (id) {
			fetch(`https://svelte-course-doles-default-rtdb.firebaseio.com/meetups/${id}.json`, {
				method: 'PATCH',
				body: JSON.stringify(meetupData),
				headers: { 'Content-Type': 'application/json' }
			}).then(res => {
				if (!res.ok) {
					throw new Error('Failed!');
				}

				customMeetupsStore.updateMeetup(id, meetupData);
			}).catch(err => {
				console.log(err);
			});
		} else {
			fetch('https://svelte-course-doles-default-rtdb.firebaseio.com/meetups.json', {
				method: 'POST',
				body: JSON.stringify({ ...meetupData, isFavorite: false }),
				headers: { 'Content-Type': 'application/json' }
			}).then(res => {
				if (!res.ok) {
					throw new Error('Failed!');
				}

				return res.json();
			}).then(data => {
				customMeetupsStore.addMeetup({
					...meetupData,
					isFavorite: false,
					id: data.name
				});
			}).catch(err => {
				console.log(err);
			});
		}

		dispatch('save');
	}

	function cancel() {
		dispatch('cancel');
	}

	function deleteMeetup() {
		fetch(`https://svelte-course-doles-default-rtdb.firebaseio.com/meetups/${id}.json`, { method: 'DELETE' }).then(res => {
			if (!res.ok) {
				throw new Error('Failed!');
			}

			customMeetupsStore.removeMeetup(id);
		}).catch(err => console.log(err));

		dispatch('save');
	}

	const writable_props = ['id'];

	Object.keys($$props).forEach(key => {
		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== '$$' && key !== 'slot') console_1$1.warn(`<EditMeetup> was created with unknown prop '${key}'`);
	});

	const input_handler = event => $$invalidate(1, title = event.target.value);
	const input_handler_1 = event => $$invalidate(2, subtitle = event.target.value);
	const input_handler_2 = event => $$invalidate(3, address = event.target.value);
	const input_handler_3 = event => $$invalidate(6, imageUrl = event.target.value);
	const input_handler_4 = event => $$invalidate(4, email = event.target.value);

	function textinput5_value_binding(value) {
		description = value;
		$$invalidate(5, description);
	}

	function cancel_handler(event) {
		bubble.call(this, $$self, event);
	}

	$$self.$$set = $$props => {
		if ('id' in $$props) $$invalidate(0, id = $$props.id);
	};

	$$self.$capture_state = () => ({
		meetups: customMeetupsStore,
		createEventDispatcher,
		Button,
		TextInput,
		Modal,
		isValidEmail,
		notEmpty,
		id,
		title,
		subtitle,
		address,
		email,
		description,
		imageUrl,
		dispatch,
		submitForm,
		cancel,
		deleteMeetup,
		imageUrlValid,
		descriptionValid,
		emailValid,
		addressValid,
		subtitleValid,
		titleValid,
		formIsValid
	});

	$$self.$inject_state = $$props => {
		if ('id' in $$props) $$invalidate(0, id = $$props.id);
		if ('title' in $$props) $$invalidate(1, title = $$props.title);
		if ('subtitle' in $$props) $$invalidate(2, subtitle = $$props.subtitle);
		if ('address' in $$props) $$invalidate(3, address = $$props.address);
		if ('email' in $$props) $$invalidate(4, email = $$props.email);
		if ('description' in $$props) $$invalidate(5, description = $$props.description);
		if ('imageUrl' in $$props) $$invalidate(6, imageUrl = $$props.imageUrl);
		if ('imageUrlValid' in $$props) $$invalidate(7, imageUrlValid = $$props.imageUrlValid);
		if ('descriptionValid' in $$props) $$invalidate(8, descriptionValid = $$props.descriptionValid);
		if ('emailValid' in $$props) $$invalidate(9, emailValid = $$props.emailValid);
		if ('addressValid' in $$props) $$invalidate(10, addressValid = $$props.addressValid);
		if ('subtitleValid' in $$props) $$invalidate(11, subtitleValid = $$props.subtitleValid);
		if ('titleValid' in $$props) $$invalidate(12, titleValid = $$props.titleValid);
		if ('formIsValid' in $$props) $$invalidate(13, formIsValid = $$props.formIsValid);
	};

	if ($$props && "$$inject" in $$props) {
		$$self.$inject_state($$props.$$inject);
	}

	$$self.$$.update = () => {
		if ($$self.$$.dirty & /*title*/ 2) {
			 $$invalidate(12, titleValid = !notEmpty(title));
		}

		if ($$self.$$.dirty & /*subtitle*/ 4) {
			 $$invalidate(11, subtitleValid = !notEmpty(subtitle));
		}

		if ($$self.$$.dirty & /*address*/ 8) {
			 $$invalidate(10, addressValid = !notEmpty(address));
		}

		if ($$self.$$.dirty & /*email*/ 16) {
			 $$invalidate(9, emailValid = !isValidEmail(email));
		}

		if ($$self.$$.dirty & /*description*/ 32) {
			 $$invalidate(8, descriptionValid = !notEmpty(description));
		}

		if ($$self.$$.dirty & /*imageUrl*/ 64) {
			 $$invalidate(7, imageUrlValid = !notEmpty(imageUrl));
		}

		if ($$self.$$.dirty & /*titleValid, subtitleValid, addressValid, emailValid, descriptionValid, imageUrlValid*/ 8064) {
			 $$invalidate(13, formIsValid = titleValid && subtitleValid && addressValid && emailValid && descriptionValid && imageUrlValid);
		}
	};

	return [
		id,
		title,
		subtitle,
		address,
		email,
		description,
		imageUrl,
		imageUrlValid,
		descriptionValid,
		emailValid,
		addressValid,
		subtitleValid,
		titleValid,
		formIsValid,
		submitForm,
		cancel,
		deleteMeetup,
		input_handler,
		input_handler_1,
		input_handler_2,
		input_handler_3,
		input_handler_4,
		textinput5_value_binding,
		cancel_handler
	];
}

class EditMeetup extends SvelteComponentDev {
	constructor(options) {
		super(options);
		init(this, options, instance$6, create_fragment$6, safe_not_equal, { id: 0 });

		dispatch_dev("SvelteRegisterComponent", {
			component: this,
			tagName: "EditMeetup",
			options,
			id: create_fragment$6.name
		});
	}

	get id() {
		throw new Error_1$1("<EditMeetup>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	set id(value) {
		throw new Error_1$1("<EditMeetup>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}
}

/* src\routes\index.svelte generated by Svelte v3.45.0 */

const { Error: Error_1$2, console: console_1$2 } = globals;
const file$7 = "src\\routes\\index.svelte";

function get_each_context(ctx, list, i) {
	const child_ctx = ctx.slice();
	child_ctx[13] = list[i];
	return child_ctx;
}

// (92:0) {#if editMode === 'edit'}
function create_if_block_2(ctx) {
	let editmeetup;
	let current;

	editmeetup = new EditMeetup({
			props: { id: /*editedId*/ ctx[1] },
			$$inline: true
		});

	editmeetup.$on("save", /*savedMeetup*/ ctx[5]);
	editmeetup.$on("cancel", /*cancelEdit*/ ctx[6]);

	const block = {
		c: function create() {
			create_component(editmeetup.$$.fragment);
		},
		l: function claim(nodes) {
			claim_component(editmeetup.$$.fragment, nodes);
		},
		m: function mount(target, anchor) {
			mount_component(editmeetup, target, anchor);
			current = true;
		},
		p: function update(ctx, dirty) {
			const editmeetup_changes = {};
			if (dirty & /*editedId*/ 2) editmeetup_changes.id = /*editedId*/ ctx[1];
			editmeetup.$set(editmeetup_changes);
		},
		i: function intro(local) {
			if (current) return;
			transition_in(editmeetup.$$.fragment, local);
			current = true;
		},
		o: function outro(local) {
			transition_out(editmeetup.$$.fragment, local);
			current = false;
		},
		d: function destroy(detaching) {
			destroy_component(editmeetup, detaching);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_if_block_2.name,
		type: "if",
		source: "(92:0) {#if editMode === 'edit'}",
		ctx
	});

	return block;
}

// (97:0) {:else}
function create_else_block$2(ctx) {
	let section0;
	let meetupfilter;
	let t0;
	let button;
	let t1;
	let t2;
	let section1;
	let each_blocks = [];
	let each_1_lookup = new Map();
	let current;
	meetupfilter = new MeetupFilter({ $$inline: true });
	meetupfilter.$on("select", /*setFilter*/ ctx[4]);

	button = new Button({
			props: {
				$$slots: { default: [create_default_slot$3] },
				$$scope: { ctx }
			},
			$$inline: true
		});

	button.$on("click", /*startAdd*/ ctx[8]);
	let if_block = /*filteredMeetups*/ ctx[2].length === 0 && create_if_block_1$2(ctx);
	let each_value = /*filteredMeetups*/ ctx[2];
	validate_each_argument(each_value);
	const get_key = ctx => /*meetup*/ ctx[13].id;
	validate_each_keys(ctx, each_value, get_each_context, get_key);

	for (let i = 0; i < each_value.length; i += 1) {
		let child_ctx = get_each_context(ctx, each_value, i);
		let key = get_key(child_ctx);
		each_1_lookup.set(key, each_blocks[i] = create_each_block(key, child_ctx));
	}

	const block = {
		c: function create() {
			section0 = element("section");
			create_component(meetupfilter.$$.fragment);
			t0 = space();
			create_component(button.$$.fragment);
			t1 = space();
			if (if_block) if_block.c();
			t2 = space();
			section1 = element("section");

			for (let i = 0; i < each_blocks.length; i += 1) {
				each_blocks[i].c();
			}

			this.h();
		},
		l: function claim(nodes) {
			section0 = claim_element(nodes, "SECTION", { id: true, class: true });
			var section0_nodes = children(section0);
			claim_component(meetupfilter.$$.fragment, section0_nodes);
			t0 = claim_space(section0_nodes);
			claim_component(button.$$.fragment, section0_nodes);
			section0_nodes.forEach(detach_dev);
			t1 = claim_space(nodes);
			if (if_block) if_block.l(nodes);
			t2 = claim_space(nodes);
			section1 = claim_element(nodes, "SECTION", { id: true, class: true });
			var section1_nodes = children(section1);

			for (let i = 0; i < each_blocks.length; i += 1) {
				each_blocks[i].l(section1_nodes);
			}

			section1_nodes.forEach(detach_dev);
			this.h();
		},
		h: function hydrate() {
			attr_dev(section0, "id", "meetup-controls");
			attr_dev(section0, "class", "svelte-1pg00w7");
			add_location(section0, file$7, 97, 2, 2427);
			attr_dev(section1, "id", "meetups");
			attr_dev(section1, "class", "svelte-1pg00w7");
			add_location(section1, file$7, 104, 2, 2686);
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, section0, anchor);
			mount_component(meetupfilter, section0, null);
			append_hydration_dev(section0, t0);
			mount_component(button, section0, null);
			insert_hydration_dev(target, t1, anchor);
			if (if_block) if_block.m(target, anchor);
			insert_hydration_dev(target, t2, anchor);
			insert_hydration_dev(target, section1, anchor);

			for (let i = 0; i < each_blocks.length; i += 1) {
				each_blocks[i].m(section1, null);
			}

			current = true;
		},
		p: function update(ctx, dirty) {
			const button_changes = {};

			if (dirty & /*$$scope*/ 65536) {
				button_changes.$$scope = { dirty, ctx };
			}

			button.$set(button_changes);

			if (/*filteredMeetups*/ ctx[2].length === 0) {
				if (if_block) ; else {
					if_block = create_if_block_1$2(ctx);
					if_block.c();
					if_block.m(t2.parentNode, t2);
				}
			} else if (if_block) {
				if_block.d(1);
				if_block = null;
			}

			if (dirty & /*filteredMeetups, startEdit*/ 132) {
				each_value = /*filteredMeetups*/ ctx[2];
				validate_each_argument(each_value);
				group_outros();
				for (let i = 0; i < each_blocks.length; i += 1) each_blocks[i].r();
				validate_each_keys(ctx, each_value, get_each_context, get_key);
				each_blocks = update_keyed_each(each_blocks, dirty, get_key, 1, ctx, each_value, each_1_lookup, section1, fix_and_outro_and_destroy_block, create_each_block, null, get_each_context);
				for (let i = 0; i < each_blocks.length; i += 1) each_blocks[i].a();
				check_outros();
			}
		},
		i: function intro(local) {
			if (current) return;
			transition_in(meetupfilter.$$.fragment, local);
			transition_in(button.$$.fragment, local);

			for (let i = 0; i < each_value.length; i += 1) {
				transition_in(each_blocks[i]);
			}

			current = true;
		},
		o: function outro(local) {
			transition_out(meetupfilter.$$.fragment, local);
			transition_out(button.$$.fragment, local);

			for (let i = 0; i < each_blocks.length; i += 1) {
				transition_out(each_blocks[i]);
			}

			current = false;
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(section0);
			destroy_component(meetupfilter);
			destroy_component(button);
			if (detaching) detach_dev(t1);
			if (if_block) if_block.d(detaching);
			if (detaching) detach_dev(t2);
			if (detaching) detach_dev(section1);

			for (let i = 0; i < each_blocks.length; i += 1) {
				each_blocks[i].d();
			}
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_else_block$2.name,
		type: "else",
		source: "(97:0) {:else}",
		ctx
	});

	return block;
}

// (95:0) {#if isLoading}
function create_if_block$3(ctx) {
	let spinner;
	let current;
	spinner = new Spinner({ $$inline: true });

	const block = {
		c: function create() {
			create_component(spinner.$$.fragment);
		},
		l: function claim(nodes) {
			claim_component(spinner.$$.fragment, nodes);
		},
		m: function mount(target, anchor) {
			mount_component(spinner, target, anchor);
			current = true;
		},
		p: noop,
		i: function intro(local) {
			if (current) return;
			transition_in(spinner.$$.fragment, local);
			current = true;
		},
		o: function outro(local) {
			transition_out(spinner.$$.fragment, local);
			current = false;
		},
		d: function destroy(detaching) {
			destroy_component(spinner, detaching);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_if_block$3.name,
		type: "if",
		source: "(95:0) {#if isLoading}",
		ctx
	});

	return block;
}

// (100:4) <Button on:click={startAdd}>
function create_default_slot$3(ctx) {
	let t;

	const block = {
		c: function create() {
			t = text("New Meetup");
		},
		l: function claim(nodes) {
			t = claim_text(nodes, "New Meetup");
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, t, anchor);
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(t);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_default_slot$3.name,
		type: "slot",
		source: "(100:4) <Button on:click={startAdd}>",
		ctx
	});

	return block;
}

// (102:2) {#if filteredMeetups.length === 0}
function create_if_block_1$2(ctx) {
	let p;
	let t;

	const block = {
		c: function create() {
			p = element("p");
			t = text("No Meetups, you may start adding some.");
			this.h();
		},
		l: function claim(nodes) {
			p = claim_element(nodes, "P", { id: true, class: true });
			var p_nodes = children(p);
			t = claim_text(p_nodes, "No Meetups, you may start adding some.");
			p_nodes.forEach(detach_dev);
			this.h();
		},
		h: function hydrate() {
			attr_dev(p, "id", "no-meetups");
			attr_dev(p, "class", "svelte-1pg00w7");
			add_location(p, file$7, 102, 4, 2612);
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, p, anchor);
			append_hydration_dev(p, t);
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(p);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_if_block_1$2.name,
		type: "if",
		source: "(102:2) {#if filteredMeetups.length === 0}",
		ctx
	});

	return block;
}

// (106:4) {#each filteredMeetups as meetup (meetup.id)}
function create_each_block(key_1, ctx) {
	let div;
	let meetupitem;
	let t;
	let div_transition;
	let rect;
	let stop_animation = noop;
	let current;

	meetupitem = new MeetupItem({
			props: {
				id: /*meetup*/ ctx[13].id,
				title: /*meetup*/ ctx[13].title,
				subtitle: /*meetup*/ ctx[13].subtitle,
				description: /*meetup*/ ctx[13].description,
				imageUrl: /*meetup*/ ctx[13].imageUrl,
				address: /*meetup*/ ctx[13].description,
				email: /*meetup*/ ctx[13].contactEmail,
				isFav: /*meetup*/ ctx[13].isFavorite
			},
			$$inline: true
		});

	meetupitem.$on("edit", /*startEdit*/ ctx[7]);

	const block = {
		key: key_1,
		first: null,
		c: function create() {
			div = element("div");
			create_component(meetupitem.$$.fragment);
			t = space();
			this.h();
		},
		l: function claim(nodes) {
			div = claim_element(nodes, "DIV", {});
			var div_nodes = children(div);
			claim_component(meetupitem.$$.fragment, div_nodes);
			t = claim_space(div_nodes);
			div_nodes.forEach(detach_dev);
			this.h();
		},
		h: function hydrate() {
			add_location(div, file$7, 106, 6, 2767);
			this.first = div;
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, div, anchor);
			mount_component(meetupitem, div, null);
			append_hydration_dev(div, t);
			current = true;
		},
		p: function update(new_ctx, dirty) {
			ctx = new_ctx;
			const meetupitem_changes = {};
			if (dirty & /*filteredMeetups*/ 4) meetupitem_changes.id = /*meetup*/ ctx[13].id;
			if (dirty & /*filteredMeetups*/ 4) meetupitem_changes.title = /*meetup*/ ctx[13].title;
			if (dirty & /*filteredMeetups*/ 4) meetupitem_changes.subtitle = /*meetup*/ ctx[13].subtitle;
			if (dirty & /*filteredMeetups*/ 4) meetupitem_changes.description = /*meetup*/ ctx[13].description;
			if (dirty & /*filteredMeetups*/ 4) meetupitem_changes.imageUrl = /*meetup*/ ctx[13].imageUrl;
			if (dirty & /*filteredMeetups*/ 4) meetupitem_changes.address = /*meetup*/ ctx[13].description;
			if (dirty & /*filteredMeetups*/ 4) meetupitem_changes.email = /*meetup*/ ctx[13].contactEmail;
			if (dirty & /*filteredMeetups*/ 4) meetupitem_changes.isFav = /*meetup*/ ctx[13].isFavorite;
			meetupitem.$set(meetupitem_changes);
		},
		r: function measure() {
			rect = div.getBoundingClientRect();
		},
		f: function fix() {
			fix_position(div);
			stop_animation();
			add_transform(div, rect);
		},
		a: function animate() {
			stop_animation();
			stop_animation = create_animation(div, rect, flip, { duration: 300 });
		},
		i: function intro(local) {
			if (current) return;
			transition_in(meetupitem.$$.fragment, local);

			add_render_callback(() => {
				if (!div_transition) div_transition = create_bidirectional_transition(div, scale, {}, true);
				div_transition.run(1);
			});

			current = true;
		},
		o: function outro(local) {
			transition_out(meetupitem.$$.fragment, local);
			if (!div_transition) div_transition = create_bidirectional_transition(div, scale, {}, false);
			div_transition.run(0);
			current = false;
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(div);
			destroy_component(meetupitem);
			if (detaching && div_transition) div_transition.end();
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_each_block.name,
		type: "each",
		source: "(106:4) {#each filteredMeetups as meetup (meetup.id)}",
		ctx
	});

	return block;
}

function create_fragment$7(ctx) {
	let t0;
	let t1;
	let current_block_type_index;
	let if_block1;
	let if_block1_anchor;
	let current;
	let if_block0 = /*editMode*/ ctx[0] === 'edit' && create_if_block_2(ctx);
	const if_block_creators = [create_if_block$3, create_else_block$2];
	const if_blocks = [];

	function select_block_type(ctx, dirty) {
		if (/*isLoading*/ ctx[3]) return 0;
		return 1;
	}

	current_block_type_index = select_block_type(ctx);
	if_block1 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);

	const block = {
		c: function create() {
			t0 = space();
			if (if_block0) if_block0.c();
			t1 = space();
			if_block1.c();
			if_block1_anchor = empty();
			this.h();
		},
		l: function claim(nodes) {
			const head_nodes = query_selector_all('[data-svelte=\"svelte-jjer0t\"]', document.head);
			head_nodes.forEach(detach_dev);
			t0 = claim_space(nodes);
			if (if_block0) if_block0.l(nodes);
			t1 = claim_space(nodes);
			if_block1.l(nodes);
			if_block1_anchor = empty();
			this.h();
		},
		h: function hydrate() {
			document.title = "All Meetups";
		},
		m: function mount(target, anchor) {
			insert_hydration_dev(target, t0, anchor);
			if (if_block0) if_block0.m(target, anchor);
			insert_hydration_dev(target, t1, anchor);
			if_blocks[current_block_type_index].m(target, anchor);
			insert_hydration_dev(target, if_block1_anchor, anchor);
			current = true;
		},
		p: function update(ctx, [dirty]) {
			if (/*editMode*/ ctx[0] === 'edit') {
				if (if_block0) {
					if_block0.p(ctx, dirty);

					if (dirty & /*editMode*/ 1) {
						transition_in(if_block0, 1);
					}
				} else {
					if_block0 = create_if_block_2(ctx);
					if_block0.c();
					transition_in(if_block0, 1);
					if_block0.m(t1.parentNode, t1);
				}
			} else if (if_block0) {
				group_outros();

				transition_out(if_block0, 1, 1, () => {
					if_block0 = null;
				});

				check_outros();
			}

			if_block1.p(ctx, dirty);
		},
		i: function intro(local) {
			if (current) return;
			transition_in(if_block0);
			transition_in(if_block1);
			current = true;
		},
		o: function outro(local) {
			transition_out(if_block0);
			transition_out(if_block1);
			current = false;
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(t0);
			if (if_block0) if_block0.d(detaching);
			if (detaching) detach_dev(t1);
			if_blocks[current_block_type_index].d(detaching);
			if (detaching) detach_dev(if_block1_anchor);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_fragment$7.name,
		type: "component",
		source: "",
		ctx
	});

	return block;
}

function preload(page) {
	console.log(page);

	return this.fetch('https://svelte-course-doles-default-rtdb.firebaseio.com/meetups.json').then(res => {
		if (!res.ok) {
			throw new Error('Fetching meetups failed, please try again later.');
		}

		return res.json();
	}).then(data => {
		const fetchedMeetups = [];

		for (const key in data) {
			fetchedMeetups.push({ id: key, ...data[key] });
		}

		return { fetchedMeetups: fetchedMeetups.reverse() };
	}).catch(err => {
		error = err;
		console.log(err);
		this.error(500, 'Could note fetch meetups');
	});
}

function instance$7($$self, $$props, $$invalidate) {
	let filteredMeetups;
	let { $$slots: slots = {}, $$scope } = $$props;
	validate_slots('Routes', slots, []);
	let { fetchedMeetups } = $$props;
	let editMode;
	let editedId;
	let isLoading;
	let favsOnly = false;
	let unsubscribe;
	const dispatch = createEventDispatcher();

	onMount(() => {
		customMeetupsStore.setMeetups(fetchedMeetups);

		unsubscribe = customMeetupsStore.subscribe(items => {
			$$invalidate(9, fetchedMeetups = items);
		});
	});

	onDestroy(() => {
		if (unsubscribe) {
			unsubscribe();
		}
	});

	function setFilter(event) {
		$$invalidate(10, favsOnly = event.detail === 1);
	}

	function savedMeetup(event) {
		$$invalidate(0, editMode = null);
	}

	function cancelEdit() {
		$$invalidate(0, editMode = null);
		$$invalidate(1, editedId = null);
	}

	function startEdit(event) {
		$$invalidate(0, editMode = 'edit');
		$$invalidate(1, editedId = event.detail);
	}

	function startAdd(event) {
		$$invalidate(0, editMode = 'edit');
	}

	const writable_props = ['fetchedMeetups'];

	Object.keys($$props).forEach(key => {
		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== '$$' && key !== 'slot') console_1$2.warn(`<Routes> was created with unknown prop '${key}'`);
	});

	$$self.$$set = $$props => {
		if ('fetchedMeetups' in $$props) $$invalidate(9, fetchedMeetups = $$props.fetchedMeetups);
	};

	$$self.$capture_state = () => ({
		preload,
		createEventDispatcher,
		onDestroy,
		onMount,
		scale,
		flip,
		meetups: customMeetupsStore,
		MeetupItem,
		MeetupFilter,
		Button,
		EditMeetup,
		Spinner,
		fetchedMeetups,
		editMode,
		editedId,
		isLoading,
		favsOnly,
		unsubscribe,
		dispatch,
		setFilter,
		savedMeetup,
		cancelEdit,
		startEdit,
		startAdd,
		filteredMeetups
	});

	$$self.$inject_state = $$props => {
		if ('fetchedMeetups' in $$props) $$invalidate(9, fetchedMeetups = $$props.fetchedMeetups);
		if ('editMode' in $$props) $$invalidate(0, editMode = $$props.editMode);
		if ('editedId' in $$props) $$invalidate(1, editedId = $$props.editedId);
		if ('isLoading' in $$props) $$invalidate(3, isLoading = $$props.isLoading);
		if ('favsOnly' in $$props) $$invalidate(10, favsOnly = $$props.favsOnly);
		if ('unsubscribe' in $$props) unsubscribe = $$props.unsubscribe;
		if ('filteredMeetups' in $$props) $$invalidate(2, filteredMeetups = $$props.filteredMeetups);
	};

	if ($$props && "$$inject" in $$props) {
		$$self.$inject_state($$props.$$inject);
	}

	$$self.$$.update = () => {
		if ($$self.$$.dirty & /*favsOnly, fetchedMeetups*/ 1536) {
			 $$invalidate(2, filteredMeetups = favsOnly
			? fetchedMeetups.filter(m => m.isFavorite)
			: fetchedMeetups);
		}
	};

	return [
		editMode,
		editedId,
		filteredMeetups,
		isLoading,
		setFilter,
		savedMeetup,
		cancelEdit,
		startEdit,
		startAdd,
		fetchedMeetups,
		favsOnly
	];
}

class Routes extends SvelteComponentDev {
	constructor(options) {
		super(options);
		init(this, options, instance$7, create_fragment$7, safe_not_equal, { fetchedMeetups: 9 });

		dispatch_dev("SvelteRegisterComponent", {
			component: this,
			tagName: "Routes",
			options,
			id: create_fragment$7.name
		});

		const { ctx } = this.$$;
		const props = options.props || {};

		if (/*fetchedMeetups*/ ctx[9] === undefined && !('fetchedMeetups' in props)) {
			console_1$2.warn("<Routes> was created without expected prop 'fetchedMeetups'");
		}
	}

	get fetchedMeetups() {
		throw new Error_1$2("<Routes>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}

	set fetchedMeetups(value) {
		throw new Error_1$2("<Routes>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
	}
}

export default Routes;
export { preload };
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguMDZjMzkyYzguanMiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdmVsdGUvZWFzaW5nL2luZGV4Lm1qcyIsIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdmVsdGUvdHJhbnNpdGlvbi9pbmRleC5tanMiLCIuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3ZlbHRlL2FuaW1hdGUvaW5kZXgubWpzIiwiLi4vLi4vLi4vc3JjL21ldHR1cHMtc3RvcmUuanMiLCIuLi8uLi8uLi9zcmMvY29tcG9uZW50cy9VSS9CYWRnZS5zdmVsdGUiLCIuLi8uLi8uLi9zcmMvY29tcG9uZW50cy9VSS9TcGlubmVyLnN2ZWx0ZSIsIi4uLy4uLy4uL3NyYy9jb21wb25lbnRzL01lZXR1cHMvTWVldHVwSXRlbS5zdmVsdGUiLCIuLi8uLi8uLi9zcmMvY29tcG9uZW50cy9NZWV0dXBzL01lZXR1cEZpbHRlci5zdmVsdGUiLCIuLi8uLi8uLi9zcmMvY29tcG9uZW50cy9VSS9UZXh0SW5wdXQuc3ZlbHRlIiwiLi4vLi4vLi4vc3JjL2NvbXBvbmVudHMvVUkvTW9kYWwuc3ZlbHRlIiwiLi4vLi4vLi4vc3JjL2hlbHBlcnMvdmFsaWRhdGlvbi5qcyIsIi4uLy4uLy4uL3NyYy9jb21wb25lbnRzL01lZXR1cHMvRWRpdE1lZXR1cC5zdmVsdGUiLCIuLi8uLi8uLi9zcmMvcm91dGVzL2luZGV4LnN2ZWx0ZSJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgeyBpZGVudGl0eSBhcyBsaW5lYXIgfSBmcm9tICcuLi9pbnRlcm5hbC9pbmRleC5tanMnO1xuXG4vKlxuQWRhcHRlZCBmcm9tIGh0dHBzOi8vZ2l0aHViLmNvbS9tYXR0ZGVzbFxuRGlzdHJpYnV0ZWQgdW5kZXIgTUlUIExpY2Vuc2UgaHR0cHM6Ly9naXRodWIuY29tL21hdHRkZXNsL2Vhc2VzL2Jsb2IvbWFzdGVyL0xJQ0VOU0UubWRcbiovXG5mdW5jdGlvbiBiYWNrSW5PdXQodCkge1xuICAgIGNvbnN0IHMgPSAxLjcwMTU4ICogMS41MjU7XG4gICAgaWYgKCh0ICo9IDIpIDwgMSlcbiAgICAgICAgcmV0dXJuIDAuNSAqICh0ICogdCAqICgocyArIDEpICogdCAtIHMpKTtcbiAgICByZXR1cm4gMC41ICogKCh0IC09IDIpICogdCAqICgocyArIDEpICogdCArIHMpICsgMik7XG59XG5mdW5jdGlvbiBiYWNrSW4odCkge1xuICAgIGNvbnN0IHMgPSAxLjcwMTU4O1xuICAgIHJldHVybiB0ICogdCAqICgocyArIDEpICogdCAtIHMpO1xufVxuZnVuY3Rpb24gYmFja091dCh0KSB7XG4gICAgY29uc3QgcyA9IDEuNzAxNTg7XG4gICAgcmV0dXJuIC0tdCAqIHQgKiAoKHMgKyAxKSAqIHQgKyBzKSArIDE7XG59XG5mdW5jdGlvbiBib3VuY2VPdXQodCkge1xuICAgIGNvbnN0IGEgPSA0LjAgLyAxMS4wO1xuICAgIGNvbnN0IGIgPSA4LjAgLyAxMS4wO1xuICAgIGNvbnN0IGMgPSA5LjAgLyAxMC4wO1xuICAgIGNvbnN0IGNhID0gNDM1Ni4wIC8gMzYxLjA7XG4gICAgY29uc3QgY2IgPSAzNTQ0Mi4wIC8gMTgwNS4wO1xuICAgIGNvbnN0IGNjID0gMTYwNjEuMCAvIDE4MDUuMDtcbiAgICBjb25zdCB0MiA9IHQgKiB0O1xuICAgIHJldHVybiB0IDwgYVxuICAgICAgICA/IDcuNTYyNSAqIHQyXG4gICAgICAgIDogdCA8IGJcbiAgICAgICAgICAgID8gOS4wNzUgKiB0MiAtIDkuOSAqIHQgKyAzLjRcbiAgICAgICAgICAgIDogdCA8IGNcbiAgICAgICAgICAgICAgICA/IGNhICogdDIgLSBjYiAqIHQgKyBjY1xuICAgICAgICAgICAgICAgIDogMTAuOCAqIHQgKiB0IC0gMjAuNTIgKiB0ICsgMTAuNzI7XG59XG5mdW5jdGlvbiBib3VuY2VJbk91dCh0KSB7XG4gICAgcmV0dXJuIHQgPCAwLjVcbiAgICAgICAgPyAwLjUgKiAoMS4wIC0gYm91bmNlT3V0KDEuMCAtIHQgKiAyLjApKVxuICAgICAgICA6IDAuNSAqIGJvdW5jZU91dCh0ICogMi4wIC0gMS4wKSArIDAuNTtcbn1cbmZ1bmN0aW9uIGJvdW5jZUluKHQpIHtcbiAgICByZXR1cm4gMS4wIC0gYm91bmNlT3V0KDEuMCAtIHQpO1xufVxuZnVuY3Rpb24gY2lyY0luT3V0KHQpIHtcbiAgICBpZiAoKHQgKj0gMikgPCAxKVxuICAgICAgICByZXR1cm4gLTAuNSAqIChNYXRoLnNxcnQoMSAtIHQgKiB0KSAtIDEpO1xuICAgIHJldHVybiAwLjUgKiAoTWF0aC5zcXJ0KDEgLSAodCAtPSAyKSAqIHQpICsgMSk7XG59XG5mdW5jdGlvbiBjaXJjSW4odCkge1xuICAgIHJldHVybiAxLjAgLSBNYXRoLnNxcnQoMS4wIC0gdCAqIHQpO1xufVxuZnVuY3Rpb24gY2lyY091dCh0KSB7XG4gICAgcmV0dXJuIE1hdGguc3FydCgxIC0gLS10ICogdCk7XG59XG5mdW5jdGlvbiBjdWJpY0luT3V0KHQpIHtcbiAgICByZXR1cm4gdCA8IDAuNSA/IDQuMCAqIHQgKiB0ICogdCA6IDAuNSAqIE1hdGgucG93KDIuMCAqIHQgLSAyLjAsIDMuMCkgKyAxLjA7XG59XG5mdW5jdGlvbiBjdWJpY0luKHQpIHtcbiAgICByZXR1cm4gdCAqIHQgKiB0O1xufVxuZnVuY3Rpb24gY3ViaWNPdXQodCkge1xuICAgIGNvbnN0IGYgPSB0IC0gMS4wO1xuICAgIHJldHVybiBmICogZiAqIGYgKyAxLjA7XG59XG5mdW5jdGlvbiBlbGFzdGljSW5PdXQodCkge1xuICAgIHJldHVybiB0IDwgMC41XG4gICAgICAgID8gMC41ICpcbiAgICAgICAgICAgIE1hdGguc2luKCgoKzEzLjAgKiBNYXRoLlBJKSAvIDIpICogMi4wICogdCkgKlxuICAgICAgICAgICAgTWF0aC5wb3coMi4wLCAxMC4wICogKDIuMCAqIHQgLSAxLjApKVxuICAgICAgICA6IDAuNSAqXG4gICAgICAgICAgICBNYXRoLnNpbigoKC0xMy4wICogTWF0aC5QSSkgLyAyKSAqICgyLjAgKiB0IC0gMS4wICsgMS4wKSkgKlxuICAgICAgICAgICAgTWF0aC5wb3coMi4wLCAtMTAuMCAqICgyLjAgKiB0IC0gMS4wKSkgK1xuICAgICAgICAgICAgMS4wO1xufVxuZnVuY3Rpb24gZWxhc3RpY0luKHQpIHtcbiAgICByZXR1cm4gTWF0aC5zaW4oKDEzLjAgKiB0ICogTWF0aC5QSSkgLyAyKSAqIE1hdGgucG93KDIuMCwgMTAuMCAqICh0IC0gMS4wKSk7XG59XG5mdW5jdGlvbiBlbGFzdGljT3V0KHQpIHtcbiAgICByZXR1cm4gKE1hdGguc2luKCgtMTMuMCAqICh0ICsgMS4wKSAqIE1hdGguUEkpIC8gMikgKiBNYXRoLnBvdygyLjAsIC0xMC4wICogdCkgKyAxLjApO1xufVxuZnVuY3Rpb24gZXhwb0luT3V0KHQpIHtcbiAgICByZXR1cm4gdCA9PT0gMC4wIHx8IHQgPT09IDEuMFxuICAgICAgICA/IHRcbiAgICAgICAgOiB0IDwgMC41XG4gICAgICAgICAgICA/ICswLjUgKiBNYXRoLnBvdygyLjAsIDIwLjAgKiB0IC0gMTAuMClcbiAgICAgICAgICAgIDogLTAuNSAqIE1hdGgucG93KDIuMCwgMTAuMCAtIHQgKiAyMC4wKSArIDEuMDtcbn1cbmZ1bmN0aW9uIGV4cG9Jbih0KSB7XG4gICAgcmV0dXJuIHQgPT09IDAuMCA/IHQgOiBNYXRoLnBvdygyLjAsIDEwLjAgKiAodCAtIDEuMCkpO1xufVxuZnVuY3Rpb24gZXhwb091dCh0KSB7XG4gICAgcmV0dXJuIHQgPT09IDEuMCA/IHQgOiAxLjAgLSBNYXRoLnBvdygyLjAsIC0xMC4wICogdCk7XG59XG5mdW5jdGlvbiBxdWFkSW5PdXQodCkge1xuICAgIHQgLz0gMC41O1xuICAgIGlmICh0IDwgMSlcbiAgICAgICAgcmV0dXJuIDAuNSAqIHQgKiB0O1xuICAgIHQtLTtcbiAgICByZXR1cm4gLTAuNSAqICh0ICogKHQgLSAyKSAtIDEpO1xufVxuZnVuY3Rpb24gcXVhZEluKHQpIHtcbiAgICByZXR1cm4gdCAqIHQ7XG59XG5mdW5jdGlvbiBxdWFkT3V0KHQpIHtcbiAgICByZXR1cm4gLXQgKiAodCAtIDIuMCk7XG59XG5mdW5jdGlvbiBxdWFydEluT3V0KHQpIHtcbiAgICByZXR1cm4gdCA8IDAuNVxuICAgICAgICA/ICs4LjAgKiBNYXRoLnBvdyh0LCA0LjApXG4gICAgICAgIDogLTguMCAqIE1hdGgucG93KHQgLSAxLjAsIDQuMCkgKyAxLjA7XG59XG5mdW5jdGlvbiBxdWFydEluKHQpIHtcbiAgICByZXR1cm4gTWF0aC5wb3codCwgNC4wKTtcbn1cbmZ1bmN0aW9uIHF1YXJ0T3V0KHQpIHtcbiAgICByZXR1cm4gTWF0aC5wb3codCAtIDEuMCwgMy4wKSAqICgxLjAgLSB0KSArIDEuMDtcbn1cbmZ1bmN0aW9uIHF1aW50SW5PdXQodCkge1xuICAgIGlmICgodCAqPSAyKSA8IDEpXG4gICAgICAgIHJldHVybiAwLjUgKiB0ICogdCAqIHQgKiB0ICogdDtcbiAgICByZXR1cm4gMC41ICogKCh0IC09IDIpICogdCAqIHQgKiB0ICogdCArIDIpO1xufVxuZnVuY3Rpb24gcXVpbnRJbih0KSB7XG4gICAgcmV0dXJuIHQgKiB0ICogdCAqIHQgKiB0O1xufVxuZnVuY3Rpb24gcXVpbnRPdXQodCkge1xuICAgIHJldHVybiAtLXQgKiB0ICogdCAqIHQgKiB0ICsgMTtcbn1cbmZ1bmN0aW9uIHNpbmVJbk91dCh0KSB7XG4gICAgcmV0dXJuIC0wLjUgKiAoTWF0aC5jb3MoTWF0aC5QSSAqIHQpIC0gMSk7XG59XG5mdW5jdGlvbiBzaW5lSW4odCkge1xuICAgIGNvbnN0IHYgPSBNYXRoLmNvcyh0ICogTWF0aC5QSSAqIDAuNSk7XG4gICAgaWYgKE1hdGguYWJzKHYpIDwgMWUtMTQpXG4gICAgICAgIHJldHVybiAxO1xuICAgIGVsc2VcbiAgICAgICAgcmV0dXJuIDEgLSB2O1xufVxuZnVuY3Rpb24gc2luZU91dCh0KSB7XG4gICAgcmV0dXJuIE1hdGguc2luKCh0ICogTWF0aC5QSSkgLyAyKTtcbn1cblxuZXhwb3J0IHsgYmFja0luLCBiYWNrSW5PdXQsIGJhY2tPdXQsIGJvdW5jZUluLCBib3VuY2VJbk91dCwgYm91bmNlT3V0LCBjaXJjSW4sIGNpcmNJbk91dCwgY2lyY091dCwgY3ViaWNJbiwgY3ViaWNJbk91dCwgY3ViaWNPdXQsIGVsYXN0aWNJbiwgZWxhc3RpY0luT3V0LCBlbGFzdGljT3V0LCBleHBvSW4sIGV4cG9Jbk91dCwgZXhwb091dCwgcXVhZEluLCBxdWFkSW5PdXQsIHF1YWRPdXQsIHF1YXJ0SW4sIHF1YXJ0SW5PdXQsIHF1YXJ0T3V0LCBxdWludEluLCBxdWludEluT3V0LCBxdWludE91dCwgc2luZUluLCBzaW5lSW5PdXQsIHNpbmVPdXQgfTtcbiIsImltcG9ydCB7IGN1YmljSW5PdXQsIGxpbmVhciwgY3ViaWNPdXQgfSBmcm9tICcuLi9lYXNpbmcvaW5kZXgubWpzJztcbmltcG9ydCB7IGlzX2Z1bmN0aW9uLCBhc3NpZ24gfSBmcm9tICcuLi9pbnRlcm5hbC9pbmRleC5tanMnO1xuXG4vKiEgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuQ29weXJpZ2h0IChjKSBNaWNyb3NvZnQgQ29ycG9yYXRpb24uXHJcblxyXG5QZXJtaXNzaW9uIHRvIHVzZSwgY29weSwgbW9kaWZ5LCBhbmQvb3IgZGlzdHJpYnV0ZSB0aGlzIHNvZnR3YXJlIGZvciBhbnlcclxucHVycG9zZSB3aXRoIG9yIHdpdGhvdXQgZmVlIGlzIGhlcmVieSBncmFudGVkLlxyXG5cclxuVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiBBTkQgVEhFIEFVVEhPUiBESVNDTEFJTVMgQUxMIFdBUlJBTlRJRVMgV0lUSFxyXG5SRUdBUkQgVE8gVEhJUyBTT0ZUV0FSRSBJTkNMVURJTkcgQUxMIElNUExJRUQgV0FSUkFOVElFUyBPRiBNRVJDSEFOVEFCSUxJVFlcclxuQU5EIEZJVE5FU1MuIElOIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1IgQkUgTElBQkxFIEZPUiBBTlkgU1BFQ0lBTCwgRElSRUNULFxyXG5JTkRJUkVDVCwgT1IgQ09OU0VRVUVOVElBTCBEQU1BR0VTIE9SIEFOWSBEQU1BR0VTIFdIQVRTT0VWRVIgUkVTVUxUSU5HIEZST01cclxuTE9TUyBPRiBVU0UsIERBVEEgT1IgUFJPRklUUywgV0hFVEhFUiBJTiBBTiBBQ1RJT04gT0YgQ09OVFJBQ1QsIE5FR0xJR0VOQ0UgT1JcclxuT1RIRVIgVE9SVElPVVMgQUNUSU9OLCBBUklTSU5HIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFIFVTRSBPUlxyXG5QRVJGT1JNQU5DRSBPRiBUSElTIFNPRlRXQVJFLlxyXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiAqL1xyXG5cclxuZnVuY3Rpb24gX19yZXN0KHMsIGUpIHtcclxuICAgIHZhciB0ID0ge307XHJcbiAgICBmb3IgKHZhciBwIGluIHMpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwocywgcCkgJiYgZS5pbmRleE9mKHApIDwgMClcclxuICAgICAgICB0W3BdID0gc1twXTtcclxuICAgIGlmIChzICE9IG51bGwgJiYgdHlwZW9mIE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMgPT09IFwiZnVuY3Rpb25cIilcclxuICAgICAgICBmb3IgKHZhciBpID0gMCwgcCA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMocyk7IGkgPCBwLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChlLmluZGV4T2YocFtpXSkgPCAwICYmIE9iamVjdC5wcm90b3R5cGUucHJvcGVydHlJc0VudW1lcmFibGUuY2FsbChzLCBwW2ldKSlcclxuICAgICAgICAgICAgICAgIHRbcFtpXV0gPSBzW3BbaV1dO1xyXG4gICAgICAgIH1cclxuICAgIHJldHVybiB0O1xyXG59XG5cbmZ1bmN0aW9uIGJsdXIobm9kZSwgeyBkZWxheSA9IDAsIGR1cmF0aW9uID0gNDAwLCBlYXNpbmcgPSBjdWJpY0luT3V0LCBhbW91bnQgPSA1LCBvcGFjaXR5ID0gMCB9ID0ge30pIHtcbiAgICBjb25zdCBzdHlsZSA9IGdldENvbXB1dGVkU3R5bGUobm9kZSk7XG4gICAgY29uc3QgdGFyZ2V0X29wYWNpdHkgPSArc3R5bGUub3BhY2l0eTtcbiAgICBjb25zdCBmID0gc3R5bGUuZmlsdGVyID09PSAnbm9uZScgPyAnJyA6IHN0eWxlLmZpbHRlcjtcbiAgICBjb25zdCBvZCA9IHRhcmdldF9vcGFjaXR5ICogKDEgLSBvcGFjaXR5KTtcbiAgICByZXR1cm4ge1xuICAgICAgICBkZWxheSxcbiAgICAgICAgZHVyYXRpb24sXG4gICAgICAgIGVhc2luZyxcbiAgICAgICAgY3NzOiAoX3QsIHUpID0+IGBvcGFjaXR5OiAke3RhcmdldF9vcGFjaXR5IC0gKG9kICogdSl9OyBmaWx0ZXI6ICR7Zn0gYmx1cigke3UgKiBhbW91bnR9cHgpO2BcbiAgICB9O1xufVxuZnVuY3Rpb24gZmFkZShub2RlLCB7IGRlbGF5ID0gMCwgZHVyYXRpb24gPSA0MDAsIGVhc2luZyA9IGxpbmVhciB9ID0ge30pIHtcbiAgICBjb25zdCBvID0gK2dldENvbXB1dGVkU3R5bGUobm9kZSkub3BhY2l0eTtcbiAgICByZXR1cm4ge1xuICAgICAgICBkZWxheSxcbiAgICAgICAgZHVyYXRpb24sXG4gICAgICAgIGVhc2luZyxcbiAgICAgICAgY3NzOiB0ID0+IGBvcGFjaXR5OiAke3QgKiBvfWBcbiAgICB9O1xufVxuZnVuY3Rpb24gZmx5KG5vZGUsIHsgZGVsYXkgPSAwLCBkdXJhdGlvbiA9IDQwMCwgZWFzaW5nID0gY3ViaWNPdXQsIHggPSAwLCB5ID0gMCwgb3BhY2l0eSA9IDAgfSA9IHt9KSB7XG4gICAgY29uc3Qgc3R5bGUgPSBnZXRDb21wdXRlZFN0eWxlKG5vZGUpO1xuICAgIGNvbnN0IHRhcmdldF9vcGFjaXR5ID0gK3N0eWxlLm9wYWNpdHk7XG4gICAgY29uc3QgdHJhbnNmb3JtID0gc3R5bGUudHJhbnNmb3JtID09PSAnbm9uZScgPyAnJyA6IHN0eWxlLnRyYW5zZm9ybTtcbiAgICBjb25zdCBvZCA9IHRhcmdldF9vcGFjaXR5ICogKDEgLSBvcGFjaXR5KTtcbiAgICByZXR1cm4ge1xuICAgICAgICBkZWxheSxcbiAgICAgICAgZHVyYXRpb24sXG4gICAgICAgIGVhc2luZyxcbiAgICAgICAgY3NzOiAodCwgdSkgPT4gYFxuXHRcdFx0dHJhbnNmb3JtOiAke3RyYW5zZm9ybX0gdHJhbnNsYXRlKCR7KDEgLSB0KSAqIHh9cHgsICR7KDEgLSB0KSAqIHl9cHgpO1xuXHRcdFx0b3BhY2l0eTogJHt0YXJnZXRfb3BhY2l0eSAtIChvZCAqIHUpfWBcbiAgICB9O1xufVxuZnVuY3Rpb24gc2xpZGUobm9kZSwgeyBkZWxheSA9IDAsIGR1cmF0aW9uID0gNDAwLCBlYXNpbmcgPSBjdWJpY091dCB9ID0ge30pIHtcbiAgICBjb25zdCBzdHlsZSA9IGdldENvbXB1dGVkU3R5bGUobm9kZSk7XG4gICAgY29uc3Qgb3BhY2l0eSA9ICtzdHlsZS5vcGFjaXR5O1xuICAgIGNvbnN0IGhlaWdodCA9IHBhcnNlRmxvYXQoc3R5bGUuaGVpZ2h0KTtcbiAgICBjb25zdCBwYWRkaW5nX3RvcCA9IHBhcnNlRmxvYXQoc3R5bGUucGFkZGluZ1RvcCk7XG4gICAgY29uc3QgcGFkZGluZ19ib3R0b20gPSBwYXJzZUZsb2F0KHN0eWxlLnBhZGRpbmdCb3R0b20pO1xuICAgIGNvbnN0IG1hcmdpbl90b3AgPSBwYXJzZUZsb2F0KHN0eWxlLm1hcmdpblRvcCk7XG4gICAgY29uc3QgbWFyZ2luX2JvdHRvbSA9IHBhcnNlRmxvYXQoc3R5bGUubWFyZ2luQm90dG9tKTtcbiAgICBjb25zdCBib3JkZXJfdG9wX3dpZHRoID0gcGFyc2VGbG9hdChzdHlsZS5ib3JkZXJUb3BXaWR0aCk7XG4gICAgY29uc3QgYm9yZGVyX2JvdHRvbV93aWR0aCA9IHBhcnNlRmxvYXQoc3R5bGUuYm9yZGVyQm90dG9tV2lkdGgpO1xuICAgIHJldHVybiB7XG4gICAgICAgIGRlbGF5LFxuICAgICAgICBkdXJhdGlvbixcbiAgICAgICAgZWFzaW5nLFxuICAgICAgICBjc3M6IHQgPT4gJ292ZXJmbG93OiBoaWRkZW47JyArXG4gICAgICAgICAgICBgb3BhY2l0eTogJHtNYXRoLm1pbih0ICogMjAsIDEpICogb3BhY2l0eX07YCArXG4gICAgICAgICAgICBgaGVpZ2h0OiAke3QgKiBoZWlnaHR9cHg7YCArXG4gICAgICAgICAgICBgcGFkZGluZy10b3A6ICR7dCAqIHBhZGRpbmdfdG9wfXB4O2AgK1xuICAgICAgICAgICAgYHBhZGRpbmctYm90dG9tOiAke3QgKiBwYWRkaW5nX2JvdHRvbX1weDtgICtcbiAgICAgICAgICAgIGBtYXJnaW4tdG9wOiAke3QgKiBtYXJnaW5fdG9wfXB4O2AgK1xuICAgICAgICAgICAgYG1hcmdpbi1ib3R0b206ICR7dCAqIG1hcmdpbl9ib3R0b219cHg7YCArXG4gICAgICAgICAgICBgYm9yZGVyLXRvcC13aWR0aDogJHt0ICogYm9yZGVyX3RvcF93aWR0aH1weDtgICtcbiAgICAgICAgICAgIGBib3JkZXItYm90dG9tLXdpZHRoOiAke3QgKiBib3JkZXJfYm90dG9tX3dpZHRofXB4O2BcbiAgICB9O1xufVxuZnVuY3Rpb24gc2NhbGUobm9kZSwgeyBkZWxheSA9IDAsIGR1cmF0aW9uID0gNDAwLCBlYXNpbmcgPSBjdWJpY091dCwgc3RhcnQgPSAwLCBvcGFjaXR5ID0gMCB9ID0ge30pIHtcbiAgICBjb25zdCBzdHlsZSA9IGdldENvbXB1dGVkU3R5bGUobm9kZSk7XG4gICAgY29uc3QgdGFyZ2V0X29wYWNpdHkgPSArc3R5bGUub3BhY2l0eTtcbiAgICBjb25zdCB0cmFuc2Zvcm0gPSBzdHlsZS50cmFuc2Zvcm0gPT09ICdub25lJyA/ICcnIDogc3R5bGUudHJhbnNmb3JtO1xuICAgIGNvbnN0IHNkID0gMSAtIHN0YXJ0O1xuICAgIGNvbnN0IG9kID0gdGFyZ2V0X29wYWNpdHkgKiAoMSAtIG9wYWNpdHkpO1xuICAgIHJldHVybiB7XG4gICAgICAgIGRlbGF5LFxuICAgICAgICBkdXJhdGlvbixcbiAgICAgICAgZWFzaW5nLFxuICAgICAgICBjc3M6IChfdCwgdSkgPT4gYFxuXHRcdFx0dHJhbnNmb3JtOiAke3RyYW5zZm9ybX0gc2NhbGUoJHsxIC0gKHNkICogdSl9KTtcblx0XHRcdG9wYWNpdHk6ICR7dGFyZ2V0X29wYWNpdHkgLSAob2QgKiB1KX1cblx0XHRgXG4gICAgfTtcbn1cbmZ1bmN0aW9uIGRyYXcobm9kZSwgeyBkZWxheSA9IDAsIHNwZWVkLCBkdXJhdGlvbiwgZWFzaW5nID0gY3ViaWNJbk91dCB9ID0ge30pIHtcbiAgICBsZXQgbGVuID0gbm9kZS5nZXRUb3RhbExlbmd0aCgpO1xuICAgIGNvbnN0IHN0eWxlID0gZ2V0Q29tcHV0ZWRTdHlsZShub2RlKTtcbiAgICBpZiAoc3R5bGUuc3Ryb2tlTGluZWNhcCAhPT0gJ2J1dHQnKSB7XG4gICAgICAgIGxlbiArPSBwYXJzZUludChzdHlsZS5zdHJva2VXaWR0aCk7XG4gICAgfVxuICAgIGlmIChkdXJhdGlvbiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIGlmIChzcGVlZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBkdXJhdGlvbiA9IDgwMDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGR1cmF0aW9uID0gbGVuIC8gc3BlZWQ7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZWxzZSBpZiAodHlwZW9mIGR1cmF0aW9uID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIGR1cmF0aW9uID0gZHVyYXRpb24obGVuKTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZGVsYXksXG4gICAgICAgIGR1cmF0aW9uLFxuICAgICAgICBlYXNpbmcsXG4gICAgICAgIGNzczogKHQsIHUpID0+IGBzdHJva2UtZGFzaGFycmF5OiAke3QgKiBsZW59ICR7dSAqIGxlbn1gXG4gICAgfTtcbn1cbmZ1bmN0aW9uIGNyb3NzZmFkZShfYSkge1xuICAgIHZhciB7IGZhbGxiYWNrIH0gPSBfYSwgZGVmYXVsdHMgPSBfX3Jlc3QoX2EsIFtcImZhbGxiYWNrXCJdKTtcbiAgICBjb25zdCB0b19yZWNlaXZlID0gbmV3IE1hcCgpO1xuICAgIGNvbnN0IHRvX3NlbmQgPSBuZXcgTWFwKCk7XG4gICAgZnVuY3Rpb24gY3Jvc3NmYWRlKGZyb20sIG5vZGUsIHBhcmFtcykge1xuICAgICAgICBjb25zdCB7IGRlbGF5ID0gMCwgZHVyYXRpb24gPSBkID0+IE1hdGguc3FydChkKSAqIDMwLCBlYXNpbmcgPSBjdWJpY091dCB9ID0gYXNzaWduKGFzc2lnbih7fSwgZGVmYXVsdHMpLCBwYXJhbXMpO1xuICAgICAgICBjb25zdCB0byA9IG5vZGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgIGNvbnN0IGR4ID0gZnJvbS5sZWZ0IC0gdG8ubGVmdDtcbiAgICAgICAgY29uc3QgZHkgPSBmcm9tLnRvcCAtIHRvLnRvcDtcbiAgICAgICAgY29uc3QgZHcgPSBmcm9tLndpZHRoIC8gdG8ud2lkdGg7XG4gICAgICAgIGNvbnN0IGRoID0gZnJvbS5oZWlnaHQgLyB0by5oZWlnaHQ7XG4gICAgICAgIGNvbnN0IGQgPSBNYXRoLnNxcnQoZHggKiBkeCArIGR5ICogZHkpO1xuICAgICAgICBjb25zdCBzdHlsZSA9IGdldENvbXB1dGVkU3R5bGUobm9kZSk7XG4gICAgICAgIGNvbnN0IHRyYW5zZm9ybSA9IHN0eWxlLnRyYW5zZm9ybSA9PT0gJ25vbmUnID8gJycgOiBzdHlsZS50cmFuc2Zvcm07XG4gICAgICAgIGNvbnN0IG9wYWNpdHkgPSArc3R5bGUub3BhY2l0eTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGRlbGF5LFxuICAgICAgICAgICAgZHVyYXRpb246IGlzX2Z1bmN0aW9uKGR1cmF0aW9uKSA/IGR1cmF0aW9uKGQpIDogZHVyYXRpb24sXG4gICAgICAgICAgICBlYXNpbmcsXG4gICAgICAgICAgICBjc3M6ICh0LCB1KSA9PiBgXG5cdFx0XHRcdG9wYWNpdHk6ICR7dCAqIG9wYWNpdHl9O1xuXHRcdFx0XHR0cmFuc2Zvcm0tb3JpZ2luOiB0b3AgbGVmdDtcblx0XHRcdFx0dHJhbnNmb3JtOiAke3RyYW5zZm9ybX0gdHJhbnNsYXRlKCR7dSAqIGR4fXB4LCR7dSAqIGR5fXB4KSBzY2FsZSgke3QgKyAoMSAtIHQpICogZHd9LCAke3QgKyAoMSAtIHQpICogZGh9KTtcblx0XHRcdGBcbiAgICAgICAgfTtcbiAgICB9XG4gICAgZnVuY3Rpb24gdHJhbnNpdGlvbihpdGVtcywgY291bnRlcnBhcnRzLCBpbnRybykge1xuICAgICAgICByZXR1cm4gKG5vZGUsIHBhcmFtcykgPT4ge1xuICAgICAgICAgICAgaXRlbXMuc2V0KHBhcmFtcy5rZXksIHtcbiAgICAgICAgICAgICAgICByZWN0OiBub2RlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKGNvdW50ZXJwYXJ0cy5oYXMocGFyYW1zLmtleSkpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgeyByZWN0IH0gPSBjb3VudGVycGFydHMuZ2V0KHBhcmFtcy5rZXkpO1xuICAgICAgICAgICAgICAgICAgICBjb3VudGVycGFydHMuZGVsZXRlKHBhcmFtcy5rZXkpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gY3Jvc3NmYWRlKHJlY3QsIG5vZGUsIHBhcmFtcyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8vIGlmIHRoZSBub2RlIGlzIGRpc2FwcGVhcmluZyBhbHRvZ2V0aGVyXG4gICAgICAgICAgICAgICAgLy8gKGkuZS4gd2Fzbid0IGNsYWltZWQgYnkgdGhlIG90aGVyIGxpc3QpXG4gICAgICAgICAgICAgICAgLy8gdGhlbiB3ZSBuZWVkIHRvIHN1cHBseSBhbiBvdXRyb1xuICAgICAgICAgICAgICAgIGl0ZW1zLmRlbGV0ZShwYXJhbXMua2V5KTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsbGJhY2sgJiYgZmFsbGJhY2sobm9kZSwgcGFyYW1zLCBpbnRybyk7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gW1xuICAgICAgICB0cmFuc2l0aW9uKHRvX3NlbmQsIHRvX3JlY2VpdmUsIGZhbHNlKSxcbiAgICAgICAgdHJhbnNpdGlvbih0b19yZWNlaXZlLCB0b19zZW5kLCB0cnVlKVxuICAgIF07XG59XG5cbmV4cG9ydCB7IGJsdXIsIGNyb3NzZmFkZSwgZHJhdywgZmFkZSwgZmx5LCBzY2FsZSwgc2xpZGUgfTtcbiIsImltcG9ydCB7IGN1YmljT3V0IH0gZnJvbSAnLi4vZWFzaW5nL2luZGV4Lm1qcyc7XG5pbXBvcnQgeyBpc19mdW5jdGlvbiB9IGZyb20gJy4uL2ludGVybmFsL2luZGV4Lm1qcyc7XG5cbmZ1bmN0aW9uIGZsaXAobm9kZSwgeyBmcm9tLCB0byB9LCBwYXJhbXMgPSB7fSkge1xuICAgIGNvbnN0IHN0eWxlID0gZ2V0Q29tcHV0ZWRTdHlsZShub2RlKTtcbiAgICBjb25zdCB0cmFuc2Zvcm0gPSBzdHlsZS50cmFuc2Zvcm0gPT09ICdub25lJyA/ICcnIDogc3R5bGUudHJhbnNmb3JtO1xuICAgIGNvbnN0IFtveCwgb3ldID0gc3R5bGUudHJhbnNmb3JtT3JpZ2luLnNwbGl0KCcgJykubWFwKHBhcnNlRmxvYXQpO1xuICAgIGNvbnN0IGR4ID0gKGZyb20ubGVmdCArIGZyb20ud2lkdGggKiBveCAvIHRvLndpZHRoKSAtICh0by5sZWZ0ICsgb3gpO1xuICAgIGNvbnN0IGR5ID0gKGZyb20udG9wICsgZnJvbS5oZWlnaHQgKiBveSAvIHRvLmhlaWdodCkgLSAodG8udG9wICsgb3kpO1xuICAgIGNvbnN0IHsgZGVsYXkgPSAwLCBkdXJhdGlvbiA9IChkKSA9PiBNYXRoLnNxcnQoZCkgKiAxMjAsIGVhc2luZyA9IGN1YmljT3V0IH0gPSBwYXJhbXM7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZGVsYXksXG4gICAgICAgIGR1cmF0aW9uOiBpc19mdW5jdGlvbihkdXJhdGlvbikgPyBkdXJhdGlvbihNYXRoLnNxcnQoZHggKiBkeCArIGR5ICogZHkpKSA6IGR1cmF0aW9uLFxuICAgICAgICBlYXNpbmcsXG4gICAgICAgIGNzczogKHQsIHUpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHggPSB1ICogZHg7XG4gICAgICAgICAgICBjb25zdCB5ID0gdSAqIGR5O1xuICAgICAgICAgICAgY29uc3Qgc3ggPSB0ICsgdSAqIGZyb20ud2lkdGggLyB0by53aWR0aDtcbiAgICAgICAgICAgIGNvbnN0IHN5ID0gdCArIHUgKiBmcm9tLmhlaWdodCAvIHRvLmhlaWdodDtcbiAgICAgICAgICAgIHJldHVybiBgdHJhbnNmb3JtOiAke3RyYW5zZm9ybX0gdHJhbnNsYXRlKCR7eH1weCwgJHt5fXB4KSBzY2FsZSgke3N4fSwgJHtzeX0pO2A7XG4gICAgICAgIH1cbiAgICB9O1xufVxuXG5leHBvcnQgeyBmbGlwIH07XG4iLCJpbXBvcnQgeyB3cml0YWJsZSB9IGZyb20gJ3N2ZWx0ZS9zdG9yZSc7XHJcblxyXG5jb25zdCBtZWV0dXBzID0gd3JpdGFibGUoW10pO1xyXG5cclxuY29uc3QgY3VzdG9tTWVldHVwc1N0b3JlID0ge1xyXG4gIHN1YnNjcmliZTogbWVldHVwcy5zdWJzY3JpYmUsXHJcbiAgc2V0TWVldHVwczogKGl0ZW1zKSA9PiB7XHJcbiAgICBtZWV0dXBzLnNldChpdGVtcyk7XHJcbiAgfSxcclxuICBhZGRNZWV0dXA6IChtZWV0dXBEYXRhKSA9PiB7XHJcbiAgICBjb25zdCBuZXdNZWV0dXAgPSB7XHJcbiAgICAgIC4uLm1lZXR1cERhdGEsXHJcbiAgICB9O1xyXG4gICAgbWVldHVwcy51cGRhdGUoKGl0ZW1zKSA9PiBbbmV3TWVldHVwLCAuLi5pdGVtc10pO1xyXG4gIH0sXHJcbiAgdXBkYXRlTWVldHVwOiAoaWQsIG1lZXR1cERhdGEpID0+IHtcclxuICAgIG1lZXR1cHMudXBkYXRlKChpdGVtcykgPT4ge1xyXG4gICAgICBjb25zdCBtZWV0dXBJbmRleCA9IGl0ZW1zLmZpbmRJbmRleCgoaSkgPT4gaS5pZCA9PT0gaWQpO1xyXG4gICAgICBjb25zdCB1cGRhdGVkTWVldHVwID0geyAuLi5pdGVtc1ttZWV0dXBJbmRleF0sIC4uLm1lZXR1cERhdGEgfTtcclxuICAgICAgY29uc3QgdXBkYXRlZE1lZXR1cHMgPSBbLi4uaXRlbXNdO1xyXG4gICAgICB1cGRhdGVkTWVldHVwc1ttZWV0dXBJbmRleF0gPSB1cGRhdGVkTWVldHVwO1xyXG4gICAgICByZXR1cm4gdXBkYXRlZE1lZXR1cHM7XHJcbiAgICB9KTtcclxuICB9LFxyXG4gIHJlbW92ZU1lZXR1cDogKGlkKSA9PiB7XHJcbiAgICBtZWV0dXBzLnVwZGF0ZSgoaXRlbXMpID0+IHtcclxuICAgICAgcmV0dXJuIGl0ZW1zLmZpbHRlcigoaSkgPT4gaS5pZCAhPT0gaWQpO1xyXG4gICAgfSk7XHJcbiAgfSxcclxuICB0b2dnbGVGYXZvcml0ZTogKGlkKSA9PiB7XHJcbiAgICBtZWV0dXBzLnVwZGF0ZSgoaXRlbXMpID0+IHtcclxuICAgICAgY29uc3QgdXBkYXRlZE1lZXR1cCA9IHsgLi4uaXRlbXMuZmluZCgobSkgPT4gbS5pZCA9PT0gaWQpIH07XHJcbiAgICAgIHVwZGF0ZWRNZWV0dXAuaXNGYXZvcml0ZSA9ICF1cGRhdGVkTWVldHVwLmlzRmF2b3JpdGU7XHJcbiAgICAgIGNvbnN0IG1lZXR1cEluZGV4ID0gaXRlbXMuZmluZEluZGV4KChtKSA9PiBtLmlkID09PSBpZCk7XHJcbiAgICAgIGNvbnN0IHVwZGF0ZWRNZWV0dXBzID0gWy4uLml0ZW1zXTtcclxuICAgICAgdXBkYXRlZE1lZXR1cHNbbWVldHVwSW5kZXhdID0gdXBkYXRlZE1lZXR1cDtcclxuICAgICAgcmV0dXJuIHVwZGF0ZWRNZWV0dXBzO1xyXG4gICAgfSk7XHJcbiAgfSxcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGN1c3RvbU1lZXR1cHNTdG9yZTtcclxuIiwiPHNjcmlwdD5cclxuICBpbXBvcnQgeyBzbGlkZSB9IGZyb20gJ3N2ZWx0ZS90cmFuc2l0aW9uJztcclxuPC9zY3JpcHQ+XHJcblxyXG48c3BhbiB0cmFuc2l0aW9uOnNsaWRlPjxzbG90IC8+PC9zcGFuPlxyXG5cclxuPHN0eWxlPlxyXG4gIHNwYW4ge1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgbWFyZ2luOiAwIDAuMjVyZW07XHJcbiAgICBib3JkZXItcmFkaXVzOiAzcHg7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjY2YwMDU2O1xyXG4gICAgYmFja2dyb3VuZDogI2NmMDA1NjtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIHBhZGRpbmc6IDAgMC41cmVtO1xyXG4gICAgZm9udC1mYW1pbHk6ICdMYXRvJywgJ3NhbnMtc2VyaWYnO1xyXG4gICAgZm9udC1zaXplOiAwLjhyZW07XHJcbiAgfVxyXG48L3N0eWxlPlxyXG4iLCI8ZGl2IGNsYXNzPVwibG9hZGluZ1wiPlxyXG4gIDxkaXYgY2xhc3M9XCJsZHMtcmluZ1wiPlxyXG4gICAgPGRpdiAvPlxyXG4gICAgPGRpdiAvPlxyXG4gICAgPGRpdiAvPlxyXG4gICAgPGRpdiAvPlxyXG4gIDwvZGl2PlxyXG48L2Rpdj5cclxuXHJcbjxzdHlsZT5cclxuICAubG9hZGluZyB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgbWFyZ2luOiAycmVtO1xyXG4gIH1cclxuICAubGRzLXJpbmcge1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgd2lkdGg6IDgwcHg7XHJcbiAgICBoZWlnaHQ6IDgwcHg7XHJcbiAgfVxyXG4gIC5sZHMtcmluZyBkaXYge1xyXG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgd2lkdGg6IDY0cHg7XHJcbiAgICBoZWlnaHQ6IDY0cHg7XHJcbiAgICBtYXJnaW46IDhweDtcclxuICAgIGJvcmRlcjogOHB4IHNvbGlkICNjZjAwNTY7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICBhbmltYXRpb246IGxkcy1yaW5nIDEuMnMgY3ViaWMtYmV6aWVyKDAuNSwgMCwgMC41LCAxKSBpbmZpbml0ZTtcclxuICAgIGJvcmRlci1jb2xvcjogI2NmMDA1NiB0cmFuc3BhcmVudCB0cmFuc3BhcmVudCB0cmFuc3BhcmVudDtcclxuICB9XHJcbiAgLmxkcy1yaW5nIGRpdjpudGgtY2hpbGQoMSkge1xyXG4gICAgYW5pbWF0aW9uLWRlbGF5OiAtMC40NXM7XHJcbiAgfVxyXG4gIC5sZHMtcmluZyBkaXY6bnRoLWNoaWxkKDIpIHtcclxuICAgIGFuaW1hdGlvbi1kZWxheTogLTAuM3M7XHJcbiAgfVxyXG4gIC5sZHMtcmluZyBkaXY6bnRoLWNoaWxkKDMpIHtcclxuICAgIGFuaW1hdGlvbi1kZWxheTogLTAuMTVzO1xyXG4gIH1cclxuICBAa2V5ZnJhbWVzIGxkcy1yaW5nIHtcclxuICAgIDAlIHtcclxuICAgICAgdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7XHJcbiAgICB9XHJcbiAgICAxMDAlIHtcclxuICAgICAgdHJhbnNmb3JtOiByb3RhdGUoMzYwZGVnKTtcclxuICAgIH1cclxuICB9XHJcbjwvc3R5bGU+XHJcbiIsIjxzY3JpcHQ+XG4gIGltcG9ydCB7IGNyZWF0ZUV2ZW50RGlzcGF0Y2hlciB9IGZyb20gJ3N2ZWx0ZSc7XG4gIGltcG9ydCBtZWV0dXBzIGZyb20gJy4uLy4uL21ldHR1cHMtc3RvcmUnO1xuICBpbXBvcnQgQnV0dG9uIGZyb20gJy4uL1VJL0J1dHRvbi5zdmVsdGUnO1xuICBpbXBvcnQgQmFkZ2UgZnJvbSAnLi4vVUkvQmFkZ2Uuc3ZlbHRlJztcbiAgaW1wb3J0IFNwaW5uZXIgZnJvbSAnLi4vVUkvU3Bpbm5lci5zdmVsdGUnO1xuXG4gIGV4cG9ydCBsZXQgaWQ7XG4gIGV4cG9ydCBsZXQgdGl0bGU7XG4gIGV4cG9ydCBsZXQgc3VidGl0bGU7XG4gIGV4cG9ydCBsZXQgaW1hZ2VVcmw7XG4gIGV4cG9ydCBsZXQgZGVzY3JpcHRpb247XG4gIGV4cG9ydCBsZXQgYWRkcmVzcztcbiAgZXhwb3J0IGxldCBlbWFpbDtcbiAgZXhwb3J0IGxldCBpc0ZhdjtcblxuICBsZXQgaXNMb2FkaW5nID0gZmFsc2U7XG5cbiAgY29uc3QgZGlzcGF0Y2ggPSBjcmVhdGVFdmVudERpc3BhdGNoZXIoKTtcblxuICBmdW5jdGlvbiB0b2dnbGVGYXZvcml0ZShldmVudCkge1xuICAgIGlzTG9hZGluZyA9IHRydWU7XG4gICAgZmV0Y2goXG4gICAgICBgaHR0cHM6Ly9zdmVsdGUtY291cnNlLWRvbGVzLWRlZmF1bHQtcnRkYi5maXJlYmFzZWlvLmNvbS9tZWV0dXBzLyR7aWR9Lmpzb25gLFxuICAgICAge1xuICAgICAgICBtZXRob2Q6ICdQQVRDSCcsXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgaXNGYXZvcml0ZTogIWlzRmF2IH0pLFxuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgIH1cbiAgICApXG4gICAgICAudGhlbigocmVzKSA9PiB7XG4gICAgICAgIGlmICghcmVzLm9rKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdGYWlsZWQhJyk7XG4gICAgICAgIH1cbiAgICAgICAgbWVldHVwcy50b2dnbGVGYXZvcml0ZShpZCk7XG4gICAgICB9KVxuICAgICAgLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgY29uc29sZS5sb2coZXJyKTtcbiAgICAgIH0pXG4gICAgICAuZmluYWxseSgoKSA9PiAoaXNMb2FkaW5nID0gZmFsc2UpKTtcbiAgfVxuPC9zY3JpcHQ+XG5cbjxhcnRpY2xlPlxuICA8aGVhZGVyPlxuICAgIDxoMT5cbiAgICAgIHt0aXRsZX1cbiAgICAgIHsjaWYgaXNGYXZ9XG4gICAgICAgIDxCYWRnZT5GQVZPUklURTwvQmFkZ2U+XG4gICAgICB7L2lmfVxuICAgIDwvaDE+XG4gICAgPGgyPntzdWJ0aXRsZX08L2gyPlxuICAgIDxwPnthZGRyZXNzfTwvcD5cbiAgPC9oZWFkZXI+XG4gIDxkaXYgY2xhc3M9XCJpbWFnZVwiPlxuICAgIDxpbWcgc3JjPXtpbWFnZVVybH0gYWx0PXt0aXRsZX0gLz5cbiAgPC9kaXY+XG4gIDxkaXYgY2xhc3M9XCJjb250ZW50XCI+XG4gICAgPHA+e2Rlc2NyaXB0aW9ufTwvcD5cbiAgPC9kaXY+XG4gIDxmb290ZXI+XG4gICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgbW9kZT1cIm91dGxpbmVcIiBvbjpjbGljaz17KCkgPT4gZGlzcGF0Y2goJ2VkaXQnLCBpZCl9XG4gICAgICA+RWRpdDwvQnV0dG9uXG4gICAgPlxuICAgIHsjaWYgaXNMb2FkaW5nfVxuICAgICAgPCEtLSA8U3Bpbm5lciAvPiAtLT5cbiAgICAgIDxzcGFuPkNoYW5naW5nLi4uPC9zcGFuPlxuICAgIHs6ZWxzZX1cbiAgICAgIDxCdXR0b25cbiAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgIG1vZGU9XCJvdXRsaW5lXCJcbiAgICAgICAgY29sb3I9e2lzRmF2ID8gbnVsbCA6ICdzdWNjZXNzJ31cbiAgICAgICAgb246Y2xpY2s9e3RvZ2dsZUZhdm9yaXRlfT57aXNGYXYgPyAnVW5mYXZvcml0ZScgOiAnRmF2b3JpdGUnfTwvQnV0dG9uXG4gICAgICA+XG4gICAgey9pZn1cbiAgICA8QnV0dG9uIHR5cGU9XCJidXR0b25cIiBjYXB0aW9uPVwiU2hvdyBEZXRhaWxzXCIgaHJlZj1cIi97aWR9XCJcbiAgICAgID5TaG93IERldGFpbHM8L0J1dHRvblxuICAgID5cbiAgPC9mb290ZXI+XG48L2FydGljbGU+XG5cbjxzdHlsZT5cbiAgYXJ0aWNsZSB7XG4gICAgYm94LXNoYWRvdzogMCAycHggOHB4IHJnYmEoMCwgMCwgMCwgMC4yNik7XG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xuICAgIG1hcmdpbjogMXJlbTtcbiAgfVxuXG4gIGhlYWRlcixcbiAgLmNvbnRlbnQsXG4gIGZvb3RlciB7XG4gICAgcGFkZGluZzogMXJlbTtcbiAgfVxuXG4gIC5pbWFnZSB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxNHJlbTtcbiAgfVxuXG4gIC5pbWFnZSBpbWcge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgfVxuXG4gIGgxIHtcbiAgICBmb250LXNpemU6IDEuMjVyZW07XG4gICAgbWFyZ2luOiAwLjVyZW0gMDtcbiAgICBmb250LWZhbWlseTogJ1JvYm90byBTbGFiJywgc2Fucy1zZXJpZjtcbiAgfVxuXG4gIGgxLmlzLWZhdm9yaXRlIHtcbiAgICBiYWNrZ3JvdW5kOiAjMDFhMTI5O1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBwYWRkaW5nOiAwIDAuNXJlbTtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIH1cblxuICBoMiB7XG4gICAgZm9udC1zaXplOiAxcmVtO1xuICAgIGNvbG9yOiAjODA4MDgwO1xuICAgIG1hcmdpbjogMC41cmVtIDA7XG4gIH1cblxuICBwIHtcbiAgICBmb250LXNpemU6IDEuMjVyZW07XG4gICAgbWFyZ2luOiAwO1xuICB9XG5cbiAgZGl2IHtcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgfVxuXG4gIC5jb250ZW50IHtcbiAgICBoZWlnaHQ6IDRyZW07XG4gIH1cbjwvc3R5bGU+XG4iLCI8c2NyaXB0PlxyXG4gIGltcG9ydCB7IGNyZWF0ZUV2ZW50RGlzcGF0Y2hlciB9IGZyb20gJ3N2ZWx0ZSc7XHJcblxyXG4gIGNvbnN0IGRpc3BhdGNoID0gY3JlYXRlRXZlbnREaXNwYXRjaGVyKCk7XHJcblxyXG4gIGxldCBzZWxlY3RlZEJ1dHRvbiA9IDA7XHJcbjwvc2NyaXB0PlxyXG5cclxuPGRpdj5cclxuICA8YnV0dG9uXHJcbiAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgIGNsYXNzOmFjdGl2ZT17c2VsZWN0ZWRCdXR0b24gPT09IDB9XHJcbiAgICBvbjpjbGljaz17KCkgPT4ge1xyXG4gICAgICBzZWxlY3RlZEJ1dHRvbiA9IDA7XHJcbiAgICAgIGRpc3BhdGNoKCdzZWxlY3QnLCAwKTtcclxuICAgIH19PkFsbDwvYnV0dG9uXHJcbiAgPlxyXG4gIDxidXR0b25cclxuICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgY2xhc3M6YWN0aXZlPXtzZWxlY3RlZEJ1dHRvbiA9PT0gMX1cclxuICAgIG9uOmNsaWNrPXsoKSA9PiB7XHJcbiAgICAgIHNlbGVjdGVkQnV0dG9uID0gMTtcclxuICAgICAgZGlzcGF0Y2goJ3NlbGVjdCcsIDEpO1xyXG4gICAgfX0+RmF2b3JpdGVzPC9idXR0b25cclxuICA+XHJcbjwvZGl2PlxyXG5cclxuPHN0eWxlPlxyXG4gIGRpdiB7XHJcbiAgICBmb250LXNpemU6IDBweDtcclxuICB9XHJcblxyXG4gIGJ1dHRvbiB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjYWFhYWFhO1xyXG4gICAgZm9udDogaW5oZXJpdDtcclxuICAgIGZvbnQtc2l6ZTogMXJlbTtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNhYWFhYWE7XHJcbiAgICBwYWRkaW5nOiAwLjVyZW0gMXJlbTtcclxuICB9XHJcblxyXG4gIGJ1dHRvbjpmb2N1cyB7XHJcbiAgICBvdXRsaW5lOiBub25lO1xyXG4gIH1cclxuXHJcbiAgYnV0dG9uOmZpcnN0LW9mLXR5cGUge1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXB4IDAgMCA1cHg7XHJcbiAgfVxyXG5cclxuICBidXR0b246bGFzdC1vZi10eXBlIHtcclxuICAgIGJvcmRlci1yYWRpdXM6IDAgNXB4IDVweCAwO1xyXG4gIH1cclxuXHJcbiAgYnV0dG9uOmhvdmVyLFxyXG4gIGJ1dHRvbjphY3RpdmUsXHJcbiAgLmFjdGl2ZSB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjY2YwMDU2O1xyXG4gICAgYm9yZGVyLWNvbG9yOiAjY2YwMDU2O1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gIH1cclxuPC9zdHlsZT5cclxuIiwiPHNjcmlwdD5cclxuICBleHBvcnQgbGV0IGNvbnRyb2xUeXBlID0gbnVsbDtcclxuICBleHBvcnQgbGV0IGlkO1xyXG4gIGV4cG9ydCBsZXQgbGFiZWw7XHJcbiAgZXhwb3J0IGxldCByb3dzID0gbnVsbDtcclxuICBleHBvcnQgbGV0IHZhbHVlO1xyXG4gIGV4cG9ydCBsZXQgdHlwZSA9ICd0ZXh0JztcclxuICBleHBvcnQgbGV0IHZhbGlkID0gdHJ1ZTtcclxuICBleHBvcnQgbGV0IHZhbGlkaXR5TWVzc2FnZSA9ICcnO1xyXG5cclxuICBsZXQgdG91Y2hlZCA9IGZhbHNlO1xyXG48L3NjcmlwdD5cclxuXHJcbjxkaXYgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIj5cclxuICA8bGFiZWwgZm9yPXtpZH0+e2xhYmVsfTwvbGFiZWw+XHJcbiAgeyNpZiBjb250cm9sVHlwZSA9PT0gJ3RleHRhcmVhJ31cclxuICAgIDx0ZXh0YXJlYVxyXG4gICAgICBjbGFzczppbnZhbGlkPXshdmFsaWQgJiYgdG91Y2hlZH1cclxuICAgICAge3Jvd3N9XHJcbiAgICAgIHtpZH1cclxuICAgICAgYmluZDp2YWx1ZVxyXG4gICAgICBvbjpibHVyPXsoKSA9PiAodG91Y2hlZCA9IHRydWUpfVxyXG4gICAgLz5cclxuICB7OmVsc2V9XHJcbiAgICA8aW5wdXRcclxuICAgICAgY2xhc3M6aW52YWxpZD17IXZhbGlkICYmIHRvdWNoZWR9XHJcbiAgICAgIHt0eXBlfVxyXG4gICAgICB7aWR9XHJcbiAgICAgIHt2YWx1ZX1cclxuICAgICAgb246aW5wdXRcclxuICAgICAgb246Ymx1cj17KCkgPT4gKHRvdWNoZWQgPSB0cnVlKX1cclxuICAgIC8+XHJcbiAgey9pZn1cclxuICB7I2lmIHZhbGlkaXR5TWVzc2FnZSAmJiAhdmFsaWQgJiYgdG91Y2hlZH1cclxuICAgIDxwIGNsYXNzPVwiZXJyb3ItbWVzc2FnZVwiPnt2YWxpZGl0eU1lc3NhZ2V9PC9wPlxyXG4gIHsvaWZ9XHJcbjwvZGl2PlxyXG5cclxuPHN0eWxlPlxyXG4gIGlucHV0LFxyXG4gIHRleHRhcmVhIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBmb250OiBpbmhlcml0O1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkICNjY2M7XHJcbiAgICBib3JkZXItcmFkaXVzOiAzcHggM3B4IDAgMDtcclxuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgcGFkZGluZzogMC4xNXJlbSAwLjI1cmVtO1xyXG4gICAgdHJhbnNpdGlvbjogYm9yZGVyLWNvbG9yIDAuMXMgZWFzZS1vdXQ7XHJcbiAgfVxyXG5cclxuICBpbnB1dDpmb2N1cyxcclxuICB0ZXh0YXJlYTpmb2N1cyB7XHJcbiAgICBib3JkZXItY29sb3I6ICNlNDA3NjM7XHJcbiAgICBvdXRsaW5lOiBub25lO1xyXG4gIH1cclxuXHJcbiAgbGFiZWwge1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAwLjVyZW07XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICB9XHJcblxyXG4gIC5mb3JtLWNvbnRyb2wge1xyXG4gICAgcGFkZGluZzogMC41cmVtIDA7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIG1hcmdpbjogMC4yNXJlbSAwO1xyXG4gIH1cclxuXHJcbiAgLmludmFsaWQge1xyXG4gICAgYm9yZGVyLWNvbG9yOiByZWQ7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmRlM2UzO1xyXG4gIH1cclxuXHJcbiAgLmVycm9yLW1lc3NhZ2Uge1xyXG4gICAgY29sb3I6IHJlZDtcclxuICAgIG1hcmdpbjogMC4yNXJlbSAwO1xyXG4gIH1cclxuPC9zdHlsZT5cclxuIiwiPHNjcmlwdD5cclxuICBpbXBvcnQgeyBjcmVhdGVFdmVudERpc3BhdGNoZXIgfSBmcm9tICdzdmVsdGUnO1xyXG4gIGltcG9ydCB7IGZhZGUsIGZseSB9IGZyb20gJ3N2ZWx0ZS90cmFuc2l0aW9uJztcclxuICBpbXBvcnQgQnV0dG9uIGZyb20gJy4vQnV0dG9uLnN2ZWx0ZSc7XHJcbiAgZXhwb3J0IGxldCB0aXRsZTtcclxuICBjb25zdCBkaXNwYXRjaCA9IGNyZWF0ZUV2ZW50RGlzcGF0Y2hlcigpO1xyXG5cclxuICBmdW5jdGlvbiBjbG9zZU1vZGFsKCkge1xyXG4gICAgZGlzcGF0Y2goJ2NhbmNlbCcpO1xyXG4gIH1cclxuPC9zY3JpcHQ+XHJcblxyXG48ZGl2IHRyYW5zaXRpb246ZmFkZSBjbGFzcz1cIm1vZGFsLWJhY2tkcm9wXCIgb246Y2xpY2s9e2Nsb3NlTW9kYWx9IC8+XHJcbjxkaXYgdHJhbnNpdGlvbjpmbHk9e3sgeTogMzAwIH19IGNsYXNzPVwibW9kYWxcIj5cclxuICA8aDE+e3RpdGxlfTwvaDE+XHJcbiAgPGRpdiBjbGFzcz1cImNvbnRlbnRcIj48c2xvdCAvPjwvZGl2PlxyXG4gIDxmb290ZXI+XHJcbiAgICA8c2xvdCBuYW1lPVwiZm9vdGVyXCI+XHJcbiAgICAgIDxCdXR0b24gb246Y2xpY2s9e2Nsb3NlTW9kYWx9PkNsb3NlPC9CdXR0b24+XHJcbiAgICA8L3Nsb3Q+XHJcbiAgPC9mb290ZXI+XHJcbjwvZGl2PlxyXG5cclxuPHN0eWxlPlxyXG4gIC5tb2RhbC1iYWNrZHJvcCB7XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICB0b3A6IDA7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDEwMHZoO1xyXG4gICAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwLjc1KTtcclxuICAgIHotaW5kZXg6IDEwO1xyXG4gIH1cclxuXHJcbiAgLm1vZGFsIHtcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIHRvcDogMTB2aDtcclxuICAgIGxlZnQ6IDEwJTtcclxuICAgIHdpZHRoOiA4MCU7XHJcbiAgICBtYXgtaGVpZ2h0OiA4MHZoO1xyXG4gICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICB6LWluZGV4OiAxMDA7XHJcbiAgICBib3gtc2hhZG93OiAwIDJweCA4cHggcmdiYSgwLCAwLCAwLCAwLjI2KTtcclxuICAgIG92ZXJmbG93OiBzY3JvbGw7XHJcbiAgfVxyXG5cclxuICBoMSB7XHJcbiAgICBwYWRkaW5nOiAxcmVtO1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNjY2M7XHJcbiAgICBmb250LWZhbWlseTogJ1JvYm90byBTbGFiJywgc2Fucy1zZXJpZjtcclxuICB9XHJcblxyXG4gIC5jb250ZW50IHtcclxuICAgIHBhZGRpbmc6IDFyZW07XHJcbiAgfVxyXG5cclxuICBmb290ZXIge1xyXG4gICAgcGFkZGluZzogMXJlbTtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWluLXdpZHRoOiA3NjhweCkge1xyXG4gICAgLm1vZGFsIHtcclxuICAgICAgd2lkdGg6IDQwcmVtO1xyXG4gICAgICBsZWZ0OiBjYWxjKDUwJSAtIDIwcmVtKTtcclxuICAgIH1cclxuICB9XHJcbjwvc3R5bGU+XHJcbiIsImV4cG9ydCBmdW5jdGlvbiBub3RFbXB0eSh2YWwpIHtcclxuICByZXR1cm4gdmFsLnRyaW0oKS5sZW5ndGggPT09IDA7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBpc1ZhbGlkRW1haWwodmFsKSB7XHJcbiAgcmV0dXJuIG5ldyBSZWdFeHAoJy9eUytAUysuUyskLycpLnRlc3QodmFsKTtcclxufVxyXG4iLCI8c2NyaXB0PlxyXG4gIGltcG9ydCBtZWV0dXBzIGZyb20gJy4uLy4uL21ldHR1cHMtc3RvcmUnO1xyXG4gIGltcG9ydCB7IGNyZWF0ZUV2ZW50RGlzcGF0Y2hlciB9IGZyb20gJ3N2ZWx0ZSc7XHJcbiAgaW1wb3J0IEJ1dHRvbiBmcm9tICcuLi9VSS9CdXR0b24uc3ZlbHRlJztcclxuICBpbXBvcnQgVGV4dElucHV0IGZyb20gJy4uL1VJL1RleHRJbnB1dC5zdmVsdGUnO1xyXG4gIGltcG9ydCBNb2RhbCBmcm9tICcuLi9VSS9Nb2RhbC5zdmVsdGUnO1xyXG4gIGltcG9ydCB7IGlzVmFsaWRFbWFpbCwgbm90RW1wdHkgfSBmcm9tICcuLi8uLi9oZWxwZXJzL3ZhbGlkYXRpb24nO1xyXG5cclxuICBleHBvcnQgbGV0IGlkID0gbnVsbDtcclxuICBsZXQgdGl0bGUgPSAnJztcclxuICBsZXQgc3VidGl0bGUgPSAnJztcclxuICBsZXQgYWRkcmVzcyA9ICcnO1xyXG4gIGxldCBlbWFpbCA9ICcnO1xyXG4gIGxldCBkZXNjcmlwdGlvbiA9ICcnO1xyXG4gIGxldCBpbWFnZVVybCA9ICcnO1xyXG5cclxuICBpZiAoaWQpIHtcclxuICAgIGNvbnN0IHVuc3Vic2NyaWJlID0gbWVldHVwcy5zdWJzY3JpYmUoKGl0ZW1zKSA9PiB7XHJcbiAgICAgIGNvbnN0IHNlbGVjdGVkTWVldHVwID0gaXRlbXMuZmluZCgoaSkgPT4gaS5pZCA9PT0gaWQpO1xyXG4gICAgICB0aXRsZSA9IHNlbGVjdGVkTWVldHVwLnRpdGxlO1xyXG4gICAgICBzdWJ0aXRsZSA9IHNlbGVjdGVkTWVldHVwLnN1YnRpdGxlO1xyXG4gICAgICBhZGRyZXNzID0gc2VsZWN0ZWRNZWV0dXAuYWRkcmVzcztcclxuICAgICAgZW1haWwgPSBzZWxlY3RlZE1lZXR1cC5jb250YWN0RW1haWw7XHJcbiAgICAgIGRlc2NyaXB0aW9uID0gc2VsZWN0ZWRNZWV0dXAuZGVzY3JpcHRpb247XHJcbiAgICAgIGltYWdlVXJsID0gc2VsZWN0ZWRNZWV0dXAuaW1hZ2VVcmw7XHJcbiAgICB9KTtcclxuICAgIHVuc3Vic2NyaWJlKCk7XHJcbiAgfVxyXG5cclxuICBjb25zdCBkaXNwYXRjaCA9IGNyZWF0ZUV2ZW50RGlzcGF0Y2hlcigpO1xyXG5cclxuICAkOiB0aXRsZVZhbGlkID0gIW5vdEVtcHR5KHRpdGxlKTtcclxuICAkOiBzdWJ0aXRsZVZhbGlkID0gIW5vdEVtcHR5KHN1YnRpdGxlKTtcclxuICAkOiBhZGRyZXNzVmFsaWQgPSAhbm90RW1wdHkoYWRkcmVzcyk7XHJcbiAgJDogZW1haWxWYWxpZCA9ICFpc1ZhbGlkRW1haWwoZW1haWwpO1xyXG4gICQ6IGRlc2NyaXB0aW9uVmFsaWQgPSAhbm90RW1wdHkoZGVzY3JpcHRpb24pO1xyXG4gICQ6IGltYWdlVXJsVmFsaWQgPSAhbm90RW1wdHkoaW1hZ2VVcmwpO1xyXG4gICQ6IGZvcm1Jc1ZhbGlkID1cclxuICAgIHRpdGxlVmFsaWQgJiZcclxuICAgIHN1YnRpdGxlVmFsaWQgJiZcclxuICAgIGFkZHJlc3NWYWxpZCAmJlxyXG4gICAgZW1haWxWYWxpZCAmJlxyXG4gICAgZGVzY3JpcHRpb25WYWxpZCAmJlxyXG4gICAgaW1hZ2VVcmxWYWxpZDtcclxuXHJcbiAgZnVuY3Rpb24gc3VibWl0Rm9ybSgpIHtcclxuICAgIGNvbnN0IG1lZXR1cERhdGEgPSB7XHJcbiAgICAgIHRpdGxlLFxyXG4gICAgICBzdWJ0aXRsZSxcclxuICAgICAgYWRkcmVzcyxcclxuICAgICAgZW1haWwsXHJcbiAgICAgIGRlc2NyaXB0aW9uLFxyXG4gICAgICBpbWFnZVVybCxcclxuICAgIH07XHJcblxyXG4gICAgaWYgKGlkKSB7XHJcbiAgICAgIGZldGNoKFxyXG4gICAgICAgIGBodHRwczovL3N2ZWx0ZS1jb3Vyc2UtZG9sZXMtZGVmYXVsdC1ydGRiLmZpcmViYXNlaW8uY29tL21lZXR1cHMvJHtpZH0uanNvbmAsXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgbWV0aG9kOiAnUEFUQ0gnLFxyXG4gICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkobWVldHVwRGF0YSksXHJcbiAgICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgICAgICAudGhlbigocmVzKSA9PiB7XHJcbiAgICAgICAgICBpZiAoIXJlcy5vaykge1xyXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ZhaWxlZCEnKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIG1lZXR1cHMudXBkYXRlTWVldHVwKGlkLCBtZWV0dXBEYXRhKTtcclxuICAgICAgICB9KVxyXG4gICAgICAgIC5jYXRjaCgoZXJyKSA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZmV0Y2goXHJcbiAgICAgICAgJ2h0dHBzOi8vc3ZlbHRlLWNvdXJzZS1kb2xlcy1kZWZhdWx0LXJ0ZGIuZmlyZWJhc2Vpby5jb20vbWVldHVwcy5qc29uJyxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgLi4ubWVldHVwRGF0YSwgaXNGYXZvcml0ZTogZmFsc2UgfSksXHJcbiAgICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgICAgICAudGhlbigocmVzKSA9PiB7XHJcbiAgICAgICAgICBpZiAoIXJlcy5vaykge1xyXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ZhaWxlZCEnKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHJldHVybiByZXMuanNvbigpO1xyXG4gICAgICAgIH0pXHJcbiAgICAgICAgLnRoZW4oKGRhdGEpID0+IHtcclxuICAgICAgICAgIG1lZXR1cHMuYWRkTWVldHVwKHtcclxuICAgICAgICAgICAgLi4ubWVldHVwRGF0YSxcclxuICAgICAgICAgICAgaXNGYXZvcml0ZTogZmFsc2UsXHJcbiAgICAgICAgICAgIGlkOiBkYXRhLm5hbWUsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9KVxyXG4gICAgICAgIC5jYXRjaCgoZXJyKSA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgZGlzcGF0Y2goJ3NhdmUnKTtcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIGNhbmNlbCgpIHtcclxuICAgIGRpc3BhdGNoKCdjYW5jZWwnKTtcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIGRlbGV0ZU1lZXR1cCgpIHtcclxuICAgIGZldGNoKFxyXG4gICAgICBgaHR0cHM6Ly9zdmVsdGUtY291cnNlLWRvbGVzLWRlZmF1bHQtcnRkYi5maXJlYmFzZWlvLmNvbS9tZWV0dXBzLyR7aWR9Lmpzb25gLFxyXG4gICAgICB7IG1ldGhvZDogJ0RFTEVURScgfVxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzKSA9PiB7XHJcbiAgICAgICAgaWYgKCFyZXMub2spIHtcclxuICAgICAgICAgIHRocm93IG5ldyBFcnJvcignRmFpbGVkIScpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBtZWV0dXBzLnJlbW92ZU1lZXR1cChpZCk7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiBjb25zb2xlLmxvZyhlcnIpKTtcclxuICAgIGRpc3BhdGNoKCdzYXZlJyk7XHJcbiAgfVxyXG48L3NjcmlwdD5cclxuXHJcbjxNb2RhbCB0aXRsZT1cIkVkaXQgTWVldHVwIERhdGFcIiBvbjpjYW5jZWw+XHJcbiAgPGZvcm0gb246c3VibWl0fHByZXZlbnREZWZhdWx0PXtzdWJtaXRGb3JtfT5cclxuICAgIDxUZXh0SW5wdXRcclxuICAgICAgaWQ9XCJ0aXRsZVwiXHJcbiAgICAgIGxhYmVsPVwiVGl0bGVcIlxyXG4gICAgICB2YWxpZD17dGl0bGVWYWxpZH1cclxuICAgICAgdmFsaWRpdHlNZXNzYWdlPVwiUGxlYXNlIGVudGVyIGEgdmFsaWQgdGl0bGVcIlxyXG4gICAgICB2YWx1ZT17dGl0bGV9XHJcbiAgICAgIG9uOmlucHV0PXsoZXZlbnQpID0+ICh0aXRsZSA9IGV2ZW50LnRhcmdldC52YWx1ZSl9XHJcbiAgICAvPlxyXG4gICAgPFRleHRJbnB1dFxyXG4gICAgICBpZD1cInN1YnRpdGxlXCJcclxuICAgICAgbGFiZWw9XCJTdWJ0aXRsZVwiXHJcbiAgICAgIHZhbGlkPXtzdWJ0aXRsZVZhbGlkfVxyXG4gICAgICB2YWxpZGl0eU1lc3NhZ2U9XCJQbGVhc2UgZW50ZXIgYSB2YWxpZCBzdWJ0aXRsZVwiXHJcbiAgICAgIHZhbHVlPXtzdWJ0aXRsZX1cclxuICAgICAgb246aW5wdXQ9eyhldmVudCkgPT4gKHN1YnRpdGxlID0gZXZlbnQudGFyZ2V0LnZhbHVlKX1cclxuICAgIC8+XHJcbiAgICA8VGV4dElucHV0XHJcbiAgICAgIGlkPVwiYWRkcmVzc1wiXHJcbiAgICAgIGxhYmVsPVwiQWRyZXNzXCJcclxuICAgICAgdmFsaWQ9e2FkZHJlc3NWYWxpZH1cclxuICAgICAgdmFsaWRpdHlNZXNzYWdlPVwiUGxlYXNlIGVudGVyIGEgdmFsaWQgYWRkcmVzc1wiXHJcbiAgICAgIHZhbHVlPXthZGRyZXNzfVxyXG4gICAgICBvbjppbnB1dD17KGV2ZW50KSA9PiAoYWRkcmVzcyA9IGV2ZW50LnRhcmdldC52YWx1ZSl9XHJcbiAgICAvPlxyXG4gICAgPFRleHRJbnB1dFxyXG4gICAgICBpZD1cImltYWdlVXJsXCJcclxuICAgICAgbGFiZWw9XCJJbWFnZSBVUkxcIlxyXG4gICAgICB2YWxpZD17aW1hZ2VVcmxWYWxpZH1cclxuICAgICAgdmFsaWRpdHlNZXNzYWdlPVwiUGxlYXNlIGVudGVyIGEgdmFsaWQgaW1hZ2UgdXJsXCJcclxuICAgICAgdmFsdWU9e2ltYWdlVXJsfVxyXG4gICAgICBvbjppbnB1dD17KGV2ZW50KSA9PiAoaW1hZ2VVcmwgPSBldmVudC50YXJnZXQudmFsdWUpfVxyXG4gICAgLz5cclxuICAgIDxUZXh0SW5wdXRcclxuICAgICAgaWQ9XCJlbWFpbFwiXHJcbiAgICAgIGxhYmVsPVwiRW1haWxcIlxyXG4gICAgICB2YWxpZD17ZW1haWxWYWxpZH1cclxuICAgICAgdmFsaWRpdHlNZXNzYWdlPVwiUGxlYXNlIGVudGVyIGEgdmFsaWQgZW1haWwgYWRkcmVzc1wiXHJcbiAgICAgIHR5cGU9XCJlbWFpbFwiXHJcbiAgICAgIHZhbHVlPXtlbWFpbH1cclxuICAgICAgb246aW5wdXQ9eyhldmVudCkgPT4gKGVtYWlsID0gZXZlbnQudGFyZ2V0LnZhbHVlKX1cclxuICAgIC8+XHJcbiAgICA8VGV4dElucHV0XHJcbiAgICAgIGlkPVwiZGVzY3JpcHRpb25cIlxyXG4gICAgICBsYWJlbD1cIkRlc2NyaXB0aW9uXCJcclxuICAgICAgdmFsaWQ9e2Rlc2NyaXB0aW9uVmFsaWR9XHJcbiAgICAgIHZhbGlkaXR5TWVzc2FnZT1cIlBsZWFzZSBlbnRlciBhIHZhbGlkIGRlc2NyaXB0aW9uXCJcclxuICAgICAgY29udHJvbFR5cGU9XCJ0ZXh0YXJlYVwiXHJcbiAgICAgIHJvd3M9XCIzXCJcclxuICAgICAgYmluZDp2YWx1ZT17ZGVzY3JpcHRpb259XHJcbiAgICAvPlxyXG4gIDwvZm9ybT5cclxuICA8ZGl2IHNsb3Q9XCJmb290ZXJcIj5cclxuICAgIDxCdXR0b24gdHlwZT1cImJ1dHRvblwiIG1vZGU9XCJvdXRsaW5lXCIgb246Y2xpY2s9e2NhbmNlbH0+Q2FuY2VsPC9CdXR0b24+XHJcbiAgICA8QnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbjpjbGljaz17c3VibWl0Rm9ybX0gZGlzYWJsZWQ9eyFmb3JtSXNWYWxpZH1cclxuICAgICAgPlNhdmU8L0J1dHRvblxyXG4gICAgPlxyXG4gICAgeyNpZiBpZH1cclxuICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb246Y2xpY2s9e2RlbGV0ZU1lZXR1cH0+RGVsZXRlPC9CdXR0b24+XHJcbiAgICB7L2lmfVxyXG4gIDwvZGl2PlxyXG48L01vZGFsPlxyXG5cclxuPHN0eWxlPlxyXG4gIGZvcm0ge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgfVxyXG48L3N0eWxlPlxyXG4iLCI8c2NyaXB0IGNvbnRleHQ9XCJtb2R1bGVcIj5cclxuICBleHBvcnQgZnVuY3Rpb24gcHJlbG9hZChwYWdlKSB7XHJcbiAgICBjb25zb2xlLmxvZyhwYWdlKTtcclxuICAgIHJldHVybiB0aGlzLmZldGNoKFxyXG4gICAgICAnaHR0cHM6Ly9zdmVsdGUtY291cnNlLWRvbGVzLWRlZmF1bHQtcnRkYi5maXJlYmFzZWlvLmNvbS9tZWV0dXBzLmpzb24nXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXMpID0+IHtcclxuICAgICAgICBpZiAoIXJlcy5vaykge1xyXG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdGZXRjaGluZyBtZWV0dXBzIGZhaWxlZCwgcGxlYXNlIHRyeSBhZ2FpbiBsYXRlci4nKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHJlcy5qc29uKCk7XHJcbiAgICAgIH0pXHJcbiAgICAgIC50aGVuKChkYXRhKSA9PiB7XHJcbiAgICAgICAgY29uc3QgZmV0Y2hlZE1lZXR1cHMgPSBbXTtcclxuICAgICAgICBmb3IgKGNvbnN0IGtleSBpbiBkYXRhKSB7XHJcbiAgICAgICAgICBmZXRjaGVkTWVldHVwcy5wdXNoKHsgaWQ6IGtleSwgLi4uZGF0YVtrZXldIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4geyBmZXRjaGVkTWVldHVwczogZmV0Y2hlZE1lZXR1cHMucmV2ZXJzZSgpIH07XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiB7XHJcbiAgICAgICAgZXJyb3IgPSBlcnI7XHJcbiAgICAgICAgY29uc29sZS5sb2coZXJyKTtcclxuICAgICAgICB0aGlzLmVycm9yKDUwMCwgJ0NvdWxkIG5vdGUgZmV0Y2ggbWVldHVwcycpO1xyXG4gICAgICB9KTtcclxuICB9XHJcbjwvc2NyaXB0PlxyXG5cclxuPHNjcmlwdD5cclxuICBpbXBvcnQgeyBjcmVhdGVFdmVudERpc3BhdGNoZXIsIG9uRGVzdHJveSwgb25Nb3VudCB9IGZyb20gJ3N2ZWx0ZSc7XHJcbiAgaW1wb3J0IHsgc2NhbGUgfSBmcm9tICdzdmVsdGUvdHJhbnNpdGlvbic7XHJcbiAgaW1wb3J0IHsgZmxpcCB9IGZyb20gJ3N2ZWx0ZS9hbmltYXRlJztcclxuICBpbXBvcnQgbWVldHVwcyBmcm9tICcuLi9tZXR0dXBzLXN0b3JlJztcclxuICBpbXBvcnQgTWVldHVwSXRlbSBmcm9tICcuLi9jb21wb25lbnRzL01lZXR1cHMvTWVldHVwSXRlbS5zdmVsdGUnO1xyXG4gIGltcG9ydCBNZWV0dXBGaWx0ZXIgZnJvbSAnLi4vY29tcG9uZW50cy9NZWV0dXBzL01lZXR1cEZpbHRlci5zdmVsdGUnO1xyXG4gIGltcG9ydCBCdXR0b24gZnJvbSAnLi4vY29tcG9uZW50cy9VSS9CdXR0b24uc3ZlbHRlJztcclxuICBpbXBvcnQgRWRpdE1lZXR1cCBmcm9tICcuLi9jb21wb25lbnRzL01lZXR1cHMvRWRpdE1lZXR1cC5zdmVsdGUnO1xyXG4gIGltcG9ydCBTcGlubmVyIGZyb20gJy4uL2NvbXBvbmVudHMvVUkvU3Bpbm5lci5zdmVsdGUnO1xyXG5cclxuICBleHBvcnQgbGV0IGZldGNoZWRNZWV0dXBzO1xyXG4gIGxldCBlZGl0TW9kZTtcclxuICBsZXQgZWRpdGVkSWQ7XHJcbiAgbGV0IGlzTG9hZGluZztcclxuICBsZXQgZmF2c09ubHkgPSBmYWxzZTtcclxuICBsZXQgdW5zdWJzY3JpYmU7XHJcblxyXG4gICQ6IGZpbHRlcmVkTWVldHVwcyA9IGZhdnNPbmx5XHJcbiAgICA/IGZldGNoZWRNZWV0dXBzLmZpbHRlcigobSkgPT4gbS5pc0Zhdm9yaXRlKVxyXG4gICAgOiBmZXRjaGVkTWVldHVwcztcclxuXHJcbiAgY29uc3QgZGlzcGF0Y2ggPSBjcmVhdGVFdmVudERpc3BhdGNoZXIoKTtcclxuXHJcbiAgb25Nb3VudCgoKSA9PiB7XHJcbiAgICBtZWV0dXBzLnNldE1lZXR1cHMoZmV0Y2hlZE1lZXR1cHMpO1xyXG4gICAgdW5zdWJzY3JpYmUgPSBtZWV0dXBzLnN1YnNjcmliZSgoaXRlbXMpID0+IHtcclxuICAgICAgZmV0Y2hlZE1lZXR1cHMgPSBpdGVtcztcclxuICAgIH0pO1xyXG4gIH0pO1xyXG5cclxuICBvbkRlc3Ryb3koKCkgPT4ge1xyXG4gICAgaWYgKHVuc3Vic2NyaWJlKSB7XHJcbiAgICAgIHVuc3Vic2NyaWJlKCk7XHJcbiAgICB9XHJcbiAgfSk7XHJcblxyXG4gIGZ1bmN0aW9uIHNldEZpbHRlcihldmVudCkge1xyXG4gICAgZmF2c09ubHkgPSBldmVudC5kZXRhaWwgPT09IDE7XHJcbiAgfVxyXG5cclxuICBmdW5jdGlvbiBzYXZlZE1lZXR1cChldmVudCkge1xyXG4gICAgZWRpdE1vZGUgPSBudWxsO1xyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gY2FuY2VsRWRpdCgpIHtcclxuICAgIGVkaXRNb2RlID0gbnVsbDtcclxuICAgIGVkaXRlZElkID0gbnVsbDtcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIHN0YXJ0RWRpdChldmVudCkge1xyXG4gICAgZWRpdE1vZGUgPSAnZWRpdCc7XHJcbiAgICBlZGl0ZWRJZCA9IGV2ZW50LmRldGFpbDtcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIHN0YXJ0QWRkKGV2ZW50KSB7XHJcbiAgICBlZGl0TW9kZSA9ICdlZGl0JztcclxuICB9XHJcbjwvc2NyaXB0PlxyXG5cclxuPHN2ZWx0ZTpoZWFkPlxyXG4gIDx0aXRsZT5BbGwgTWVldHVwczwvdGl0bGU+XHJcbjwvc3ZlbHRlOmhlYWQ+XHJcblxyXG57I2lmIGVkaXRNb2RlID09PSAnZWRpdCd9XHJcbiAgPEVkaXRNZWV0dXAgaWQ9e2VkaXRlZElkfSBvbjpzYXZlPXtzYXZlZE1lZXR1cH0gb246Y2FuY2VsPXtjYW5jZWxFZGl0fSAvPlxyXG57L2lmfVxyXG57I2lmIGlzTG9hZGluZ31cclxuICA8U3Bpbm5lciAvPlxyXG57OmVsc2V9XHJcbiAgPHNlY3Rpb24gaWQ9XCJtZWV0dXAtY29udHJvbHNcIj5cclxuICAgIDxNZWV0dXBGaWx0ZXIgb246c2VsZWN0PXtzZXRGaWx0ZXJ9IC8+XHJcbiAgICA8QnV0dG9uIG9uOmNsaWNrPXtzdGFydEFkZH0+TmV3IE1lZXR1cDwvQnV0dG9uPlxyXG4gIDwvc2VjdGlvbj5cclxuICB7I2lmIGZpbHRlcmVkTWVldHVwcy5sZW5ndGggPT09IDB9XHJcbiAgICA8cCBpZD1cIm5vLW1lZXR1cHNcIj5ObyBNZWV0dXBzLCB5b3UgbWF5IHN0YXJ0IGFkZGluZyBzb21lLjwvcD5cclxuICB7L2lmfVxyXG4gIDxzZWN0aW9uIGlkPVwibWVldHVwc1wiPlxyXG4gICAgeyNlYWNoIGZpbHRlcmVkTWVldHVwcyBhcyBtZWV0dXAgKG1lZXR1cC5pZCl9XHJcbiAgICAgIDxkaXYgdHJhbnNpdGlvbjpzY2FsZSBhbmltYXRlOmZsaXA9e3sgZHVyYXRpb246IDMwMCB9fT5cclxuICAgICAgICA8TWVldHVwSXRlbVxyXG4gICAgICAgICAgaWQ9e21lZXR1cC5pZH1cclxuICAgICAgICAgIHRpdGxlPXttZWV0dXAudGl0bGV9XHJcbiAgICAgICAgICBzdWJ0aXRsZT17bWVldHVwLnN1YnRpdGxlfVxyXG4gICAgICAgICAgZGVzY3JpcHRpb249e21lZXR1cC5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgIGltYWdlVXJsPXttZWV0dXAuaW1hZ2VVcmx9XHJcbiAgICAgICAgICBhZGRyZXNzPXttZWV0dXAuZGVzY3JpcHRpb259XHJcbiAgICAgICAgICBlbWFpbD17bWVldHVwLmNvbnRhY3RFbWFpbH1cclxuICAgICAgICAgIGlzRmF2PXttZWV0dXAuaXNGYXZvcml0ZX1cclxuICAgICAgICAgIG9uOmVkaXQ9e3N0YXJ0RWRpdH1cclxuICAgICAgICAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIHsvZWFjaH1cclxuICA8L3NlY3Rpb24+XHJcbnsvaWZ9XHJcblxyXG48c3R5bGU+XHJcbiAgI21lZXR1cC1jb250cm9scyB7XHJcbiAgICBtYXJnaW46IDFyZW07XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gIH1cclxuICAjbm8tbWVldHVwcyB7XHJcbiAgICBtYXJnaW46IDFyZW07XHJcbiAgfVxyXG5cclxuICAjbWVldHVwcyB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGRpc3BsYXk6IGdyaWQ7XHJcbiAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmcjtcclxuICAgIGdyaWQtZ2FwOiAxcmVtO1xyXG4gIH1cclxuXHJcbiAgQG1lZGlhIChtaW4td2lkdGg6IDc2OHB4KSB7XHJcbiAgICAjbWVldHVwcyB7XHJcbiAgICAgIGdyaWQtdGVtcGxhdGUtY29sdW1uczogcmVwZWF0KDIsIDFmcik7XHJcbiAgICB9XHJcbiAgfVxyXG48L3N0eWxlPlxyXG4iXSwibmFtZXMiOlsibGluZWFyIiwibWVldHVwcyJdLCJtYXBwaW5ncyI6Ijs7O0FBNkRBLFNBQVMsUUFBUSxDQUFDLENBQUMsRUFBRTtBQUNyQixJQUFJLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUM7QUFDdEIsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQztBQUMzQjs7QUN0QkEsU0FBUyxJQUFJLENBQUMsSUFBSSxFQUFFLEVBQUUsS0FBSyxHQUFHLENBQUMsRUFBRSxRQUFRLEdBQUcsR0FBRyxFQUFFLE1BQU0sR0FBR0EsUUFBTSxFQUFFLEdBQUcsRUFBRSxFQUFFO0FBQ3pFLElBQUksTUFBTSxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDOUMsSUFBSSxPQUFPO0FBQ1gsUUFBUSxLQUFLO0FBQ2IsUUFBUSxRQUFRO0FBQ2hCLFFBQVEsTUFBTTtBQUNkLFFBQVEsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDckMsS0FBSyxDQUFDO0FBQ04sQ0FBQztBQUNELFNBQVMsR0FBRyxDQUFDLElBQUksRUFBRSxFQUFFLEtBQUssR0FBRyxDQUFDLEVBQUUsUUFBUSxHQUFHLEdBQUcsRUFBRSxNQUFNLEdBQUcsUUFBUSxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxPQUFPLEdBQUcsQ0FBQyxFQUFFLEdBQUcsRUFBRSxFQUFFO0FBQ3JHLElBQUksTUFBTSxLQUFLLEdBQUcsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDekMsSUFBSSxNQUFNLGNBQWMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7QUFDMUMsSUFBSSxNQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsU0FBUyxLQUFLLE1BQU0sR0FBRyxFQUFFLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQztBQUN4RSxJQUFJLE1BQU0sRUFBRSxHQUFHLGNBQWMsSUFBSSxDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUM7QUFDOUMsSUFBSSxPQUFPO0FBQ1gsUUFBUSxLQUFLO0FBQ2IsUUFBUSxRQUFRO0FBQ2hCLFFBQVEsTUFBTTtBQUNkLFFBQVEsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDO0FBQ3hCLGNBQWMsRUFBRSxTQUFTLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDckUsWUFBWSxFQUFFLGNBQWMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QyxLQUFLLENBQUM7QUFDTixDQUFDO0FBQ0QsU0FBUyxLQUFLLENBQUMsSUFBSSxFQUFFLEVBQUUsS0FBSyxHQUFHLENBQUMsRUFBRSxRQUFRLEdBQUcsR0FBRyxFQUFFLE1BQU0sR0FBRyxRQUFRLEVBQUUsR0FBRyxFQUFFLEVBQUU7QUFDNUUsSUFBSSxNQUFNLEtBQUssR0FBRyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN6QyxJQUFJLE1BQU0sT0FBTyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztBQUNuQyxJQUFJLE1BQU0sTUFBTSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDNUMsSUFBSSxNQUFNLFdBQVcsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3JELElBQUksTUFBTSxjQUFjLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUMzRCxJQUFJLE1BQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDbkQsSUFBSSxNQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ3pELElBQUksTUFBTSxnQkFBZ0IsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0FBQzlELElBQUksTUFBTSxtQkFBbUIsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUM7QUFDcEUsSUFBSSxPQUFPO0FBQ1gsUUFBUSxLQUFLO0FBQ2IsUUFBUSxRQUFRO0FBQ2hCLFFBQVEsTUFBTTtBQUNkLFFBQVEsR0FBRyxFQUFFLENBQUMsSUFBSSxtQkFBbUI7QUFDckMsWUFBWSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUN4RCxZQUFZLENBQUMsUUFBUSxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDO0FBQ3RDLFlBQVksQ0FBQyxhQUFhLEVBQUUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUM7QUFDaEQsWUFBWSxDQUFDLGdCQUFnQixFQUFFLENBQUMsR0FBRyxjQUFjLENBQUMsR0FBRyxDQUFDO0FBQ3RELFlBQVksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUM7QUFDOUMsWUFBWSxDQUFDLGVBQWUsRUFBRSxDQUFDLEdBQUcsYUFBYSxDQUFDLEdBQUcsQ0FBQztBQUNwRCxZQUFZLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxHQUFHLGdCQUFnQixDQUFDLEdBQUcsQ0FBQztBQUMxRCxZQUFZLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxHQUFHLG1CQUFtQixDQUFDLEdBQUcsQ0FBQztBQUNoRSxLQUFLLENBQUM7QUFDTixDQUFDO0FBQ0QsU0FBUyxLQUFLLENBQUMsSUFBSSxFQUFFLEVBQUUsS0FBSyxHQUFHLENBQUMsRUFBRSxRQUFRLEdBQUcsR0FBRyxFQUFFLE1BQU0sR0FBRyxRQUFRLEVBQUUsS0FBSyxHQUFHLENBQUMsRUFBRSxPQUFPLEdBQUcsQ0FBQyxFQUFFLEdBQUcsRUFBRSxFQUFFO0FBQ3BHLElBQUksTUFBTSxLQUFLLEdBQUcsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDekMsSUFBSSxNQUFNLGNBQWMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7QUFDMUMsSUFBSSxNQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsU0FBUyxLQUFLLE1BQU0sR0FBRyxFQUFFLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQztBQUN4RSxJQUFJLE1BQU0sRUFBRSxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUM7QUFDekIsSUFBSSxNQUFNLEVBQUUsR0FBRyxjQUFjLElBQUksQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDO0FBQzlDLElBQUksT0FBTztBQUNYLFFBQVEsS0FBSztBQUNiLFFBQVEsUUFBUTtBQUNoQixRQUFRLE1BQU07QUFDZCxRQUFRLEdBQUcsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLEtBQUssQ0FBQztBQUN6QixjQUFjLEVBQUUsU0FBUyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ2hELFlBQVksRUFBRSxjQUFjLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLEVBQUUsQ0FBQztBQUNILEtBQUssQ0FBQztBQUNOLENBQUM7O0FDdEdELFNBQVMsSUFBSSxDQUFDLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsRUFBRSxNQUFNLEdBQUcsRUFBRSxFQUFFO0FBQy9DLElBQUksTUFBTSxLQUFLLEdBQUcsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDekMsSUFBSSxNQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsU0FBUyxLQUFLLE1BQU0sR0FBRyxFQUFFLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQztBQUN4RSxJQUFJLE1BQU0sQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RFLElBQUksTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQyxLQUFLLEtBQUssRUFBRSxDQUFDLElBQUksR0FBRyxFQUFFLENBQUMsQ0FBQztBQUN6RSxJQUFJLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUMsTUFBTSxLQUFLLEVBQUUsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDekUsSUFBSSxNQUFNLEVBQUUsS0FBSyxHQUFHLENBQUMsRUFBRSxRQUFRLEdBQUcsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEVBQUUsTUFBTSxHQUFHLFFBQVEsRUFBRSxHQUFHLE1BQU0sQ0FBQztBQUMxRixJQUFJLE9BQU87QUFDWCxRQUFRLEtBQUs7QUFDYixRQUFRLFFBQVEsRUFBRSxXQUFXLENBQUMsUUFBUSxDQUFDLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsR0FBRyxRQUFRO0FBQzNGLFFBQVEsTUFBTTtBQUNkLFFBQVEsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSztBQUN2QixZQUFZLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUM7QUFDN0IsWUFBWSxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDO0FBQzdCLFlBQVksTUFBTSxFQUFFLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUM7QUFDckQsWUFBWSxNQUFNLEVBQUUsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQztBQUN2RCxZQUFZLE9BQU8sQ0FBQyxXQUFXLEVBQUUsU0FBUyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDNUYsU0FBUztBQUNULEtBQUssQ0FBQztBQUNOLENBQUM7O0FDcEJELE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUM3QjtBQUNBLE1BQU0sa0JBQWtCLEdBQUc7QUFDM0IsRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDLFNBQVM7QUFDOUIsRUFBRSxVQUFVLEVBQUUsQ0FBQyxLQUFLLEtBQUs7QUFDekIsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3ZCLEdBQUc7QUFDSCxFQUFFLFNBQVMsRUFBRSxDQUFDLFVBQVUsS0FBSztBQUM3QixJQUFJLE1BQU0sU0FBUyxHQUFHO0FBQ3RCLE1BQU0sR0FBRyxVQUFVO0FBQ25CLEtBQUssQ0FBQztBQUNOLElBQUksT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssS0FBSyxDQUFDLFNBQVMsRUFBRSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDckQsR0FBRztBQUNILEVBQUUsWUFBWSxFQUFFLENBQUMsRUFBRSxFQUFFLFVBQVUsS0FBSztBQUNwQyxJQUFJLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLEtBQUs7QUFDOUIsTUFBTSxNQUFNLFdBQVcsR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7QUFDOUQsTUFBTSxNQUFNLGFBQWEsR0FBRyxFQUFFLEdBQUcsS0FBSyxDQUFDLFdBQVcsQ0FBQyxFQUFFLEdBQUcsVUFBVSxFQUFFLENBQUM7QUFDckUsTUFBTSxNQUFNLGNBQWMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUM7QUFDeEMsTUFBTSxjQUFjLENBQUMsV0FBVyxDQUFDLEdBQUcsYUFBYSxDQUFDO0FBQ2xELE1BQU0sT0FBTyxjQUFjLENBQUM7QUFDNUIsS0FBSyxDQUFDLENBQUM7QUFDUCxHQUFHO0FBQ0gsRUFBRSxZQUFZLEVBQUUsQ0FBQyxFQUFFLEtBQUs7QUFDeEIsSUFBSSxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxLQUFLO0FBQzlCLE1BQU0sT0FBTyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7QUFDOUMsS0FBSyxDQUFDLENBQUM7QUFDUCxHQUFHO0FBQ0gsRUFBRSxjQUFjLEVBQUUsQ0FBQyxFQUFFLEtBQUs7QUFDMUIsSUFBSSxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxLQUFLO0FBQzlCLE1BQU0sTUFBTSxhQUFhLEdBQUcsRUFBRSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFDO0FBQ2xFLE1BQU0sYUFBYSxDQUFDLFVBQVUsR0FBRyxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUM7QUFDM0QsTUFBTSxNQUFNLFdBQVcsR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7QUFDOUQsTUFBTSxNQUFNLGNBQWMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUM7QUFDeEMsTUFBTSxjQUFjLENBQUMsV0FBVyxDQUFDLEdBQUcsYUFBYSxDQUFDO0FBQ2xELE1BQU0sT0FBTyxjQUFjLENBQUM7QUFDNUIsS0FBSyxDQUFDLENBQUM7QUFDUCxHQUFHO0FBQ0gsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0NuQ0Ysb0JBQXNDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0NKdEMsb0JBT007R0FOSixvQkFLTTtHQUpKLG9CQUFPOztHQUNQLG9CQUFPOztHQUNQLG9CQUFPOztHQUNQLG9CQUFPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQzJDSSxVQUFROzs7eUJBQVIsVUFBUTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBY2hCLE1BQUk7Ozt5QkFBSixNQUFJOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7cUJBU0ksR0FBSyxNQUFHLElBQUksR0FBRyxTQUFTOzs7Ozs7O3dDQUNyQixHQUFjOzs7Ozs7Ozs7Ozs7Ozs7OERBRGpCLEdBQUssTUFBRyxJQUFJLEdBQUcsU0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFMM0IsYUFBVzs7Ozs7OzhCQUFYLGFBQVc7Ozs7Ozs7O0dBQWpCLG9CQUF3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzBCQU1LLEdBQUssTUFBRyxZQUFZLEdBQUcsVUFBVTs7Ozs7Ozs7Ozs7Ozs7aUVBQWpDLEdBQUssTUFBRyxZQUFZLEdBQUcsVUFBVTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBSTdELGNBQVk7Ozt5QkFBWixjQUFZOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzsyQkE3QlIsR0FBSzs7Ozs7Ozs7Ozs7Ozs7Ozs7b0JBaUJQLEdBQVM7Ozs7Ozs7Ozs7O3VCQVd1QyxHQUFFOzs7Ozs7Ozs7Ozs7dUJBN0JwRCxHQUFLOzs7OzswQkFLSCxHQUFROzs7eUJBQ1QsR0FBTzs7Ozs7Ozs2QkFNUCxHQUFXOzs7Ozs7Ozs7Ozs7Ozs7Ozt1Q0FaWixHQUFLOzs7Ozs7OzBDQUtILEdBQVE7Ozs7O3lDQUNULEdBQU87Ozs7Ozs7Ozs7Ozs7NkNBTVAsR0FBVzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzREQUhMLEdBQVE7a0NBQU8sR0FBSzs7Ozs7Ozs7Ozs7Ozs7O0dBWmxDLG9CQW9DVTtHQW5DUixvQkFTUztHQVJQLG9CQUtLOzs7OztHQUNMLG9CQUFtQjs7O0dBQ25CLG9CQUFnQjs7O0dBRWxCLG9CQUVNO0dBREosb0JBQWtDOztHQUVwQyxvQkFFTTtHQURKLG9CQUFvQjs7O0dBRXRCLG9CQWtCUzs7Ozs7Ozs7O21FQWhDSixHQUFLOztpQkFDRCxHQUFLOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7eUVBSVAsR0FBUTt3RUFDVCxHQUFPOztrR0FHRCxHQUFROzs7OzttQ0FBTyxHQUFLOzs7Z0ZBRzFCLEdBQVc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzZEQWlCc0MsR0FBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQXBFOUMsRUFBRTtPQUNGLEtBQUs7T0FDTCxRQUFRO09BQ1IsUUFBUTtPQUNSLFdBQVc7T0FDWCxPQUFPO09BQ1AsS0FBSztPQUNMLEtBQUs7S0FFWixTQUFTLEdBQUcsS0FBSztPQUVmLFFBQVEsR0FBRyxxQkFBcUI7O1VBRTdCLGNBQWMsQ0FBQyxLQUFLO2tCQUMzQixTQUFTLEdBQUcsSUFBSTs7RUFDaEIsS0FBSyxvRUFDZ0UsRUFBRTtHQUVuRSxNQUFNLEVBQUUsT0FBTztHQUNmLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxHQUFHLFVBQVUsR0FBRyxLQUFLO0dBQ3pDLE9BQU8sSUFBSSxjQUFjLEVBQUUsa0JBQWtCO0tBRzlDLElBQUksQ0FBRSxHQUFHO1FBQ0gsR0FBRyxDQUFDLEVBQUU7Y0FDQyxLQUFLLENBQUMsU0FBUzs7O0dBRTNCQyxrQkFBTyxDQUFDLGNBQWMsQ0FBQyxFQUFFO0tBRTFCLEtBQUssQ0FBRSxHQUFHO0dBQ1QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHO0tBRWhCLE9BQU8sdUJBQVEsU0FBUyxHQUFHLEtBQUs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs2QkFzQmtCLFFBQVEsQ0FBQyxNQUFNLEVBQUUsRUFBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2FDOUNyRSxLQUFHOzs7YUFRSCxXQUFTOzs7Ozs7OztrQ0FSVCxLQUFHOzs7OztrQ0FRSCxXQUFTOzs7Ozs7OztzREFaRSxHQUFjLFFBQUssQ0FBQzs7OztzREFRcEIsR0FBYyxRQUFLLENBQUM7Ozs7OztHQVh0QyxvQkFpQk07R0FoQkosb0JBT0M7OztHQUNELG9CQU9DOzs7Ozs7Ozs7Ozs7Ozt1REFiZSxHQUFjLFFBQUssQ0FBQzs7Ozt1REFRcEIsR0FBYyxRQUFLLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BaEI5QixRQUFRLEdBQUcscUJBQXFCO0tBRWxDLGNBQWMsR0FBRyxDQUFDOzs7Ozs7OztrQkFRbEIsY0FBYyxHQUFHLENBQUM7RUFDbEIsUUFBUSxDQUFDLFFBQVEsRUFBRSxDQUFDOzs7O2tCQU9wQixjQUFjLEdBQUcsQ0FBQztFQUNsQixRQUFRLENBQUMsUUFBUSxFQUFFLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7NkNDR0osR0FBSyxtQkFBSSxHQUFPOzs7O0dBRGxDLG9CQU9FOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzhDQU5nQixHQUFLLG1CQUFJLEdBQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2dEQVJoQixHQUFLLG1CQUFJLEdBQU87Ozs7R0FEbEMsb0JBTUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lEQUxnQixHQUFLLG1CQUFJLEdBQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2dDQWlCUixHQUFlOzs7Ozs7K0NBQWYsR0FBZTs7Ozs7Ozs7O0dBQXpDLG9CQUE4Qzs7Ozs0RUFBcEIsR0FBZTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7c0JBbkJ0QyxHQUFXLFFBQUssVUFBVTs7Ozs7O3FDQWtCMUIsR0FBZSxrQkFBSyxHQUFLLG1CQUFJLEdBQU87Ozs7Ozt1QkFuQnhCLEdBQUs7Ozs7Ozs7Ozs7Ozs0Q0FBTCxHQUFLOzs7Ozs7Ozs7O21DQUFWLEdBQUU7Ozs7Ozs7R0FEaEIsb0JBdUJNO0dBdEJKLG9CQUErQjs7Ozs7Ozs7dURBQWQsR0FBSzs7O29DQUFWLEdBQUU7Ozs7Ozs7Ozs7Ozs7OzsyQkFtQlQsR0FBZSxrQkFBSyxHQUFLLG1CQUFJLEdBQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQWhDOUIsV0FBVyxHQUFHLElBQUk7T0FDbEIsRUFBRTtPQUNGLEtBQUs7T0FDTCxJQUFJLEdBQUcsSUFBSTtPQUNYLEtBQUs7T0FDTCxJQUFJLEdBQUcsTUFBTTtPQUNiLEtBQUssR0FBRyxJQUFJO09BQ1osZUFBZSxHQUFHLEVBQUU7S0FFM0IsT0FBTyxHQUFHLEtBQUs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRDQVdDLE9BQU8sR0FBRyxJQUFJOzhDQVNkLE9BQU8sR0FBRyxJQUFJOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lDWkEsT0FBSzs7O3lCQUFMLE9BQUs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7b0NBQWpCLEdBQVU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3VCQUozQixHQUFLOzs7Ozs7Ozs7Ozs7Ozs7Ozt1Q0FBTCxHQUFLOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBRlosb0JBQW9FOztHQUNwRSxvQkFRTTtHQVBKLG9CQUFnQjs7O0dBQ2hCLG9CQUFtQzs7Ozs7OztHQUNuQyxvQkFJUzs7Ozs7Ozs7O3VEQVIyQyxHQUFVOzs7OzttRUFFekQsR0FBSzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7eUZBRFcsQ0FBQyxFQUFFLEdBQUc7Ozs7Ozs7Ozs7O3dGQUFOLENBQUMsRUFBRSxHQUFHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BVGhCLEtBQUs7T0FDVixRQUFRLEdBQUcscUJBQXFCOztVQUU3QixVQUFVO0VBQ2pCLFFBQVEsQ0FBQyxRQUFROzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUmQsU0FBUyxRQUFRLENBQUMsR0FBRyxFQUFFO0FBQzlCLEVBQUUsT0FBTyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQztBQUNqQyxDQUFDO0FBQ0Q7QUFDQSxBQUFPLFNBQVMsWUFBWSxDQUFDLEdBQUcsRUFBRTtBQUNsQyxFQUFFLE9BQU8sSUFBSSxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzlDLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzswQkN5SFksR0FBVTs7cUJBRVYsR0FBSzs7Ozs7Ozs7Ozs7NkJBTUwsR0FBYTs7d0JBRWIsR0FBUTs7Ozs7Ozs7Ozs7NEJBTVIsR0FBWTs7dUJBRVosR0FBTzs7Ozs7Ozs7Ozs7NkJBTVAsR0FBYTs7d0JBRWIsR0FBUTs7Ozs7Ozs7Ozs7MEJBTVIsR0FBVTs7O3FCQUdWLEdBQUs7Ozs7Ozs7Ozs7Ozs7OzhCQU1MLEdBQWdCOzs7Ozs7cUJBSVgsR0FBVzsyQ0FBWCxHQUFXOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQWpEM0Isb0JBbURPOzs7Ozs7Ozs7Ozs7Ozs7d0VBbkR5QixHQUFVOzs7Ozs7OEVBSS9CLEdBQVU7aUVBRVYsR0FBSzs7O29GQU1MLEdBQWE7dUVBRWIsR0FBUTs7O2tGQU1SLEdBQVk7cUVBRVosR0FBTzs7O21GQU1QLEdBQWE7d0VBRWIsR0FBUTs7OzZFQU1SLEdBQVU7a0VBR1YsR0FBSzs7O3lGQU1MLEdBQWdCOzs7OytDQUlYLEdBQVc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFJOEIsUUFBTTs7O3lCQUFOLFFBQU07Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQUUxRCxNQUFJOzs7eUJBQUosTUFBSTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7c0NBRzJCLEdBQVk7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBQUUsUUFBTTs7O3lCQUFOLFFBQU07Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7aUNBTFAsR0FBTTs7Ozs7K0JBQ0UsR0FBVzs7Ozs7OztxQ0FBbEMsR0FBVTt1QkFHckMsR0FBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQUxULG9CQVFNOzs7Ozs7Ozs7Ozs7Ozs7OztpRkFObUQsR0FBVzs7Ozs7Ozs7Y0FHN0QsR0FBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0E1S0UsRUFBRSxHQUFHLElBQUk7S0FDaEIsS0FBSyxHQUFHLEVBQUU7S0FDVixRQUFRLEdBQUcsRUFBRTtLQUNiLE9BQU8sR0FBRyxFQUFFO0tBQ1osS0FBSyxHQUFHLEVBQUU7S0FDVixXQUFXLEdBQUcsRUFBRTtLQUNoQixRQUFRLEdBQUcsRUFBRTs7S0FFYixFQUFFO1FBQ0UsV0FBVyxHQUFHQSxrQkFBTyxDQUFDLFNBQVMsQ0FBRSxLQUFLO1NBQ3BDLGNBQWMsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFFLENBQUMsSUFBSyxDQUFDLENBQUMsRUFBRSxLQUFLLEVBQUU7bUJBQ3BELEtBQUssR0FBRyxjQUFjLENBQUMsS0FBSzttQkFDNUIsUUFBUSxHQUFHLGNBQWMsQ0FBQyxRQUFRO21CQUNsQyxPQUFPLEdBQUcsY0FBYyxDQUFDLE9BQU87bUJBQ2hDLEtBQUssR0FBRyxjQUFjLENBQUMsWUFBWTttQkFDbkMsV0FBVyxHQUFHLGNBQWMsQ0FBQyxXQUFXO21CQUN4QyxRQUFRLEdBQUcsY0FBYyxDQUFDLFFBQVE7OztFQUVwQyxXQUFXOzs7T0FHUCxRQUFRLEdBQUcscUJBQXFCOztVQWdCN0IsVUFBVTtRQUNYLFVBQVU7R0FDZCxLQUFLO0dBQ0wsUUFBUTtHQUNSLE9BQU87R0FDUCxLQUFLO0dBQ0wsV0FBVztHQUNYLFFBQVE7OztNQUdOLEVBQUU7R0FDSixLQUFLLG9FQUNnRSxFQUFFO0lBRW5FLE1BQU0sRUFBRSxPQUFPO0lBQ2YsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVTtJQUMvQixPQUFPLElBQUksY0FBYyxFQUFFLGtCQUFrQjtNQUc5QyxJQUFJLENBQUUsR0FBRztTQUNILEdBQUcsQ0FBQyxFQUFFO2VBQ0MsS0FBSyxDQUFDLFNBQVM7OztJQUUzQkEsa0JBQU8sQ0FBQyxZQUFZLENBQUMsRUFBRSxFQUFFLFVBQVU7TUFFcEMsS0FBSyxDQUFFLEdBQUc7SUFDVCxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUc7OztHQUduQixLQUFLLENBQ0gsc0VBQXNFO0lBRXBFLE1BQU0sRUFBRSxNQUFNO0lBQ2QsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLE1BQU0sVUFBVSxFQUFFLFVBQVUsRUFBRSxLQUFLO0lBQ3ZELE9BQU8sSUFBSSxjQUFjLEVBQUUsa0JBQWtCO01BRzlDLElBQUksQ0FBRSxHQUFHO1NBQ0gsR0FBRyxDQUFDLEVBQUU7ZUFDQyxLQUFLLENBQUMsU0FBUzs7O1dBRXBCLEdBQUcsQ0FBQyxJQUFJO01BRWhCLElBQUksQ0FBRSxJQUFJO0lBQ1RBLGtCQUFPLENBQUMsU0FBUztRQUNaLFVBQVU7S0FDYixVQUFVLEVBQUUsS0FBSztLQUNqQixFQUFFLEVBQUUsSUFBSSxDQUFDLElBQUk7O01BR2hCLEtBQUssQ0FBRSxHQUFHO0lBQ1QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHOzs7O0VBR3JCLFFBQVEsQ0FBQyxNQUFNOzs7VUFHUixNQUFNO0VBQ2IsUUFBUSxDQUFDLFFBQVE7OztVQUdWLFlBQVk7RUFDbkIsS0FBSyxvRUFDZ0UsRUFBRSxXQUNuRSxNQUFNLEVBQUUsUUFBUSxJQUVqQixJQUFJLENBQUUsR0FBRztRQUNILEdBQUcsQ0FBQyxFQUFFO2NBQ0MsS0FBSyxDQUFDLFNBQVM7OztHQUUzQkEsa0JBQU8sQ0FBQyxZQUFZLENBQUMsRUFBRTtLQUV4QixLQUFLLENBQUUsR0FBRyxJQUFLLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRzs7RUFDakMsUUFBUSxDQUFDLE1BQU07Ozs7Ozs7Ozt1QkFZRixLQUFLLG9CQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUs7eUJBUXJDLEtBQUssb0JBQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSzt5QkFReEMsS0FBSyxvQkFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLO3lCQVF2QyxLQUFLLG9CQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUs7eUJBU3hDLEtBQUssb0JBQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSzs7O0VBU3BDLFdBQVc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQTdJM0Isa0JBQUcsVUFBVSxJQUFJLFFBQVEsQ0FBQyxLQUFLOzs7O0dBQy9CLGtCQUFHLGFBQWEsSUFBSSxRQUFRLENBQUMsUUFBUTs7OztHQUNyQyxrQkFBRyxZQUFZLElBQUksUUFBUSxDQUFDLE9BQU87Ozs7R0FDbkMsaUJBQUcsVUFBVSxJQUFJLFlBQVksQ0FBQyxLQUFLOzs7O0dBQ25DLGlCQUFHLGdCQUFnQixJQUFJLFFBQVEsQ0FBQyxXQUFXOzs7O0dBQzNDLGlCQUFHLGFBQWEsSUFBSSxRQUFRLENBQUMsUUFBUTs7OztHQUNyQyxrQkFBRyxXQUFXLEdBQ1osVUFBVSxJQUNWLGFBQWEsSUFDYixZQUFZLElBQ1osVUFBVSxJQUNWLGdCQUFnQixJQUNoQixhQUFhOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs2QkNpREMsR0FBUTs7Ozt3Q0FBVyxHQUFXO3lDQUFhLEdBQVU7Ozs7Ozs7Ozs7Ozs7OztvRUFBckQsR0FBUTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7MENBTUcsR0FBUzs7Ozs7Ozs7OztrQ0FDaEIsR0FBUTtvQ0FFdkIsR0FBZSxJQUFDLE1BQU0sS0FBSyxDQUFDO3NDQUl4QixHQUFlOzttQ0FBWSxHQUFNLEtBQUMsRUFBRTs7O2dDQUF6QyxNQUFJOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBUlIsb0JBR1U7Ozs7Ozs7R0FJVixvQkFnQlU7Ozs7Ozs7Ozs7Ozs7Ozs7OzJCQW5CTCxHQUFlLElBQUMsTUFBTSxLQUFLLENBQUM7Ozs7Ozs7Ozs7OztxQ0FJeEIsR0FBZTs7Ozs7Ozs7Ozs7Ozs7O2tDQUFwQixNQUFJOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBTnNCLFlBQVU7Ozt5QkFBVixZQUFVOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQUduQix3Q0FBc0M7Ozs7OzsyQkFBdEMsd0NBQXNDOzs7Ozs7Ozs7O0dBQXpELG9CQUE2RDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzttQkFNbkQsR0FBTSxLQUFDLEVBQUU7c0JBQ04sR0FBTSxLQUFDLEtBQUs7eUJBQ1QsR0FBTSxLQUFDLFFBQVE7NEJBQ1osR0FBTSxLQUFDLFdBQVc7eUJBQ3JCLEdBQU0sS0FBQyxRQUFRO3dCQUNoQixHQUFNLEtBQUMsV0FBVztzQkFDcEIsR0FBTSxLQUFDLFlBQVk7c0JBQ25CLEdBQU0sS0FBQyxVQUFVOzs7OztzQ0FDZixHQUFTOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FWdEIsb0JBWU07Ozs7Ozs7O3lFQVZFLEdBQU0sS0FBQyxFQUFFOzRFQUNOLEdBQU0sS0FBQyxLQUFLOytFQUNULEdBQU0sS0FBQyxRQUFRO2tGQUNaLEdBQU0sS0FBQyxXQUFXOytFQUNyQixHQUFNLEtBQUMsUUFBUTs4RUFDaEIsR0FBTSxLQUFDLFdBQVc7NEVBQ3BCLEdBQU0sS0FBQyxZQUFZOzRFQUNuQixHQUFNLEtBQUMsVUFBVTs7Ozs7Ozs7Ozs7Ozt3REFUVSxRQUFRLEVBQUUsR0FBRzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OEJBZnBELEdBQVEsUUFBSyxNQUFNOzs7OztvQkFHbkIsR0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7b0JBSFQsR0FBUSxRQUFLLE1BQU07Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1NBMUZOLE9BQU8sQ0FBQyxJQUFJO0NBQzFCLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSTs7UUFDVCxJQUFJLENBQUMsS0FBSyxDQUNmLHNFQUFzRSxFQUVyRSxJQUFJLENBQUUsR0FBRztPQUNILEdBQUcsQ0FBQyxFQUFFO2FBQ0MsS0FBSyxDQUFDLGtEQUFrRDs7O1NBRTdELEdBQUcsQ0FBQyxJQUFJO0lBRWhCLElBQUksQ0FBRSxJQUFJO1FBQ0gsY0FBYzs7YUFDVCxHQUFHLElBQUksSUFBSTtHQUNwQixjQUFjLENBQUMsSUFBSSxHQUFHLEVBQUUsRUFBRSxHQUFHLEtBQUssSUFBSSxDQUFDLEdBQUc7OztXQUVuQyxjQUFjLEVBQUUsY0FBYyxDQUFDLE9BQU87SUFFaEQsS0FBSyxDQUFFLEdBQUc7RUFDVCxLQUFLLEdBQUcsR0FBRztFQUNYLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRztFQUNmLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLDBCQUEwQjs7Ozs7Ozs7T0FnQnJDLGNBQWM7S0FDckIsUUFBUTtLQUNSLFFBQVE7S0FDUixTQUFTO0tBQ1QsUUFBUSxHQUFHLEtBQUs7S0FDaEIsV0FBVztPQU1ULFFBQVEsR0FBRyxxQkFBcUI7O0NBRXRDLE9BQU87RUFDTEEsa0JBQU8sQ0FBQyxVQUFVLENBQUMsY0FBYzs7RUFDakMsV0FBVyxHQUFHQSxrQkFBTyxDQUFDLFNBQVMsQ0FBRSxLQUFLO21CQUNwQyxjQUFjLEdBQUcsS0FBSzs7OztDQUkxQixTQUFTO01BQ0gsV0FBVztHQUNiLFdBQVc7Ozs7VUFJTixTQUFTLENBQUMsS0FBSzttQkFDdEIsUUFBUSxHQUFHLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQzs7O1VBR3RCLFdBQVcsQ0FBQyxLQUFLO2tCQUN4QixRQUFRLEdBQUcsSUFBSTs7O1VBR1IsVUFBVTtrQkFDakIsUUFBUSxHQUFHLElBQUk7a0JBQ2YsUUFBUSxHQUFHLElBQUk7OztVQUdSLFNBQVMsQ0FBQyxLQUFLO2tCQUN0QixRQUFRLEdBQUcsTUFBTTtrQkFDakIsUUFBUSxHQUFHLEtBQUssQ0FBQyxNQUFNOzs7VUFHaEIsUUFBUSxDQUFDLEtBQUs7a0JBQ3JCLFFBQVEsR0FBRyxNQUFNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0F0Q25CLGlCQUFHLGVBQWUsR0FBRyxRQUFRO0tBQ3pCLGNBQWMsQ0FBQyxNQUFNLENBQUUsQ0FBQyxJQUFLLENBQUMsQ0FBQyxVQUFVO0tBQ3pDLGNBQWM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzsifQ==
